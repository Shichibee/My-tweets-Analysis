window.YTD.community_note_rating.part0 = [
  {
    "communityNoteRating" : {
      "noteId" : "1790246654043656268",
      "helpfulnessLevel" : "Helpful",
      "createdAt" : "2024-05-16T01:54:21.745Z",
      "userId" : "1765658836759957505",
      "helpfulTags" : [
        "Clear",
        "ImportantContext"
      ]
    }
  },
  {
    "communityNoteRating" : {
      "noteId" : "1848431539375509810",
      "helpfulnessLevel" : "Helpful",
      "createdAt" : "2024-10-22T14:15:14.334Z",
      "userId" : "1765658836759957505",
      "helpfulTags" : [
        "ImportantContext"
      ]
    }
  },
  {
    "communityNoteRating" : {
      "noteId" : "1883291443974078694",
      "helpfulnessLevel" : "Helpful",
      "createdAt" : "2025-01-29T03:38:56.656Z",
      "userId" : "1765658836759957505",
      "helpfulTags" : [
        "Clear"
      ]
    }
  },
  {
    "communityNoteRating" : {
      "noteId" : "1914343099356332063",
      "helpfulnessLevel" : "Helpful",
      "createdAt" : "2025-04-23T03:19:13.668Z",
      "userId" : "1765658836759957505",
      "helpfulTags" : [
        "ImportantContext"
      ]
    }
  }
]