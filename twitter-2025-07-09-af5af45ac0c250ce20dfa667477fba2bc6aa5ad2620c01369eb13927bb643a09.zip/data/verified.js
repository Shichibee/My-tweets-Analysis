window.YTD.verified.part0 = [
  {
    "verified" : {
      "accountId" : "1765658836759957505",
      "verified" : false
    }
  }
]