window.YTD.deleted_tweet_headers.part0 = [
  {
    "tweet" : {
      "tweet_id" : "1942906084114735478",
      "user_id" : "1765658836759957505",
      "created_at" : "Wed Jul 09 11:18:02 +0000 2025",
      "deleted_at" : "Wed Jul 09 13:06:02 +0000 2025"
    }
  },
  {
    "tweet" : {
      "tweet_id" : "1941357724274741289",
      "user_id" : "1765658836759957505",
      "created_at" : "Sat Jul 05 04:45:24 +0000 2025",
      "deleted_at" : "Sat Jul 05 04:51:50 +0000 2025"
    }
  },
  {
    "tweet" : {
      "tweet_id" : "1941107316130254975",
      "user_id" : "1765658836759957505",
      "created_at" : "Fri Jul 04 12:10:22 +0000 2025",
      "deleted_at" : "Fri Jul 04 12:10:25 +0000 2025"
    }
  },
  {
    "tweet" : {
      "tweet_id" : "1940904288164929851",
      "user_id" : "1765658836759957505",
      "created_at" : "Thu Jul 03 22:43:37 +0000 2025",
      "deleted_at" : "Thu Jul 03 22:44:42 +0000 2025"
    }
  },
  {
    "tweet" : {
      "tweet_id" : "1940641704455164328",
      "user_id" : "1765658836759957505",
      "created_at" : "Thu Jul 03 05:20:12 +0000 2025",
      "deleted_at" : "Thu Jul 03 05:20:21 +0000 2025"
    }
  },
  {
    "tweet" : {
      "tweet_id" : "1940337114127954074",
      "user_id" : "1765658836759957505",
      "created_at" : "Wed Jul 02 09:09:52 +0000 2025",
      "deleted_at" : "Fri Jul 04 14:46:40 +0000 2025"
    }
  },
  {
    "tweet" : {
      "tweet_id" : "1936020261343838261",
      "user_id" : "1765658836759957505",
      "created_at" : "Fri Jun 20 11:16:14 +0000 2025",
      "deleted_at" : "Thu Jun 26 11:19:08 +0000 2025"
    }
  }
]