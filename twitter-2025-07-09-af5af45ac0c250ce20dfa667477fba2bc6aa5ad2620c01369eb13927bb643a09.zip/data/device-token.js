window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "-1",
      "token" : "5OXcvPUfTYnTdRwWRRrvCOjJeFrQmWdC81jxTUjG",
      "createdAt" : "1970-01-01T00:00:00.000Z",
      "lastSeenAt" : "2024-03-07T13:47:12.465Z",
      "clientApplicationName" : ""
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "-1",
      "token" : "078Pk3bgGHBmwu0iyXJ9RwiSTLsVW3jN8UGiaWVT",
      "createdAt" : "1970-01-01T00:00:00.000Z",
      "lastSeenAt" : "2024-03-07T23:26:09.717Z",
      "clientApplicationName" : ""
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "mAhLjbF9qmuXy0FxS6PWHaHXpE84Pd8klFnABiJc",
      "createdAt" : "2024-03-07T08:41:03.444Z",
      "lastSeenAt" : "2024-04-01T15:33:23.289Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "258901",
      "token" : "6y4jchndxy2L4EPOF5SfhqIlwex0NPrQrIVk1eAJ",
      "createdAt" : "2024-06-30T14:54:00.467Z",
      "lastSeenAt" : "2024-06-30T14:54:00.469Z",
      "clientApplicationName" : "Twitter for Android (Twitter, Inc.)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "I6Bwccd5Jj1wUyPuuxEH4DrQfM7k5q7RiVXlePlT",
      "createdAt" : "2024-07-27T16:48:16.110Z",
      "lastSeenAt" : "2024-07-27T16:48:16.112Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "258901",
      "token" : "W7IlESnAltiiQrgvTGs6xT7dSKoIlVFvz0vGbucw",
      "createdAt" : "2024-08-08T10:03:26.708Z",
      "lastSeenAt" : "2024-08-08T10:03:26.709Z",
      "clientApplicationName" : "Twitter for Android (Twitter, Inc.)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "WkLGh1UyAGjJTc8kvrHlwlgVFP5drwXYQA5CZrJT",
      "createdAt" : "2024-05-28T00:19:37.939Z",
      "lastSeenAt" : "2024-09-28T16:31:08.906Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "258901",
      "token" : "ctFbLrjrickD72odWFkdGsGdXy6YtCvF62x0No6Z",
      "createdAt" : "2024-12-22T03:14:48.421Z",
      "lastSeenAt" : "2025-04-01T01:40:00.581Z",
      "clientApplicationName" : "Twitter for Android (Twitter, Inc.)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "5U2rbqebrvjf2qb53UcesMI3uGt7ohmVuo8LOx5n",
      "createdAt" : "2025-05-05T13:20:31.474Z",
      "lastSeenAt" : "2025-05-05T13:20:31.476Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  }
]