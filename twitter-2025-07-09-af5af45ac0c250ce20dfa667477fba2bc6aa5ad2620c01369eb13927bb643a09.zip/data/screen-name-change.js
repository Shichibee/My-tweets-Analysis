window.YTD.screen_name_change.part0 = [
  {
    "screenNameChange" : {
      "accountId" : "1765658836759957505",
      "screenNameChange" : {
        "changedAt" : "2024-03-07T14:05:47.000Z",
        "changedFrom" : "PwOu35jsSI12014",
        "changedTo" : "joyman_7shichi7"
      }
    }
  },
  {
    "screenNameChange" : {
      "accountId" : "1765658836759957505",
      "screenNameChange" : {
        "changedAt" : "2024-03-10T03:45:27.000Z",
        "changedFrom" : "joyman_7shichi7",
        "changedTo" : "joyjoy_7shichi7"
      }
    }
  }
]