window.YTD.lists_member.part0 = [
  {
    "userListInfo" : {
      "url" : "https://twitter.com/hofukuzenshinn/lists/1765283163428008336"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/js2fzh/lists/1761644330106937819"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/js2fzh/lists/1761643609261253024"
    }
  }
]