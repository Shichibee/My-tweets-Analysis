window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "liqi3452@gmail.com",
      "createdVia" : "oauth:3033300",
      "username" : "joyjoy_7shichi7",
      "accountId" : "1765658836759957505",
      "createdAt" : "2024-03-07T08:41:03.347Z",
      "accountDisplayName" : "七億円"
    }
  }
]