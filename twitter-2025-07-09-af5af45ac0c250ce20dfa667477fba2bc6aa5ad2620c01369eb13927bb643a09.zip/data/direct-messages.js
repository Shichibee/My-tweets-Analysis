window.YTD.direct_messages.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "1117358395969814529-1765658836759957505",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "わかんないんか",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1901987570080522648",
            "createdAt" : "2025-03-18T13:22:28.625Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "3→2志望らしいけど詳しいことは分からん",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1901987354631655566",
            "createdAt" : "2025-03-18T13:21:37.262Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "これは二類のどっち",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1901987200964997219",
            "createdAt" : "2025-03-18T13:21:00.617Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "去年一類面接なしで9人通ってるからな",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1901986608070684791",
            "createdAt" : "2025-03-18T13:18:39.261Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "去年は二類16日にメールきてたぽ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1901986510922269150",
            "createdAt" : "2025-03-18T13:18:16.101Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "にるいはあったんま",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1901986434329813497",
            "createdAt" : "2025-03-18T13:17:57.835Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "いや、2類への面接はすでにやったらしいんだけど、1類についてはほんとになんもメール来てない",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1901986143027204106",
            "createdAt" : "2025-03-18T13:16:48.389Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "転類の面接のメールってきてる？そもそもあるの？",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1901977207280677062",
            "createdAt" : "2025-03-18T12:41:17.935Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "surprised",
                "eventId" : "1840186378451333121",
                "createdAt" : "2024-09-29T00:26:36.301Z"
              }
            ],
            "urls" : [ ],
            "text" : "ネット上のよくわからない物への警戒心が薄いの日本人の特徴かも",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1840068836323996060",
            "createdAt" : "2024-09-28T16:39:32.109Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "agree",
                "eventId" : "1840068674893557764",
                "createdAt" : "2024-09-28T16:38:53.585Z"
              }
            ],
            "urls" : [ ],
            "text" : "zipファイルに気をつけよう",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1840068602613117347",
            "createdAt" : "2024-09-28T16:38:36.379Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "むやみやたらに好奇心クリックしちゃだめだね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1840068473873113514",
            "createdAt" : "2024-09-28T16:38:05.710Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "emoji",
                "eventId" : "1840068542584238082",
                "createdAt" : "2024-09-28T16:38:22.042Z"
              }
            ],
            "urls" : [ ],
            "text" : "技術は褒めてあげましょう👏👏",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1840068468080816610",
            "createdAt" : "2024-09-28T16:38:04.305Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "しかもTweetするチェックマーク外したはずだったのにツイートされたし…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1840068220667212241",
            "createdAt" : "2024-09-28T16:37:05.322Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "しかもあのツール、ストーカー探しみたいなやつだから悪意しかない😅",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1840067625671676294",
            "createdAt" : "2024-09-28T16:34:43.458Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "funny",
                "eventId" : "1840067460873261056",
                "createdAt" : "2024-09-28T16:34:04.140Z"
              }
            ],
            "urls" : [ ],
            "text" : "後俺一位で顔ない",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1840067384926970358",
            "createdAt" : "2024-09-28T16:33:46.057Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あざます",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1840067287182913688",
            "createdAt" : "2024-09-28T16:33:22.765Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ツイート消したやつ変なアカウント勝手にフォローしちゃってるから気をつけてください",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1840067197298978895",
            "createdAt" : "2024-09-28T16:33:01.341Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そうですねぇ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1827311701546676241",
            "createdAt" : "2024-08-24T11:47:14.173Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あ、最初にTL見とけば元ネタ確認できたのか…！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1827311341146927518",
            "createdAt" : "2024-08-24T11:45:48.237Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "agree",
                "eventId" : "1827311157444800520",
                "createdAt" : "2024-08-24T11:45:04.400Z"
              }
            ],
            "urls" : [ ],
            "text" : "ありがとうございます‼️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1827310940330864988",
            "createdAt" : "2024-08-24T11:44:12.667Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "第一志望受かっておめでとう！！🎉",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1827310733975285825",
            "createdAt" : "2024-08-24T11:43:23.473Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "第一志望の二類でした。威張ることでもないけど、一類にも十分入れただろう点数なので、そこんとこよろしく。",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1827301744000561503",
            "createdAt" : "2024-08-24T11:07:40.102Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "funny",
                "eventId" : "1824650251187392512",
                "createdAt" : "2024-08-17T03:31:34.919Z"
              }
            ],
            "urls" : [ ],
            "text" : "行けるわけなくて好き",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1824650196233699712",
            "createdAt" : "2024-08-17T03:31:21.842Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ワンチャンメッシュならいけるんじゃね？って思って突っ込んだらしんだ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1824650126629179461",
            "createdAt" : "2024-08-17T03:31:05.251Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "俺やろうとしたけど薄給すぎてやめた",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1824650044659863689",
            "createdAt" : "2024-08-17T03:30:45.703Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "黒髪指定多い気がする",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1824649876459884561",
            "createdAt" : "2024-08-17T03:30:05.598Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あー",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1824649835422814539",
            "createdAt" : "2024-08-17T03:29:55.813Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "イベントスタッフ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1824649673640120418",
            "createdAt" : "2024-08-17T03:29:17.246Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "なんのバイト",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1824649587652694521",
            "createdAt" : "2024-08-17T03:28:56.744Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "とっても悲しい",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1824649240939057363",
            "createdAt" : "2024-08-17T03:27:34.087Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "予選敗退でーす👏👏",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1824649173062521088",
            "createdAt" : "2024-08-17T03:27:17.916Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "funny",
                "eventId" : "1824649138329489411",
                "createdAt" : "2024-08-17T03:27:09.599Z"
              }
            ],
            "urls" : [ ],
            "text" : "おい、笑える",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1824649063473746377",
            "createdAt" : "2024-08-17T03:26:51.778Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "agree",
                "eventId" : "1824649047531196416",
                "createdAt" : "2024-08-17T03:26:47.936Z"
              }
            ],
            "urls" : [ ],
            "text" : "それはバカ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1824648989968568525",
            "createdAt" : "2024-08-17T03:26:34.243Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "いやいやいいんよ\n面接なのに髪染めて行ったからwww",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1824648872544833913",
            "createdAt" : "2024-08-17T03:26:06.242Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ごめんなさい",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1824648683822125424",
            "createdAt" : "2024-08-17T03:25:21.255Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ほら誤字っちゃったじゃん",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1824648220267737135",
            "createdAt" : "2024-08-17T03:23:30.730Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "笑うな！！！今心の中でで泣いてるんだから！！！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1824648128940871910",
            "createdAt" : "2024-08-17T03:23:08.956Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "↑WWWWWWW",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1824647805216194656",
            "createdAt" : "2024-08-17T03:21:51.784Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/lF3uv7h9i8",
                "expanded" : "https://x.com/joyjoy_7shichi7/status/1824646685970272580?s=46",
                "display" : "x.com/joyjoy_7shichi…"
              },
              {
                "url" : "https://t.co/NpqHaZ1iC9",
                "expanded" : "https://twitter.com/joyjoy_7shichi7/status/1824646685970272580",
                "display" : "twitter.com/joyjoy_7shichi…"
              }
            ],
            "text" : "https://t.co/lF3uv7h9i8 https://t.co/NpqHaZ1iC9",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1824647768805347359",
            "createdAt" : "2024-08-17T03:21:43.117Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "funny",
                "eventId" : "1824449391081689093",
                "createdAt" : "2024-08-16T14:13:26.131Z"
              }
            ],
            "urls" : [ ],
            "text" : "罵倒しか思いつかなくて詰み",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1824449280846991712",
            "createdAt" : "2024-08-16T14:12:59.891Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "まあこの胃袋でも満足してるからおけおけ👍",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1824449062936121806",
            "createdAt" : "2024-08-16T14:12:07.934Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "励ましの言葉が見つからない",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1824448647360287056",
            "createdAt" : "2024-08-16T14:10:28.872Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "小さい",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1824448519140512138",
            "createdAt" : "2024-08-16T14:09:58.285Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "うん、かなり",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1824448450353828062",
            "createdAt" : "2024-08-16T14:09:41.890Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "一蘭でもお腹いっぱい？",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1824448324600205705",
            "createdAt" : "2024-08-16T14:09:11.895Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そう、私の胃袋って思ってたよりずっと小さかったことに気づいちゃったからね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1824448209839853625",
            "createdAt" : "2024-08-16T14:08:44.534Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "胃袋小さかったらそれで足りるんだろうな〜と",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1824447991777988693",
            "createdAt" : "2024-08-16T14:07:52.567Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "サイドメニューはサイドサラダね(一番普通に頼んだら高いやつ)",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1824447745018716280",
            "createdAt" : "2024-08-16T14:06:53.714Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "チーズバーガーハッピーセット",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1824447563225059356",
            "createdAt" : "2024-08-16T14:06:10.381Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "メニューは？",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1824446935136432487",
            "createdAt" : "2024-08-16T14:03:40.627Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "私はおばあちゃんになってもハッピーセットを頼み続けるぜ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1824446836226265524",
            "createdAt" : "2024-08-16T14:03:17.041Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ハッピーセットってクーポン使うと420円で食べれるのよ。つまり安くセットメニューを食べれてお得なんよ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1824446540750131566",
            "createdAt" : "2024-08-16T14:02:06.596Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "大学なのにハッピーセット？",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1824445418375352627",
            "createdAt" : "2024-08-16T13:57:38.995Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/JtyrU6TJHo",
                "expanded" : "https://x.com/joyjoy_7shichi7/status/1824442973930786871?s=46",
                "display" : "x.com/joyjoy_7shichi…"
              },
              {
                "url" : "https://t.co/Oq8p2kf9T0",
                "expanded" : "https://twitter.com/joyjoy_7shichi7/status/1824442973930786871",
                "display" : "twitter.com/joyjoy_7shichi…"
              }
            ],
            "text" : "https://t.co/JtyrU6TJHo https://t.co/Oq8p2kf9T0",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1824445374234497300",
            "createdAt" : "2024-08-16T13:57:28.498Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "like",
                "eventId" : "1821503025875406848",
                "createdAt" : "2024-08-08T11:05:37.926Z"
              }
            ],
            "urls" : [ ],
            "text" : "このアカウントは@joyjoy_7shichi7 を応援しています",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1821489094901583967",
            "createdAt" : "2024-08-08T10:10:16.561Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "agree",
                "eventId" : "1821489079856594944",
                "createdAt" : "2024-08-08T10:10:12.934Z"
              }
            ],
            "urls" : [ ],
            "text" : "頑張ってください",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1821488852999233690",
            "createdAt" : "2024-08-08T10:09:18.881Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "確かにw表現力ほしい",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1821488511935234540",
            "createdAt" : "2024-08-08T10:07:57.564Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "新幹線で4時間は耐えられん",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1821487942701138166",
            "createdAt" : "2024-08-08T10:05:41.851Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "小学生みたいな感想だなあ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1821487856235470915",
            "createdAt" : "2024-08-08T10:05:21.234Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "飛行機か！確かに飛行機は速くて良さそうだね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1821487651616370984",
            "createdAt" : "2024-08-08T10:04:32.447Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "飛行機",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1821487339685998924",
            "createdAt" : "2024-08-08T10:03:18.083Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "いいえ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1821487317036781705",
            "createdAt" : "2024-08-08T10:03:12.675Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "青森",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1821487251442020492",
            "createdAt" : "2024-08-08T10:02:57.036Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "青森だっけ？新幹線？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1821487001834856925",
            "createdAt" : "2024-08-08T10:01:57.521Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "まあ俺も実家に来週から帰るからある意味旅行か",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1821486888374743115",
            "createdAt" : "2024-08-08T10:01:30.472Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "いいですね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1821486726885622013",
            "createdAt" : "2024-08-08T10:00:51.973Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "アー",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1821486604206399636",
            "createdAt" : "2024-08-08T10:00:22.721Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "おじいちゃん家だから旅行じゃないかもだけど",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1821486488846262441",
            "createdAt" : "2024-08-08T09:59:55.214Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "次仙台",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1821486478222151851",
            "createdAt" : "2024-08-08T09:59:52.683Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "どこ行くん次は",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1821486275075203156",
            "createdAt" : "2024-08-08T09:59:04.252Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "今はって",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1821486255928168894",
            "createdAt" : "2024-08-08T09:58:59.691Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あありえん",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1821486163435364713",
            "createdAt" : "2024-08-08T09:58:37.637Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "今は岩手",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1821486161518543319",
            "createdAt" : "2024-08-08T09:58:37.181Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "とりま旅行行ってる",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1821486068753203316",
            "createdAt" : "2024-08-08T09:58:15.065Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "夏休みはいかがお過ごしでしょうか",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1821484620858495173",
            "createdAt" : "2024-08-08T09:52:29.853Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "🥶",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1821484529573601716",
            "createdAt" : "2024-08-08T09:52:08.089Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "なるほど。またツイッターに詳しくなってしまった…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1821484433628913919",
            "createdAt" : "2024-08-08T09:51:45.215Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "俺がリツイートしたから",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1821484141382365205",
            "createdAt" : "2024-08-08T09:50:35.536Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "しかし、通知はとんでくるんよ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1821484107941171407",
            "createdAt" : "2024-08-08T09:50:27.564Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "はい",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1821484069349360019",
            "createdAt" : "2024-08-08T09:50:18.365Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "でもこれフラーレン君の垢のツイートじゃなくなかった？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1821483916412518778",
            "createdAt" : "2024-08-08T09:49:41.901Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "こんなのにいいねついたら流石に疑う🤨",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1821483503781040272",
            "createdAt" : "2024-08-08T09:48:03.526Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "間違えたといえば間違えてるか",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1821483073252548821",
            "createdAt" : "2024-08-08T09:46:20.921Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "アカウント間違えてませんか",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1821479096716816598",
            "createdAt" : "2024-08-08T09:30:32.799Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/dY1KzPFwx5",
                "expanded" : "https://twitter.com/messages/media/1821479068090675680",
                "display" : "pic.twitter.com/dY1KzPFwx5"
              }
            ],
            "text" : "？？？？？？ https://t.co/dY1KzPFwx5",
            "mediaUrls" : [
              "https://ton.twitter.com/dm/1821479068090675680/1821479055062925312/3yCu7wwv.jpg"
            ],
            "senderId" : "1117358395969814529",
            "id" : "1821479068090675680",
            "createdAt" : "2024-08-08T09:30:26.043Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "👀👀",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812288468573405360",
            "createdAt" : "2024-07-14T00:50:16.308Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "emoji",
                "eventId" : "1812139667053215744",
                "createdAt" : "2024-07-13T14:58:59.217Z"
              }
            ],
            "urls" : [ ],
            "text" : "ROMなのにずっと張り付いてる❗️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812139397137228196",
            "createdAt" : "2024-07-13T14:57:54.894Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そう❗️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812139308754862430",
            "createdAt" : "2024-07-13T14:57:33.822Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "それに比べりゃ80ツイートくらいの私はROM専だね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812139254241435682",
            "createdAt" : "2024-07-13T14:57:20.823Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "自明だった",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812139060296876037",
            "createdAt" : "2024-07-13T14:56:34.588Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "8800ツイートて",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812139050926850462",
            "createdAt" : "2024-07-13T14:56:32.353Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ツイートの量を見たら分かると思うがね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812138759661789485",
            "createdAt" : "2024-07-13T14:55:22.924Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "俺は張り付いてるよ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812138573992448264",
            "createdAt" : "2024-07-13T14:54:38.644Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "でも人のこと言えないでしょう笑",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812138275920068787",
            "createdAt" : "2024-07-13T14:53:27.584Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "張り付いてなきゃ返信がすぐかえってくるわけない😡",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812137685064278472",
            "createdAt" : "2024-07-13T14:51:06.710Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "い、いや、そんなことはないい",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812137468109697434",
            "createdAt" : "2024-07-13T14:50:14.979Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "君もしかしてTwitterけっこう張り付いてる人❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812137153041993803",
            "createdAt" : "2024-07-13T14:48:59.867Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "agree",
                "eventId" : "1812137115532341248",
                "createdAt" : "2024-07-13T14:48:50.890Z"
              }
            ],
            "urls" : [ ],
            "text" : "ありがとうございます❗️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812136920589463660",
            "createdAt" : "2024-07-13T14:48:04.439Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "画像は笑えんけど()",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812136833255686246",
            "createdAt" : "2024-07-13T14:47:43.615Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "この電気通信大学の区切り方のネタ個人的にめちゃすき笑",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812136800649203902",
            "createdAt" : "2024-07-13T14:47:35.858Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "電気通信大学の「きつ」の部分",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812133564416438432",
            "createdAt" : "2024-07-13T14:34:44.263Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "これ威力やばすぎる😂",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812132987015962685",
            "createdAt" : "2024-07-13T14:32:26.604Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ヒェッ！？\nグサッときた…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812132811228533204",
            "createdAt" : "2024-07-13T14:31:44.690Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/dJskLy37fM",
                "expanded" : "https://twitter.com/messages/media/1812125487269040386",
                "display" : "pic.twitter.com/dJskLy37fM"
              }
            ],
            "text" : "ツイートみてたらこれ流れてきて鬱 https://t.co/dJskLy37fM",
            "mediaUrls" : [
              "https://ton.twitter.com/dm/1812125487269040386/1812125440070258688/319A7Ks5.jpg"
            ],
            "senderId" : "1117358395969814529",
            "id" : "1812125487269040386",
            "createdAt" : "2024-07-13T14:02:38.794Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "emoji",
                "eventId" : "1812080646552207360",
                "createdAt" : "2024-07-13T11:04:27.637Z"
              }
            ],
            "urls" : [ ],
            "text" : "私の涙ちょっぴり甘いの",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812079387782869200",
            "createdAt" : "2024-07-13T10:59:27.546Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "泣いた",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812079229007499410",
            "createdAt" : "2024-07-13T10:58:49.695Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "でもこれはちがうと思うwww",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812067429339775247",
            "createdAt" : "2024-07-13T10:11:56.440Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "まあそれもそうか笑",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812065553395405311",
            "createdAt" : "2024-07-13T10:04:29.171Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "反省してもろて",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812065533799649794",
            "createdAt" : "2024-07-13T10:04:24.502Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "5分しかないから何やっても変わらんよ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812063938697416958",
            "createdAt" : "2024-07-13T09:58:04.204Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "調子に乗ってしまい申し訳ございませんでした",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812063734938157133",
            "createdAt" : "2024-07-13T09:57:15.624Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "てか50分のうち5分のスマホタイムをこれ送るのに使うより、もっと有意義な使い方ありそうw",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812052342457487815",
            "createdAt" : "2024-07-13T09:11:59.441Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "🤮🤮🤮🤮",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812051536606069204",
            "createdAt" : "2024-07-13T09:08:47.309Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "@joyjoy_7shichi7 さん。ツイッターまとめで見かけてもっと知りたくなってフォローしましたヾ(*•ω•)ﾉ♡\n\nツイート内容が18禁なので、もし嫌じゃなければ絡みつき合いましょう。",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812049449277149399",
            "createdAt" : "2024-07-13T09:00:29.653Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "まじか",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812029854851957242",
            "createdAt" : "2024-07-13T07:42:37.978Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あー、オープンキャンパス前日だからかな？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812029706000302344",
            "createdAt" : "2024-07-13T07:42:02.487Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そいえば今日って図書館空いてないんよね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812029539629117489",
            "createdAt" : "2024-07-13T07:41:22.823Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "まじでわからん",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812029309277929767",
            "createdAt" : "2024-07-13T07:40:27.903Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "源流どこやねん",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812029200490184933",
            "createdAt" : "2024-07-13T07:40:01.965Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "先輩もコピペなんかい！！！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812029147310703083",
            "createdAt" : "2024-07-13T07:39:49.285Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "これもほぼコピペっすよ…",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812028989885895098",
            "createdAt" : "2024-07-13T07:39:11.754Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "もちろん",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812028939940037071",
            "createdAt" : "2024-07-13T07:38:59.850Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "でも先輩たちのネタツイおもろいよね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812028922592395704",
            "createdAt" : "2024-07-13T07:38:55.708Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "パクツイだったんかい！！！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812028890107523414",
            "createdAt" : "2024-07-13T07:38:47.963Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "永遠に流れてくる",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812028676328030662",
            "createdAt" : "2024-07-13T07:37:56.999Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "先輩のツイートのコピペなので…",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812028615162495276",
            "createdAt" : "2024-07-13T07:37:42.427Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "🤧",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812028545721675834",
            "createdAt" : "2024-07-13T07:37:25.858Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "てかツイートのほうでも結構な頻度でネタツイあげれてんのすごいよね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812028525966446858",
            "createdAt" : "2024-07-13T07:37:21.145Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "🤣",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812028474561036801",
            "createdAt" : "2024-07-13T07:37:08.891Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "オラsinのすけ\n↑\n｜　　   オラ\n｜ 　 ラ　  　オ\n｜  オ　　　　  オ\n｜ラ　　　　　  ラ\n  オーー ーーーー オー ー  ーー ラ→\n｜　　　　　　　 ラ 　　   　  オ\n｜　　　　　　　  オ　　　　ラ\n｜　　　　　　　　 ラ　　  オ\n｜　　　　　　　　　  オラ\n↓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812027840763715744",
            "createdAt" : "2024-07-13T07:34:37.790Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "今のままでもいいですヨ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812027579916013945",
            "createdAt" : "2024-07-13T07:33:35.589Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "🤩",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812027473305174442",
            "createdAt" : "2024-07-13T07:33:10.171Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "返答スキル上げてえ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812027382158754072",
            "createdAt" : "2024-07-13T07:32:48.440Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/KiMjgWoWLh",
                "expanded" : "https://twitter.com/messages/media/1812027356942414144",
                "display" : "pic.twitter.com/KiMjgWoWLh"
              }
            ],
            "text" : "なんて返そうかなって迷った結果だったていう() https://t.co/KiMjgWoWLh",
            "mediaUrls" : [
              "https://ton.twitter.com/dm/1812027356942414144/1812027343394717696/5T0pntQk.jpg"
            ],
            "senderId" : "1765658836759957505",
            "id" : "1812027356942414144",
            "createdAt" : "2024-07-13T07:32:42.763Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812026798143864843",
            "createdAt" : "2024-07-13T07:30:29.206Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "はぁ💧",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812026747023688107",
            "createdAt" : "2024-07-13T07:30:17.015Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/tb2HnWRvNJ",
                "expanded" : "https://twitter.com/messages/media/1812026085200265297",
                "display" : "pic.twitter.com/tb2HnWRvNJ"
              }
            ],
            "text" : " https://t.co/tb2HnWRvNJ",
            "mediaUrls" : [
              "https://ton.twitter.com/dm/1812026085200265297/1812026075116929024/lz0ls6Xl.jpg"
            ],
            "senderId" : "1117358395969814529",
            "id" : "1812026085200265297",
            "createdAt" : "2024-07-13T07:27:39.428Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "emoji",
                "eventId" : "1812026025876029440",
                "createdAt" : "2024-07-13T07:27:25.411Z"
              }
            ],
            "urls" : [ ],
            "text" : "おい、笑える",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812025858540097793",
            "createdAt" : "2024-07-13T07:26:45.180Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "待ってほんとに笑えん",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812025735324008856",
            "createdAt" : "2024-07-13T07:26:15.812Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "いや、線形と物概の前日()",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812025703728316810",
            "createdAt" : "2024-07-13T07:26:08.279Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "微積ってそっちも数円の前日❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812025082522533927",
            "createdAt" : "2024-07-13T07:23:40.160Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "emoji",
                "eventId" : "1812025143033827328",
                "createdAt" : "2024-07-13T07:23:54.566Z"
              }
            ],
            "urls" : [ ],
            "text" : "まずいですよ❗️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812024937361850562",
            "createdAt" : "2024-07-13T07:23:05.559Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "🤢🤢🤢",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812024859423105365",
            "createdAt" : "2024-07-13T07:22:46.976Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あと微積わかんないのもﾏﾁﾞわかる",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812024823423664238",
            "createdAt" : "2024-07-13T07:22:38.395Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "🤣🤣🤣",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1812024654351204472",
            "createdAt" : "2024-07-13T07:21:58.079Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "微積ぃみゎかんなぃ。。。。\n\nもぅﾏﾁﾞ無理。\n\nﾏﾘｶしょ…\n\nﾌﾞｳｳｳｩﾝwwwwwwwｲﾔｯﾌｳｩｳwwwwwﾏﾝﾏﾐｰｱwwwwwwﾋｭｲｺﾞｰwwwwwww",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1812023605418688867",
            "createdAt" : "2024-07-13T07:17:48.005Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [
              {
                "senderId" : "1117358395969814529",
                "reactionKey" : "agree",
                "eventId" : "1811732059880411136",
                "createdAt" : "2024-07-12T11:59:18.101Z"
              }
            ],
            "urls" : [ ],
            "text" : "たしかに怖いかも\n今まで何も考えず作ってた…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1811705568077447352",
            "createdAt" : "2024-07-12T10:14:01.988Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "作る時に、法律知らなすぎて違反おかしそうで怖い",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1811694687994216762",
            "createdAt" : "2024-07-12T09:30:47.973Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "なるほどね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1811693898433200208",
            "createdAt" : "2024-07-12T09:27:39.727Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "仮のテスト用で持ってるっちゃ持ってるけど、ババーンッとは出してない",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1811693472086393228",
            "createdAt" : "2024-07-12T09:25:58.072Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "自分のサイトって持ってる❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1811692878051311775",
            "createdAt" : "2024-07-12T09:23:36.458Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "agree",
                "eventId" : "1810891523049095168",
                "createdAt" : "2024-07-10T04:19:18.500Z"
              }
            ],
            "urls" : [ ],
            "text" : "有名な山だもんね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810887871454400976",
            "createdAt" : "2024-07-10T04:04:47.928Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "地元の山しか登ったことない😂",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810887798502871508",
            "createdAt" : "2024-07-10T04:04:30.528Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "かなり登りやすかった！人いっぱいいるから迷いにくいし",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1810885890962817271",
            "createdAt" : "2024-07-10T03:56:55.734Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "高尾山って登りやすいの?",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810885277214462351",
            "createdAt" : "2024-07-10T03:54:29.406Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "すごい",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810885244842856836",
            "createdAt" : "2024-07-10T03:54:21.688Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "最近も高尾山にソロ登山してきた！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1810879794235724195",
            "createdAt" : "2024-07-10T03:32:42.163Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "入ってないけど趣味だよ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1810879730176118927",
            "createdAt" : "2024-07-10T03:32:26.893Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "山岳部にでもはいってたの❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810853762447417731",
            "createdAt" : "2024-07-10T01:49:15.694Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "😂😂😂😂",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810853178646405135",
            "createdAt" : "2024-07-10T01:46:56.504Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "😅",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810853071989399870",
            "createdAt" : "2024-07-10T01:46:31.081Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "私も中学受験してないからわからん😖",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1810852575354425361",
            "createdAt" : "2024-07-10T01:44:32.670Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "中学受験とかほぼない田舎出身だからわからん",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810850752639947082",
            "createdAt" : "2024-07-10T01:37:18.104Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ほーん",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810850636587749815",
            "createdAt" : "2024-07-10T01:36:50.437Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "多分むずいのかな？倍率もすごかったような",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1810850197154734158",
            "createdAt" : "2024-07-10T01:35:05.658Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "中学から入る方がむずいんか❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810849244804497506",
            "createdAt" : "2024-07-10T01:31:18.612Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "(*☻-☻*)",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810848930030313841",
            "createdAt" : "2024-07-10T01:30:03.564Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "私は高校から。多分だけど市浦界隈のタラーさんたちは内部進学組が多い印象…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1810848579768160432",
            "createdAt" : "2024-07-10T01:28:40.058Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "agree",
                "eventId" : "1810848617915371523",
                "createdAt" : "2024-07-10T01:28:49.119Z"
              }
            ],
            "urls" : [ ],
            "text" : "旧帝いいなー",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810847436572922035",
            "createdAt" : "2024-07-10T01:24:07.484Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "一貫なのか",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810847114714632654",
            "createdAt" : "2024-07-10T01:22:50.755Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "もちろん自称進だけど、中学からの人たちはけっこう旧帝とか行ってる",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1810846836657377497",
            "createdAt" : "2024-07-10T01:21:44.466Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "市立の方ぅて自称進なの❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810846464014438830",
            "createdAt" : "2024-07-10T01:20:15.615Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "意外といないのか",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810846112091361411",
            "createdAt" : "2024-07-10T01:18:51.710Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "インスタ文化の市浦だとタラーはものすごく貴重存在",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1810845937235022000",
            "createdAt" : "2024-07-10T01:18:10.079Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "野楼さぎで草",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810845539359150568",
            "createdAt" : "2024-07-10T01:16:35.159Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そうだよ\nなんかrank334の上位ランカーが後輩くんでいるらしいね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1810845468517343357",
            "createdAt" : "2024-07-10T01:16:18.271Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "市立浦和❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810844819792744860",
            "createdAt" : "2024-07-10T01:13:43.602Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "同じクラスの人",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810844322931306864",
            "createdAt" : "2024-07-10T01:11:45.143Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "3人君のことフォローしてた",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810844303440367887",
            "createdAt" : "2024-07-10T01:11:40.495Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "なるほど…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1810843964364480674",
            "createdAt" : "2024-07-10T01:10:19.653Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "同じクラスの人がフォローしてた",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810843014761435225",
            "createdAt" : "2024-07-10T01:06:33.246Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "てかどこで知った！？！？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1810842438359208285",
            "createdAt" : "2024-07-10T01:04:15.826Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そういえばフォロリク送ってきてたよね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1810842351948140885",
            "createdAt" : "2024-07-10T01:03:55.218Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そう",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1810842328950788173",
            "createdAt" : "2024-07-10T01:03:49.739Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "インスタって佐藤(な)ってやつ❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810841840398311805",
            "createdAt" : "2024-07-10T01:01:53.267Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "sad",
                "eventId" : "1810323807078637568",
                "createdAt" : "2024-07-08T14:43:24.468Z"
              }
            ],
            "urls" : [ ],
            "text" : "再履を覚悟",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810291229063844287",
            "createdAt" : "2024-07-08T12:33:57.294Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "しかも比熱なのがやばい‼️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810291159270641847",
            "createdAt" : "2024-07-08T12:33:40.648Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "謁見と被るのきついね…！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1810290967796383795",
            "createdAt" : "2024-07-08T12:32:54.990Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "次の比熱が期末と被っててやばい❗️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810290669069717642",
            "createdAt" : "2024-07-08T12:31:43.779Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "まあそうよねー",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1810289667864244240",
            "createdAt" : "2024-07-08T12:27:45.078Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "いちいち担当の名前覚えてないな〜",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810287307859329239",
            "createdAt" : "2024-07-08T12:18:22.397Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "クラスの人が上の代の人のツイートをリツイートしてて厳しいみたいなこと言ってた",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810287216389968376",
            "createdAt" : "2024-07-08T12:18:00.593Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "いや、kndo先生が厳しいのなら知ってるけど",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1810287044004135200",
            "createdAt" : "2024-07-08T12:17:19.504Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "謁見ってysmrって人の講評厳しいって言われてる❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810285360595001621",
            "createdAt" : "2024-07-08T12:10:38.135Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [
              {
                "senderId" : "1117358395969814529",
                "reactionKey" : "sad",
                "eventId" : "1810285397374898176",
                "createdAt" : "2024-07-08T12:10:46.875Z"
              }
            ],
            "urls" : [ ],
            "text" : "確かに謎",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1810285082600702059",
            "createdAt" : "2024-07-08T12:09:31.860Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "TAに不確かさ任意って言われたのにやらないといけなくなったの謎だけど",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810284190925201876",
            "createdAt" : "2024-07-08T12:05:59.285Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "まあ担当違うからしょうがないよね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810284089322414581",
            "createdAt" : "2024-07-08T12:05:35.045Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "すまんよデマ流して…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1810284022528081978",
            "createdAt" : "2024-07-08T12:05:19.139Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "友達ってか琥珀",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810283908753486036",
            "createdAt" : "2024-07-08T12:04:51.991Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "不確かさ適当に書いた友達はOKもらっててWWWWWW",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810283874855088433",
            "createdAt" : "2024-07-08T12:04:43.910Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "まじか！やっぱり先生違うと全然違うのね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1810282943820316743",
            "createdAt" : "2024-07-08T12:01:01.968Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "不確かさやらずにだしたらやってください❗️と言われました",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1810254112841510939",
            "createdAt" : "2024-07-08T10:06:28.099Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "emoji",
                "eventId" : "1809930289906651137",
                "createdAt" : "2024-07-07T12:39:42.672Z"
              }
            ],
            "urls" : [ ],
            "text" : "この大学終わってます‼️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809930023287341243",
            "createdAt" : "2024-07-07T12:38:39.140Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "後俺のクラスの奴もR18普通にリツイートする",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809929590024130956",
            "createdAt" : "2024-07-07T12:36:55.821Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "なっちゃんっていう人と、らむかなって人はリツイートしてきます",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809929460361384249",
            "createdAt" : "2024-07-07T12:36:24.908Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "でもリツイートもするひともいるよね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809929334163116533",
            "createdAt" : "2024-07-07T12:35:54.849Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "emoji",
                "eventId" : "1809929978924183552",
                "createdAt" : "2024-07-07T12:38:28.519Z"
              }
            ],
            "urls" : [ ],
            "text" : "いいねはしてるということを吐いてて笑った",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809929323455136020",
            "createdAt" : "2024-07-07T12:35:52.268Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あ、ちがうわリツイートはしてないわ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809929118785679635",
            "createdAt" : "2024-07-07T12:35:03.476Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "😇😇😇",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809928993262723482",
            "createdAt" : "2024-07-07T12:34:33.546Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "大学垢で普通にリツイートしてくる輩がいるから意味ないけど",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809928871149707290",
            "createdAt" : "2024-07-07T12:34:04.431Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "大学垢でいいねするとまずいようななのにいいねする専用のアカウント持ってたけど、意味なくなった",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809928198014333366",
            "createdAt" : "2024-07-07T12:31:23.940Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "意外",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809927979700801571",
            "createdAt" : "2024-07-07T12:30:31.888Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "いや大学垢の他にはフォロワー0人の見る用アカウントしかない",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809927857805860930",
            "createdAt" : "2024-07-07T12:30:02.835Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Twitterアカウントたくさん持ってる人❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809927563252527552",
            "createdAt" : "2024-07-07T12:28:52.610Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "それはたしかにそうね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809927508286181759",
            "createdAt" : "2024-07-07T12:28:39.492Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "著作権に引っかからんていいね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809927358079770628",
            "createdAt" : "2024-07-07T12:28:03.690Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "自作なのか❗️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809927278417391732",
            "createdAt" : "2024-07-07T12:27:44.693Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "無事使えてよかった",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809926717647278565",
            "createdAt" : "2024-07-07T12:25:30.998Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "これは昔いつかなんかのアイコンにしたいなーって自作したやつ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809926694163325396",
            "createdAt" : "2024-07-07T12:25:25.388Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "方位磁針みたいたの",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809926527087431964",
            "createdAt" : "2024-07-07T12:24:45.564Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "アイコンってなに❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809926500109709794",
            "createdAt" : "2024-07-07T12:24:39.133Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "面白い🤣",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809926424725451178",
            "createdAt" : "2024-07-07T12:24:21.161Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "バケモンだなー",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809926348795727883",
            "createdAt" : "2024-07-07T12:24:03.055Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "GPTをGDPに間違えたい気分だったていう()",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809926265606164762",
            "createdAt" : "2024-07-07T12:23:43.222Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "まあね。２時間とかの人もいるにいるっぽいし",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809926095011233976",
            "createdAt" : "2024-07-07T12:23:02.550Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "どういうこと❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809926005957829006",
            "createdAt" : "2024-07-07T12:22:41.318Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "それは若干わざと笑",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809925954875294071",
            "createdAt" : "2024-07-07T12:22:29.135Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "まあいなくはない距離か",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809925139917902064",
            "createdAt" : "2024-07-07T12:19:14.841Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "chat gptですよ❗️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809924930194264398",
            "createdAt" : "2024-07-07T12:18:24.829Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "若干？でも片道1時間３０分くらいよ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809924773314716138",
            "createdAt" : "2024-07-07T12:17:47.429Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "遠い❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809924599272083891",
            "createdAt" : "2024-07-07T12:17:05.939Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そうそう",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809924497849692318",
            "createdAt" : "2024-07-07T12:16:41.750Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "実家❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809924473073610794",
            "createdAt" : "2024-07-07T12:16:35.855Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "寮かなるほど",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809924447161434475",
            "createdAt" : "2024-07-07T12:16:29.664Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ドームじゃないけど",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809924236573896966",
            "createdAt" : "2024-07-07T12:15:39.454Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "寮ではある",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809924221654778073",
            "createdAt" : "2024-07-07T12:15:35.906Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あ一人暮らしか",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809924168672325760",
            "createdAt" : "2024-07-07T12:15:23.276Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "実家から持ってきてない",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809923996856823902",
            "createdAt" : "2024-07-07T12:14:42.311Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "お薬飲んでないですね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809923728324915443",
            "createdAt" : "2024-07-07T12:13:38.288Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "薬とか飲んだ？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809923571952881800",
            "createdAt" : "2024-07-07T12:13:01.014Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "担当違うからそういうのなかったな〜、かなり優しい方ではあったけど",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809923491044724799",
            "createdAt" : "2024-07-07T12:12:41.716Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "体温計無くしてて困る❗️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809923363021930708",
            "createdAt" : "2024-07-07T12:12:11.188Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "朝からやばい❗️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809923315680878733",
            "createdAt" : "2024-07-07T12:11:59.909Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そんな…具合大丈夫...!?",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809923128572928202",
            "createdAt" : "2024-07-07T12:11:15.295Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そもそもokn先生が渡してきた手書き用プリントが両面１枚だけだったていう",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809923026059964633",
            "createdAt" : "2024-07-07T12:10:50.858Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "具合悪いせいでレポート全然かけん❗️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809922765224571090",
            "createdAt" : "2024-07-07T12:09:48.671Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "それでも通るのか‼️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809922432607920250",
            "createdAt" : "2024-07-07T12:08:29.366Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "私",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809919323353571412",
            "createdAt" : "2024-07-07T11:56:08.055Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "渡し()",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809919247294116093",
            "createdAt" : "2024-07-07T11:55:49.923Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "けど、渡しの場合実験数も少なかった",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809919207003578780",
            "createdAt" : "2024-07-07T11:55:40.313Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "くっそ少ない。2ページ半+画像専用ページ1枚しかなかった",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809919077961646148",
            "createdAt" : "2024-07-07T11:55:09.553Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "無しでどれくらいのページ数❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809913553228644425",
            "createdAt" : "2024-07-07T11:33:12.350Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "結局やらなかった",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809913436316500029",
            "createdAt" : "2024-07-07T11:32:44.476Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "不確かさってやったんだっけ❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809913117734002742",
            "createdAt" : "2024-07-07T11:31:28.541Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "agree",
                "eventId" : "1809592017493860352",
                "createdAt" : "2024-07-06T14:15:32.255Z"
              }
            ],
            "urls" : [ ],
            "text" : "返信早すぎて草ありがたいけど",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809591755106664617",
            "createdAt" : "2024-07-06T14:14:29.705Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ok だるすぎて各気しなかった",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809591615977320688",
            "createdAt" : "2024-07-06T14:13:56.530Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "光速度はさっき見せた1個しか書いてない",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809591175919349872",
            "createdAt" : "2024-07-06T14:12:11.610Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "書いてない",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809591061175759297",
            "createdAt" : "2024-07-06T14:11:44.273Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "光速度のケーブルの接続の図って入れた?",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809590609788957167",
            "createdAt" : "2024-07-06T14:09:56.646Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "agree",
                "eventId" : "1809556081703809026",
                "createdAt" : "2024-07-06T11:52:44.471Z"
              }
            ],
            "urls" : [ ],
            "text" : "ぜひラインスタンプかってください",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809555967627128976",
            "createdAt" : "2024-07-06T11:52:17.304Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "この人のホームページ遊び心あっていいよね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809555485114462427",
            "createdAt" : "2024-07-06T11:50:22.263Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "こういうの見てると自分もMy webサイト作りたくなってくる…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809555397604438296",
            "createdAt" : "2024-07-06T11:50:01.394Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "てかこの人のホームページの写真もぜんぶ鬼のお面つけてるのおもろい",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809555202284167174",
            "createdAt" : "2024-07-06T11:49:14.831Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "つまみログをみると徒歩記録見れたはず",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809554767125049365",
            "createdAt" : "2024-07-06T11:47:31.075Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "なんか鬼のお面付けながら徒歩してらしいです",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809554659838947606",
            "createdAt" : "2024-07-06T11:47:05.501Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "って思ったら背景若干違った",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809554477659439398",
            "createdAt" : "2024-07-06T11:46:22.068Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "鬼のお面被せてるだけやないかいw",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809554422663729610",
            "createdAt" : "2024-07-06T11:46:08.951Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "@TrpFrog",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809554233802502293",
            "createdAt" : "2024-07-06T11:45:23.931Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "股濡れ徒歩部のアイコンはつまみさんのあいこんの一部",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809554183110160396",
            "createdAt" : "2024-07-06T11:45:11.841Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "色々おもろい由来www",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809553871825694867",
            "createdAt" : "2024-07-06T11:43:57.623Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "名前",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809553446099648741",
            "createdAt" : "2024-07-06T11:42:16.128Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "つまみさん(M2,モナ子さんの友達,徒歩部(?)所属)がびっけん嫌すぎてお漏らしたところから来ているらしいです",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809553428659790128",
            "createdAt" : "2024-07-06T11:42:11.979Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "funny",
                "eventId" : "1809553043819753472",
                "createdAt" : "2024-07-06T11:40:40.187Z"
              }
            ],
            "urls" : [ ],
            "text" : "全然股濡れてないし、徒歩もしてない",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809552993110618503",
            "createdAt" : "2024-07-06T11:40:28.127Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "名前からは良くわかんなかったけどそういう活動してたのか…謎解けた！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809552850810466698",
            "createdAt" : "2024-07-06T11:39:54.191Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Twitter見てるときに名前だけ見たことある垢だ！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809552811853770786",
            "createdAt" : "2024-07-06T11:39:44.910Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "@matanure_gazer これ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809552511386452154",
            "createdAt" : "2024-07-06T11:38:33.281Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "身内でワイワイするみたいな",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809552393513890140",
            "createdAt" : "2024-07-06T11:38:05.163Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "サークルはない❗️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809552344709001327",
            "createdAt" : "2024-07-06T11:37:53.528Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そういうサークルはいってるの？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809552143252353357",
            "createdAt" : "2024-07-06T11:37:05.493Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "この人もゲームセンターで頑張ってる人なのか！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809552095743512900",
            "createdAt" : "2024-07-06T11:36:54.172Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "@kyu_099",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809551054054523060",
            "createdAt" : "2024-07-06T11:32:45.812Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "モナ子って人",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809550731978101077",
            "createdAt" : "2024-07-06T11:31:29.024Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "なんかそのTA逆に頼もしいwww",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809550669998879050",
            "createdAt" : "2024-07-06T11:31:14.291Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "じゃあそう",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809550586544812147",
            "createdAt" : "2024-07-06T11:30:54.358Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そうそう",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809550555343384876",
            "createdAt" : "2024-07-06T11:30:46.915Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あー確かにそれはそうだわ。気をつけます！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809550519867981968",
            "createdAt" : "2024-07-06T11:30:38.451Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "月曜４？",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809550479338402105",
            "createdAt" : "2024-07-06T11:30:28.786Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "この知り合いのTAたしか5クラ担当だった気がする",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809550262312530215",
            "createdAt" : "2024-07-06T11:29:37.044Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ミスると2点つく可能性あるから気を付けないとね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809550120612163624",
            "createdAt" : "2024-07-06T11:29:03.292Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "agree",
                "eventId" : "1809550070658002945",
                "createdAt" : "2024-07-06T11:28:51.327Z"
              }
            ],
            "urls" : [ ],
            "text" : "おれはひとつです",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809549956233195721",
            "createdAt" : "2024-07-06T11:28:24.071Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "今度から1個にしよw",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809549902474838436",
            "createdAt" : "2024-07-06T11:28:11.251Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "funny",
                "eventId" : "1809549969545932800",
                "createdAt" : "2024-07-06T11:28:27.216Z"
              }
            ],
            "urls" : [ ],
            "text" : "1個しか課題やらないような人がTAやってんのおもろいけどW",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809549898548932921",
            "createdAt" : "2024-07-06T11:28:10.324Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "一個でもいいんか！？2つやってた…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809549834460033216",
            "createdAt" : "2024-07-06T11:27:55.039Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "知り合いのM2のTAやってる人に聞いたら一個しかやってなったって言われて,一個しかやらんくなったWWWW",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809549639437488198",
            "createdAt" : "2024-07-06T11:27:08.544Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "最初3つやってたけど",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809549466858582059",
            "createdAt" : "2024-07-06T11:26:27.394Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "最初は頑張ってたけど、1,2個でもおなじ点ならって気づいてから適当になった笑",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809549237568590072",
            "createdAt" : "2024-07-06T11:25:32.733Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "それな",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809549228244627785",
            "createdAt" : "2024-07-06T11:25:30.513Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "普段一個か2個しかやってません…",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809548698839576653",
            "createdAt" : "2024-07-06T11:23:24.284Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [
              {
                "senderId" : "1117358395969814529",
                "reactionKey" : "funny",
                "eventId" : "1809548711950970880",
                "createdAt" : "2024-07-06T11:23:27.386Z"
              }
            ],
            "urls" : [ ],
            "text" : "そうだよね。4点レアよね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809548652765147645",
            "createdAt" : "2024-07-06T11:23:13.310Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "俺も3点しかない",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809548537337901523",
            "createdAt" : "2024-07-06T11:22:45.784Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "2点はでかいけど、8点はあわよくばと考えてる…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809548476751224950",
            "createdAt" : "2024-07-06T11:22:31.343Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "いっつも3点しか取れてないから、とりま6点は取れるように頑張る！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809548449005859312",
            "createdAt" : "2024-07-06T11:22:24.728Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "8点か6点の違いだと結構でかいね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809547955394998745",
            "createdAt" : "2024-07-06T11:20:27.037Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "らしいよね。なんか分量も加味するらしいからまとめてるドキュメントの内容を全コピペ作戦でもしよっかなって思ってる",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809547592633905257",
            "createdAt" : "2024-07-06T11:19:00.549Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "総合演習だから配点2倍らしいね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809547330376626583",
            "createdAt" : "2024-07-06T11:17:58.023Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "提出する時のLaTeXのテンプレがあるからそれに従って書けばそこまでむずくない",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809547253423698087",
            "createdAt" : "2024-07-06T11:17:39.672Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そうだよね！ありがとう！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809547075195207808",
            "createdAt" : "2024-07-06T11:16:57.178Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "個人でいいと思うよ❗️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809547021122191835",
            "createdAt" : "2024-07-06T11:16:44.279Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "てか結論は個人の中でのでいいんだよね\nグループであわせるとかじゃないよね？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809546847931060315",
            "createdAt" : "2024-07-06T11:16:02.997Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "会話しても忘れる",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809546733569110256",
            "createdAt" : "2024-07-06T11:15:35.731Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そっちの方がいい",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809546671669612666",
            "createdAt" : "2024-07-06T11:15:20.967Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "リアルで議論せずGoogleドキュメントでやってるからどうやってまとめようかなって感じ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809546623288242459",
            "createdAt" : "2024-07-06T11:15:09.436Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "俺先々週それだった",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809546577100624151",
            "createdAt" : "2024-07-06T11:14:58.429Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あーあー",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809546531487510683",
            "createdAt" : "2024-07-06T11:14:47.550Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ディスカッションするやつ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809546308883226667",
            "createdAt" : "2024-07-06T11:13:54.477Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "コンリテ何やってるの❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809546259604336908",
            "createdAt" : "2024-07-06T11:13:42.726Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "私もコンリテ月曜提出で何もやってないけど大丈夫かって楽観視しちゃってるけどw",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809545919479836953",
            "createdAt" : "2024-07-06T11:12:21.635Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "www🤣",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809545709714305306",
            "createdAt" : "2024-07-06T11:11:31.623Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そのせいで苦しめられています‼️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809544997123010631",
            "createdAt" : "2024-07-06T11:08:41.731Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "なるほど\n楽観的な考えも人生には不可欠だもんな…！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809544884585742767",
            "createdAt" : "2024-07-06T11:08:14.900Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "俺は別になくてもいけるでしょ❗️っていう楽観的な考えから見ていない",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809543941056065669",
            "createdAt" : "2024-07-06T11:04:29.941Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "でも剽窃疑惑かけられるのが怖すぎるから「意地でも見ない！！」って言ってる人もいるにはいるらしい…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809543719278072102",
            "createdAt" : "2024-07-06T11:03:37.063Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "泣いた",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809543408945623165",
            "createdAt" : "2024-07-06T11:02:23.076Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そうだね。結構な数の人が見てるよ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809539613301871061",
            "createdAt" : "2024-07-06T10:47:18.126Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "周りの人も過去レポみてるの❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809533945371062592",
            "createdAt" : "2024-07-06T10:24:46.788Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "過去レポありできついのに、なしとか本当に尊敬…✨",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809533593267679395",
            "createdAt" : "2024-07-06T10:23:22.866Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "その分考えるべきこと多すぎる",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809533323531940346",
            "createdAt" : "2024-07-06T10:22:18.524Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "まあね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809533273389035788",
            "createdAt" : "2024-07-06T10:22:06.568Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "全部我流で笑笑",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809533224869314807",
            "createdAt" : "2024-07-06T10:21:55.001Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "でも剽窃疑惑かけられないのつよい",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809533203415462033",
            "createdAt" : "2024-07-06T10:21:49.888Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "え、すご！？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809533151234126274",
            "createdAt" : "2024-07-06T10:21:37.448Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "みたことない",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809533082950909957",
            "createdAt" : "2024-07-06T10:21:21.164Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "過去レポねぇ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809533071466901607",
            "createdAt" : "2024-07-06T10:21:18.429Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "過去レポ頼りでどこ書いてるか見た記憶",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809532905594712148",
            "createdAt" : "2024-07-06T10:20:38.884Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "光速度は歴史はいらんて！！！って思ったもんなぁ…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809532717492760806",
            "createdAt" : "2024-07-06T10:19:54.035Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "光速度とか、最初に光速度の測定の歴史とかいうのが入ってるだけじゃん‼️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809519493447839989",
            "createdAt" : "2024-07-06T09:27:21.177Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そういえばそうだったわ。私もすごい悩んだ気がする",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809518520515883308",
            "createdAt" : "2024-07-06T09:23:29.220Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "放射線、光速度って他の実験と違ってテキストに明確に原理と手順の章が設けられてないでここらへん描きづらい",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809516716818592116",
            "createdAt" : "2024-07-06T09:16:19.186Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "agree",
                "eventId" : "1809514302736592898",
                "createdAt" : "2024-07-06T09:06:43.593Z"
              }
            ],
            "urls" : [ ],
            "text" : "めっちゃ簡略化してかいたので🙆‍♀️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809514271333831069",
            "createdAt" : "2024-07-06T09:06:36.128Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "教科書完全丸パクリじゃなきゃ大丈夫！多分",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809514124931657823",
            "createdAt" : "2024-07-06T09:06:01.223Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "もはや図は書いてればなんでもいいんじゃないかなんて思ってたり",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809513872400994410",
            "createdAt" : "2024-07-06T09:05:01.032Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "嬉しくも悲しくもあるやつだけど",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809513706981847049",
            "createdAt" : "2024-07-06T09:04:21.580Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "概要の図はそこまで見てないんじゃねって思ってる",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809513676959019220",
            "createdAt" : "2024-07-06T09:04:14.428Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "エセパルス派でいいのか",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809513307268870196",
            "createdAt" : "2024-07-06T09:02:46.279Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [
              {
                "senderId" : "1117358395969814529",
                "reactionKey" : "agree",
                "eventId" : "1809513323949658112",
                "createdAt" : "2024-07-06T09:02:50.235Z"
              }
            ],
            "urls" : [
              {
                "url" : "https://t.co/187kcdL7tD",
                "expanded" : "https://twitter.com/messages/media/1809511921361825973",
                "display" : "pic.twitter.com/187kcdL7tD"
              }
            ],
            "text" : "概要の図ってこんなのだよね確か https://t.co/187kcdL7tD",
            "mediaUrls" : [
              "https://ton.twitter.com/dm/1809511921361825973/1809511918782312448/sJQu8cZ_.jpg"
            ],
            "senderId" : "1765658836759957505",
            "id" : "1809511921361825973",
            "createdAt" : "2024-07-06T08:57:15.979Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "それはベクターイラストツールで適当に直線を曲げてエセパルス波を作った",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809510854850932893",
            "createdAt" : "2024-07-06T08:53:01.574Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "実験の写真てよりか原理とかで説明するのにパルス波がほしいんですのね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809506736979759210",
            "createdAt" : "2024-07-06T08:36:39.796Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そうだよ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809506527268728915",
            "createdAt" : "2024-07-06T08:35:49.812Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "okn先生の光速度は写真でもオッケーだったんだわ\n(光速度の話で合ってる？)",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809505759916618053",
            "createdAt" : "2024-07-06T08:32:46.847Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "グラフw",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809492393823269072",
            "createdAt" : "2024-07-06T07:39:40.117Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "いや",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809492384780361993",
            "createdAt" : "2024-07-06T07:39:37.966Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "パルス波作った覚えあったかな…？(忘れてるだけ？)",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809491712278184421",
            "createdAt" : "2024-07-06T07:36:57.626Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "なんの実験？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809491699460452777",
            "createdAt" : "2024-07-06T07:36:54.582Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "パルス波の図ってどうやって作った❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809483575731056765",
            "createdAt" : "2024-07-06T07:04:37.735Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "emoji",
                "eventId" : "1809005581916909569",
                "createdAt" : "2024-07-04T23:25:15.097Z"
              }
            ],
            "urls" : [ ],
            "text" : "尊敬",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809005148041326637",
            "createdAt" : "2024-07-04T23:23:31.675Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "よくそんな遅くまでいれるね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809004887252087174",
            "createdAt" : "2024-07-04T23:22:29.498Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ええ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809004837918625925",
            "createdAt" : "2024-07-04T23:22:17.735Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "いや片道1時間半かかるよ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809003515773362432",
            "createdAt" : "2024-07-04T23:17:02.510Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "調布住みなんか❓こんな遅くまでいるということは",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809002895565861059",
            "createdAt" : "2024-07-04T23:14:34.650Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ありがたい",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809002659028087050",
            "createdAt" : "2024-07-04T23:13:38.256Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "暑くて辛すぎ…！って感じたことないから多分ついてる",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809002423534694498",
            "createdAt" : "2024-07-04T23:12:42.106Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "B棟の一階ってクーラー効いてんの?",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809002214717075868",
            "createdAt" : "2024-07-04T23:11:52.316Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "おお",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809002156458193058",
            "createdAt" : "2024-07-04T23:11:38.431Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "なんか朝3時くらいまでどっかの棟で喋り倒したことあるっていう友だちもいるから閉まらない説もある…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809002067874492445",
            "createdAt" : "2024-07-04T23:11:17.305Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "図書館よりは遅くまで空いてるよね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1809001748809592984",
            "createdAt" : "2024-07-04T23:10:01.235Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "わかんないけど少なくとも22:45でも空いてるよ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1809001056925536423",
            "createdAt" : "2024-07-04T23:07:16.274Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "B棟って何時まで空いてるの❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1808891691405099322",
            "createdAt" : "2024-07-04T15:52:41.521Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "sad",
                "eventId" : "1808763430217920513",
                "createdAt" : "2024-07-04T07:23:01.632Z"
              }
            ],
            "urls" : [ ],
            "text" : "俺は図書室でスヤァします",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1808763357941617056",
            "createdAt" : "2024-07-04T07:22:44.420Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あっ中国語か",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1808763205420003627",
            "createdAt" : "2024-07-04T07:22:08.058Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "てか授業集中します",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1808762902972920191",
            "createdAt" : "2024-07-04T07:20:55.948Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "変装！？笑",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1808762827500630337",
            "createdAt" : "2024-07-04T07:20:37.957Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "今日変装してるから多分見つかんなかったと思う",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1808762752141578631",
            "createdAt" : "2024-07-04T07:20:20.006Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "なるほどね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1808762651503378543",
            "createdAt" : "2024-07-04T07:19:55.997Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そうだよ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1808762448033595554",
            "createdAt" : "2024-07-04T07:19:07.482Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "なんで琥珀知ってるのかと思ったけど、スポチャン❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1808762407122317724",
            "createdAt" : "2024-07-04T07:18:57.730Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "でもちゃんとそっちの方見てなかったな…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1808762291879620824",
            "createdAt" : "2024-07-04T07:18:30.253Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "隣",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1808762109800620323",
            "createdAt" : "2024-07-04T07:17:46.838Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "違う",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1808762097993723946",
            "createdAt" : "2024-07-04T07:17:44.028Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "琥珀?",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1808762059485745430",
            "createdAt" : "2024-07-04T07:17:34.846Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "もしや小野寺くんとかのグループにいた？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1808761792283471884",
            "createdAt" : "2024-07-04T07:16:31.138Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "今でた",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1808761121664553396",
            "createdAt" : "2024-07-04T07:13:51.257Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "もしかしてB棟いる❓(orいた❓)",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1808760469756465274",
            "createdAt" : "2024-07-04T07:11:15.827Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [
              {
                "senderId" : "1117358395969814529",
                "reactionKey" : "agree",
                "eventId" : "1808632555975159811",
                "createdAt" : "2024-07-03T22:42:58.781Z"
              }
            ],
            "urls" : [ ],
            "text" : "よかった！！！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1808627797822484694",
            "createdAt" : "2024-07-03T22:24:04.375Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "全力探索したら見つかりました❗️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1808566065531924643",
            "createdAt" : "2024-07-03T18:18:46.254Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "agree",
                "eventId" : "1808527342903627776",
                "createdAt" : "2024-07-03T15:44:54.031Z"
              }
            ],
            "urls" : [ ],
            "text" : "ごめん、ありがとう",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1808526599991808193",
            "createdAt" : "2024-07-03T15:41:56.930Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ごめん書き込みすごかった",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1808525955079758218",
            "createdAt" : "2024-07-03T15:39:23.168Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/mDM5TbTZ29",
                "expanded" : "https://twitter.com/messages/media/1808525857348321386",
                "display" : "pic.twitter.com/mDM5TbTZ29"
              }
            ],
            "text" : " https://t.co/mDM5TbTZ29",
            "mediaUrls" : [
              "https://ton.twitter.com/dm/1808525857348321386/1808525855028887552/gy3ccQKA.jpg"
            ],
            "senderId" : "1765658836759957505",
            "id" : "1808525857348321386",
            "createdAt" : "2024-07-03T15:39:00.067Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/6Et4rvUIis",
                "expanded" : "https://twitter.com/messages/media/1808525824628510957",
                "display" : "pic.twitter.com/6Et4rvUIis"
              }
            ],
            "text" : " https://t.co/6Et4rvUIis",
            "mediaUrls" : [
              "https://ton.twitter.com/dm/1808525824628510957/1808525821117906944/S6COSDJ1.jpg"
            ],
            "senderId" : "1765658836759957505",
            "id" : "1808525824628510957",
            "createdAt" : "2024-07-03T15:38:52.259Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "とりま音読ページだけ送るね\n他も送って欲しかったら言ってね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1808525800062534036",
            "createdAt" : "2024-07-03T15:38:46.209Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "選択中国語の3課と4課みせてほしい❗️教科書を無くした",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1808515977786937571",
            "createdAt" : "2024-07-03T14:59:44.407Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "funny",
                "eventId" : "1807769656117370880",
                "createdAt" : "2024-07-01T13:34:07.424Z"
              }
            ],
            "urls" : [ ],
            "text" : "やりますね〜❗️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807769412638015501",
            "createdAt" : "2024-07-01T13:33:09.404Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "なってますね❗️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807769346330308898",
            "createdAt" : "2024-07-01T13:32:53.587Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "(最近頑張れbotになってる気がする…)",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807769284355162268",
            "createdAt" : "2024-07-01T13:32:38.814Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "頑張れ！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807769260825223298",
            "createdAt" : "2024-07-01T13:32:33.205Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "簡単だからやった方がいいよー的なこと言われたからやるか",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807768976115761403",
            "createdAt" : "2024-07-01T13:31:25.324Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "(私はまだ人生で一度も求めてない人)",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807768403098337321",
            "createdAt" : "2024-07-01T13:29:08.703Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そんな緩かったんか？！でも余裕あったら出したほうがいいのだろうね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807768386270789841",
            "createdAt" : "2024-07-01T13:29:04.693Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "的な。一年の実験は不確かさ強制じゃないみたいなこともいってた",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807767967989653983",
            "createdAt" : "2024-07-01T13:27:24.965Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "やったらプラスになるよー、",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807767829825069531",
            "createdAt" : "2024-07-01T13:26:52.026Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "TAの人は強制してなかったかな",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807767766835085494",
            "createdAt" : "2024-07-01T13:26:37.005Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "いや、今回の春タームならまあ許すって言ってたからそれに甘えたけど、他の先生はわからん",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807767608349065270",
            "createdAt" : "2024-07-01T13:25:59.224Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "同じ学年でもいるよね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807767515545973109",
            "createdAt" : "2024-07-01T13:25:37.095Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "不確かさってやった❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807767366522274189",
            "createdAt" : "2024-07-01T13:25:01.562Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "てか意外とチャラい人はいるw",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807767334872027173",
            "createdAt" : "2024-07-01T13:24:54.029Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [
              {
                "senderId" : "1117358395969814529",
                "reactionKey" : "funny",
                "eventId" : "1807767292064985089",
                "createdAt" : "2024-07-01T13:24:43.788Z"
              }
            ],
            "urls" : [ ],
            "text" : "そういう人もいるのか\nまあ、他の大学から院入学してきた人って可能性もあるね…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807767270770512320",
            "createdAt" : "2024-07-01T13:24:38.740Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "電通大生には見えん",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807766793005793439",
            "createdAt" : "2024-07-01T13:22:44.834Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "帽子深く被ってピアスつけてるお兄さんだった",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807766692585673129",
            "createdAt" : "2024-07-01T13:22:20.889Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あーそういうことかー\nたまたま見なかっただけか",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807766552592421134",
            "createdAt" : "2024-07-01T13:21:47.510Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "最初講評あるからだと思う",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807766406903312825",
            "createdAt" : "2024-07-01T13:21:12.770Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "光電効果か電気回路もTAいた",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807766348543721945",
            "createdAt" : "2024-07-01T13:20:58.856Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "スペクトルもTAっぽかったよ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807766254914326838",
            "createdAt" : "2024-07-01T13:20:36.537Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "光速度にTAっているんだ！比熱だけだと思ってた",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807766110508622028",
            "createdAt" : "2024-07-01T13:20:02.110Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "最初担当の先生じゃなくてTAの人きた",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807765956233744802",
            "createdAt" : "2024-07-01T13:19:25.330Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "おれんとこは光速度測るのとケーブルのやつやった",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807765845437001734",
            "createdAt" : "2024-07-01T13:18:58.904Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "私一つだったけど他の先生どうなのかなって",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807765676624671023",
            "createdAt" : "2024-07-01T13:18:18.659Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "3つって❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807765543845585278",
            "createdAt" : "2024-07-01T13:17:47.006Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "無事に終わったっぽくてよかった！\n実験って3つやった？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807765362756505618",
            "createdAt" : "2024-07-01T13:17:03.837Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "funny",
                "eventId" : "1807765347866730497",
                "createdAt" : "2024-07-01T13:17:00.257Z"
              }
            ],
            "urls" : [ ],
            "text" : "班員が動画みたいにうまくいかないって言ったら、自分この動画作った😎って言われておもろい",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807764859117085140",
            "createdAt" : "2024-07-01T13:15:03.754Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "担当okn先生じゃなかったけど、質問したら優しかったわ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807764562214789424",
            "createdAt" : "2024-07-01T13:13:52.972Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [
              {
                "senderId" : "1117358395969814529",
                "reactionKey" : "funny",
                "eventId" : "1807679693832990720",
                "createdAt" : "2024-07-01T07:36:38.739Z"
              }
            ],
            "urls" : [ ],
            "text" : "いわゆるハズレ装置だったのか…！\nとりまおつかれ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807679263975591950",
            "createdAt" : "2024-07-01T07:34:56.281Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/093f09mjqp",
                "expanded" : "https://twitter.com/messages/media/1807678647601684813",
                "display" : "pic.twitter.com/093f09mjqp"
              }
            ],
            "text" : "プリズム汚れてたし、ケーブル断線しかけてたしで大変だったわ https://t.co/093f09mjqp",
            "mediaUrls" : [
              "https://ton.twitter.com/dm/1807678647601684813/1807678510976344064/o3AYVjRq.jpg"
            ],
            "senderId" : "1117358395969814529",
            "id" : "1807678647601684813",
            "createdAt" : "2024-07-01T07:32:29.461Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [
              {
                "senderId" : "1117358395969814529",
                "reactionKey" : "agree",
                "eventId" : "1807623303953346560",
                "createdAt" : "2024-07-01T03:52:34.348Z"
              }
            ],
            "urls" : [ ],
            "text" : "頑張って！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807623069273592312",
            "createdAt" : "2024-07-01T03:51:38.418Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "これから光速度🙂",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807623021299216406",
            "createdAt" : "2024-07-01T03:51:26.991Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [
              {
                "senderId" : "1117358395969814529",
                "reactionKey" : "agree",
                "eventId" : "1807622974155202560",
                "createdAt" : "2024-07-01T03:51:15.717Z"
              }
            ],
            "urls" : [ ],
            "text" : "よかった！！！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807622913618780583",
            "createdAt" : "2024-07-01T03:51:01.304Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ありがとうございました",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807622873034760329",
            "createdAt" : "2024-07-01T03:50:51.631Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "圧縮したら1MBくらいなって提出できた❗️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807622852956557682",
            "createdAt" : "2024-07-01T03:50:46.856Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "surprised",
                "eventId" : "1807523256318255104",
                "createdAt" : "2024-06-30T21:15:01.132Z"
              }
            ],
            "urls" : [ ],
            "text" : "俺の取り込んだpng画像のサイズがでかいみたい❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807443273080091131",
            "createdAt" : "2024-06-30T15:57:11.668Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "agree",
                "eventId" : "1807442858976415744",
                "createdAt" : "2024-06-30T15:55:32.912Z"
              }
            ],
            "urls" : [ ],
            "text" : "頑張ります‼️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807442827212939412",
            "createdAt" : "2024-06-30T15:55:25.362Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "多分",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807442727816380692",
            "createdAt" : "2024-06-30T15:55:01.666Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "つまり、夏ターム中なら行けるってことか",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807442695771894197",
            "createdAt" : "2024-06-30T15:54:54.026Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "頑張って！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807442607968281045",
            "createdAt" : "2024-06-30T15:54:33.090Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "(提出日時までは見てないってokn先生が言ってた)",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807442546211352860",
            "createdAt" : "2024-06-30T15:54:18.360Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "まあLMSのフォームが閉じるまでなら大丈夫説もあるから",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807442534211506577",
            "createdAt" : "2024-06-30T15:54:15.504Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "とりあえず印刷はしたので画像いじりますわ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807442417945284735",
            "createdAt" : "2024-06-30T15:53:47.786Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "提出できないと辛い‼️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807442188433076376",
            "createdAt" : "2024-06-30T15:52:53.061Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "一回pngからepsかjpgにwebサイトかなんかで変換してみたらちょっと軽くなるかも…？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807441624475254938",
            "createdAt" : "2024-06-30T15:50:38.604Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "pngは確かに重い部類ではあるけどそこまでになるのか…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807441614534791394",
            "createdAt" : "2024-06-30T15:50:36.238Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "8枚でした",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807441030222135425",
            "createdAt" : "2024-06-30T15:48:16.922Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "png画像で",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807440948441550873",
            "createdAt" : "2024-06-30T15:47:57.427Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "まあはい",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807440890514100438",
            "createdAt" : "2024-06-30T15:47:43.613Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "私より少ないだと…！？\n手書きを写真で撮ったとか？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807440841327423880",
            "createdAt" : "2024-06-30T15:47:31.888Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "5枚くらい貼ってますね…",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807440646543937658",
            "createdAt" : "2024-06-30T15:46:45.448Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ハイ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807440578952786349",
            "createdAt" : "2024-06-30T15:46:29.333Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "画像がめちゃくちゃ貼られてるとか？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807440542084841780",
            "createdAt" : "2024-06-30T15:46:20.543Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "違います！",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807440458852991387",
            "createdAt" : "2024-06-30T15:46:00.703Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "MBとKBの見間違えとかでもないんだよね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807440351587901798",
            "createdAt" : "2024-06-30T15:45:35.131Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ハイ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807440209400959480",
            "createdAt" : "2024-06-30T15:45:01.225Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "LaTeXで作ってる？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807440191139025072",
            "createdAt" : "2024-06-30T15:44:56.873Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そうだよ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807440138362065011",
            "createdAt" : "2024-06-30T15:44:44.288Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "圧縮なしで❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807440061971226873",
            "createdAt" : "2024-06-30T15:44:26.079Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "私放射線で14くらい行ったけど大丈夫だったよ。330KBとか",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807439878818594822",
            "createdAt" : "2024-06-30T15:43:42.408Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "surprised",
                "eventId" : "1807439907943755776",
                "createdAt" : "2024-06-30T15:43:49.330Z"
              }
            ],
            "urls" : [ ],
            "text" : "13MB😥",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807439685209448764",
            "createdAt" : "2024-06-30T15:42:56.257Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "10とか❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807439600148992316",
            "createdAt" : "2024-06-30T15:42:35.973Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "何ページくらいになっちゃったの？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807439197118296080",
            "createdAt" : "2024-06-30T15:40:59.878Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "いやそんな事ある！？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807439117317468171",
            "createdAt" : "2024-06-30T15:40:40.855Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "PDFファイル⁉️がデカすぎてLMSにあげれないのはどうすればよい❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807438088391823717",
            "createdAt" : "2024-06-30T15:36:35.541Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "agree",
                "eventId" : "1807430347384307712",
                "createdAt" : "2024-06-30T15:05:49.915Z"
              }
            ],
            "urls" : [ ],
            "text" : "まだ見てないから観ます😥",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807429797699879045",
            "createdAt" : "2024-06-30T15:03:38.887Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "まあそれは私もそうだった。LMSにある動画見るとちょっと実際の様子がわかってくるかも？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807429622109528144",
            "createdAt" : "2024-06-30T15:02:57.020Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ふぇぇ、テキスト読んでもあんまり理解できなくてね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807429359709679658",
            "createdAt" : "2024-06-30T15:01:54.462Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ほかは分からんけど",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807429180633833566",
            "createdAt" : "2024-06-30T15:01:11.766Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "これは本当に先生による。okn先生なら大勝利だと思って良い",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807429155648418216",
            "createdAt" : "2024-06-30T15:01:05.816Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "光速度はむずい❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807428928929485298",
            "createdAt" : "2024-06-30T15:00:11.764Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "agree",
                "eventId" : "1807428853830443008",
                "createdAt" : "2024-06-30T14:59:53.824Z"
              }
            ],
            "urls" : [ ],
            "text" : "ありがとう‼️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807428825560830190",
            "createdAt" : "2024-06-30T14:59:47.124Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "なんか複雑になっちゃったけど基本、講評の次の週までかな",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807428824235483429",
            "createdAt" : "2024-06-30T14:59:46.792Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "PDFは1回紙で提出して、講評で再提出の指示が出ればそれ直して紙媒体をその次の週出す＆ここでPDFも出す\n講評でこれで大丈夫だよって言われたら忘れないうちに(直したきゃ直して)出す",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807428508341477793",
            "createdAt" : "2024-06-30T14:58:31.479Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "レポートをPDFファイルで提出するのってどのタイミング❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807427076812914901",
            "createdAt" : "2024-06-30T14:52:50.182Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "初回放射線だっあ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807426900740149421",
            "createdAt" : "2024-06-30T14:52:08.203Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "たしかに",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807426865726099720",
            "createdAt" : "2024-06-30T14:51:59.852Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "放射線とか数値打ちが地獄だったよ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807426725850255568",
            "createdAt" : "2024-06-30T14:51:26.493Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "無限に時間吸われる",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807426625740714136",
            "createdAt" : "2024-06-30T14:51:02.628Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "謁見自体だるい",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807426592647606541",
            "createdAt" : "2024-06-30T14:50:54.743Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "比熱は辛い…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807426457528111468",
            "createdAt" : "2024-06-30T14:50:22.526Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ラスト比熱で死",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807426382550704149",
            "createdAt" : "2024-06-30T14:50:04.647Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "放射線と光速度同じだ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807426346848747912",
            "createdAt" : "2024-06-30T14:49:56.140Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "光電効果、放射線、光速度やったよ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807425528405831777",
            "createdAt" : "2024-06-30T14:46:41.010Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "謁見って、何やった❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807417111897350183",
            "createdAt" : "2024-06-30T14:13:14.360Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [
              {
                "senderId" : "1117358395969814529",
                "reactionKey" : "agree",
                "eventId" : "1807090178915442688",
                "createdAt" : "2024-06-29T16:34:07.432Z"
              }
            ],
            "urls" : [ ],
            "text" : "ぐんない",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807090155213533340",
            "createdAt" : "2024-06-29T16:34:01.828Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "おやすみなさい",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807089963600929168",
            "createdAt" : "2024-06-29T16:33:16.127Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [
              {
                "senderId" : "1117358395969814529",
                "reactionKey" : "agree",
                "eventId" : "1807089936325279744",
                "createdAt" : "2024-06-29T16:33:09.596Z"
              }
            ],
            "urls" : [ ],
            "text" : "謁見頑張って！(前期謁見勢より)",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807089890213109801",
            "createdAt" : "2024-06-29T16:32:58.624Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そうですね私も寝ます",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807089795807727900",
            "createdAt" : "2024-06-29T16:32:36.112Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そろそろ寝ます、謁見の手直し明日しないとなので",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807089687397531948",
            "createdAt" : "2024-06-29T16:32:10.267Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "いえいえ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807089605826818403",
            "createdAt" : "2024-06-29T16:31:50.820Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "すみません、ほんとに",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807089581034242440",
            "createdAt" : "2024-06-29T16:31:44.909Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "抑えるの頑張って",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807089494295982455",
            "createdAt" : "2024-06-29T16:31:24.249Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "心の🤡が出そうになる",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807089415724130576",
            "createdAt" : "2024-06-29T16:31:05.496Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "自重助かる",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807089373881811033",
            "createdAt" : "2024-06-29T16:30:55.523Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "今確信に迫る質問しようとしたけど、気持ち悪いから自重",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807089313232089286",
            "createdAt" : "2024-06-29T16:30:41.061Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ありがとうございますｗ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807089092565610991",
            "createdAt" : "2024-06-29T16:29:48.445Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あげます",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807088851384783064",
            "createdAt" : "2024-06-29T16:28:50.943Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "いいですよ‼️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807088833525415967",
            "createdAt" : "2024-06-29T16:28:46.697Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "月曜",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807088793247420792",
            "createdAt" : "2024-06-29T16:28:37.090Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "イキってすみません、こんなもんで勝ったと思うなよ、闇堕ちのどれか着ていくか",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807088769889357968",
            "createdAt" : "2024-06-29T16:28:31.524Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "冗談だけど笑",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807088732216189128",
            "createdAt" : "2024-06-29T16:28:22.536Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そんじゃネタTみつけてはちみつバターパンせびるか笑",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807088686154342778",
            "createdAt" : "2024-06-29T16:28:11.584Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "生協のパンくらいなら買ってあげるくらいには申し訳ないと思ってる",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807088417634910279",
            "createdAt" : "2024-06-29T16:27:07.536Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "一方的すぎたのでしょうがない",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807088254640124415",
            "createdAt" : "2024-06-29T16:26:28.678Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ネタTシャツさがすか笑",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807087913311883467",
            "createdAt" : "2024-06-29T16:25:07.290Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "個人情報なのにごめんね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807087897574772787",
            "createdAt" : "2024-06-29T16:25:03.542Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "とか?",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807087756314914961",
            "createdAt" : "2024-06-29T16:24:29.863Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ネタtシャツを着てることがおおい(?)",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807087662333071408",
            "createdAt" : "2024-06-29T16:24:07.457Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "NIKEの靴",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807087555957096841",
            "createdAt" : "2024-06-29T16:23:42.176Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "最近は黒色のトートバッグ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807087476718330358",
            "createdAt" : "2024-06-29T16:23:23.203Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "裸眼",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807087401262780714",
            "createdAt" : "2024-06-29T16:23:05.216Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "174cm",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807087381855740294",
            "createdAt" : "2024-06-29T16:23:00.585Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ゲーセンにいる",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807087312460980472",
            "createdAt" : "2024-06-29T16:22:44.044Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "男",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807087277153394866",
            "createdAt" : "2024-06-29T16:22:35.627Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "8クラ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807087249508675919",
            "createdAt" : "2024-06-29T16:22:29.027Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "それで許すかも",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807087106646581568",
            "createdAt" : "2024-06-29T16:21:54.968Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "じゃあなんかヒントくれ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807087083569455417",
            "createdAt" : "2024-06-29T16:21:49.465Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "何も情報与えてないのに一方的で迷惑よね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807086645944127828",
            "createdAt" : "2024-06-29T16:20:05.139Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そっち側からしたら怖い人ですみません",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807086539996103129",
            "createdAt" : "2024-06-29T16:19:39.866Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "まあそうなんだよね...こちらも全然検討ついてない",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807086369375948985",
            "createdAt" : "2024-06-29T16:18:59.190Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "5,6クラと関わる機会ないし",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807086185615180037",
            "createdAt" : "2024-06-29T16:18:15.381Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "5クラの女子なんて誰も知らないね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807086092052824506",
            "createdAt" : "2024-06-29T16:17:53.071Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "2人かはわからんけど2,3人くらいには",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807085932593680398",
            "createdAt" : "2024-06-29T16:17:15.052Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "いや、中国語のクラスの",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807085591298986332",
            "createdAt" : "2024-06-29T16:15:53.681Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "2人ってのは5クラ女子のってこと？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807085491600392492",
            "createdAt" : "2024-06-29T16:15:29.909Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "大外しの可能性もあるけど",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807085458129883227",
            "createdAt" : "2024-06-29T16:15:21.935Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "その時点で2人のどっちかな的な",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807085316265922912",
            "createdAt" : "2024-06-29T16:14:48.109Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あーね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807084949167808998",
            "createdAt" : "2024-06-29T16:13:20.592Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "人数少ないし女子もそんないないじゃん❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807084916921995774",
            "createdAt" : "2024-06-29T16:13:12.897Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "元々木5で中国って",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807084835523227880",
            "createdAt" : "2024-06-29T16:12:53.489Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "いや、AWEの前に食べてた",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807084714223878487",
            "createdAt" : "2024-06-29T16:12:24.583Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "君の本垢かなんかですか?",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807084635614290106",
            "createdAt" : "2024-06-29T16:12:05.838Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "じゃあそのたいみんぐじゃないのか",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807084629830316037",
            "createdAt" : "2024-06-29T16:12:04.452Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "わかりません！",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807084545784926330",
            "createdAt" : "2024-06-29T16:11:44.410Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "まじかもしかしてそうめんで伝わる？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807084493259608200",
            "createdAt" : "2024-06-29T16:11:31.894Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "多分俺の方からはわかった",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807084363349459055",
            "createdAt" : "2024-06-29T16:11:00.914Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "🉐",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807084210643140733",
            "createdAt" : "2024-06-29T16:10:24.507Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そっちのほうがフェアではあるけども",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807084122873176453",
            "createdAt" : "2024-06-29T16:10:03.579Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "両得に持ち込んだ方がいいですか?",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807083954597703964",
            "createdAt" : "2024-06-29T16:09:23.465Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "まってまたこれ片特作戦始めてるな！？！？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807083879972626636",
            "createdAt" : "2024-06-29T16:09:05.673Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "何階?",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807083793150591359",
            "createdAt" : "2024-06-29T16:08:44.972Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "AWEです",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807083728294007060",
            "createdAt" : "2024-06-29T16:08:29.512Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "金曜三限って授業なに❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807083588858601510",
            "createdAt" : "2024-06-29T16:07:56.259Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ええよ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807083423628218834",
            "createdAt" : "2024-06-29T16:07:16.866Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "全然関係ない話していい?",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807083395731816516",
            "createdAt" : "2024-06-29T16:07:10.216Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "お腹いっぱい食べてもろて",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807083274084487432",
            "createdAt" : "2024-06-29T16:06:41.212Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "今日飯あんまり食ってないわ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807083125350264848",
            "createdAt" : "2024-06-29T16:06:05.751Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ごはん❗️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807082972782408162",
            "createdAt" : "2024-06-29T16:05:29.383Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "おかず❗️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807082764543619564",
            "createdAt" : "2024-06-29T16:04:39.729Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ふわふわ時間おれ今でも歌える笑笑",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807082665897771423",
            "createdAt" : "2024-06-29T16:04:16.216Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あとごはんはおかずも",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807082511337726074",
            "createdAt" : "2024-06-29T16:03:39.362Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "funny",
                "eventId" : "1807082568447299584",
                "createdAt" : "2024-06-29T16:03:52.955Z"
              }
            ],
            "urls" : [ ],
            "text" : "オヂサンだヨ〜🙍‍♂️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807082510612128131",
            "createdAt" : "2024-06-29T16:03:39.187Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "アニメは見てないのにふわふわ時間をアコギで練習したことある笑",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807082421629972814",
            "createdAt" : "2024-06-29T16:03:17.982Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "それはほんとに思う",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807082281439506808",
            "createdAt" : "2024-06-29T16:02:44.563Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "けいおん！すき",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807082062467481709",
            "createdAt" : "2024-06-29T16:01:52.348Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "このアニメこんな前なの⁉️ってのが多くて、年取ったのを感じる",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807081742295310773",
            "createdAt" : "2024-06-29T16:00:36.015Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "agree",
                "eventId" : "1807081710443749376",
                "createdAt" : "2024-06-29T16:00:28.403Z"
              }
            ],
            "urls" : [ ],
            "text" : "頑張って‼️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807081562980393307",
            "createdAt" : "2024-06-29T15:59:53.257Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "今年中には絶対見よ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807081520752136370",
            "createdAt" : "2024-06-29T15:59:43.197Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "当時した",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807081430427869408",
            "createdAt" : "2024-06-29T15:59:21.653Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "感動する",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807081381207691609",
            "createdAt" : "2024-06-29T15:59:09.916Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "見ましょう",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807081345430229221",
            "createdAt" : "2024-06-29T15:59:01.389Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "名前とキービジュ見たことあっていつか見たいなって思ってたやつだ！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807081286827495847",
            "createdAt" : "2024-06-29T15:58:47.418Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "色づく世界の明日からってアニメ好き",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807080939983679914",
            "createdAt" : "2024-06-29T15:57:24.718Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "アニメ何見てるの?",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807080547006705894",
            "createdAt" : "2024-06-29T15:55:51.069Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あー名前だけ…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807080481663664247",
            "createdAt" : "2024-06-29T15:55:35.445Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "青ブタとかよう実とか",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807080309982441548",
            "createdAt" : "2024-06-29T15:54:54.519Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "何読んでた？(わからん可能性高いけど)",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807080238851276981",
            "createdAt" : "2024-06-29T15:54:37.559Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "この時期俺が当時読んでたラノベがアニメ化し始めてるな",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807079800915517861",
            "createdAt" : "2024-06-29T15:52:53.162Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "何それ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807079608526999923",
            "createdAt" : "2024-06-29T15:52:07.276Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "なるほど",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807079577250128216",
            "createdAt" : "2024-06-29T15:51:59.820Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あと約ネバ似のなにか",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807079576457367761",
            "createdAt" : "2024-06-29T15:51:59.634Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "私も調べてみたけどゆるキャンとかシャドーハウスとか見てたわ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807079451051823591",
            "createdAt" : "2024-06-29T15:51:29.732Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "色々あった",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807079362036203790",
            "createdAt" : "2024-06-29T15:51:08.505Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "別に平成アニメも見てたけどね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807078936771457094",
            "createdAt" : "2024-06-29T15:49:27.116Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "んー調べてみます",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807078775852871894",
            "createdAt" : "2024-06-29T15:48:48.753Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "2021って何やってたっけ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807078721788232081",
            "createdAt" : "2024-06-29T15:48:35.870Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "2021くらいまでは結構みてたかも",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807078648677294265",
            "createdAt" : "2024-06-29T15:48:18.437Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "むかしは結構見てたおれも",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807078550190825817",
            "createdAt" : "2024-06-29T15:47:54.946Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あーー",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807078512349860052",
            "createdAt" : "2024-06-29T15:47:45.938Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "アニメは好き",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807078417625739613",
            "createdAt" : "2024-06-29T15:47:23.351Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "最近は何が好き❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807078088188305668",
            "createdAt" : "2024-06-29T15:46:04.813Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "agree",
                "eventId" : "1807078094253285376",
                "createdAt" : "2024-06-29T15:46:06.224Z"
              }
            ],
            "urls" : [ ],
            "text" : "いいですね‼️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807078050678661622",
            "createdAt" : "2024-06-29T15:45:55.857Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "それはそう。好きを追求してる人っていいよね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807077946194309487",
            "createdAt" : "2024-06-29T15:45:30.946Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "オタク好き",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807077797678223841",
            "createdAt" : "2024-06-29T15:44:55.536Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "まだゲームは作りたいけど笑",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807077763880546789",
            "createdAt" : "2024-06-29T15:44:47.484Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "けど最近そこまででもないぞって気づいた",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807077728518373854",
            "createdAt" : "2024-06-29T15:44:39.103Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "昔はそう思ってた。ゲームクリエイターになりたいほど。",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807077695081349388",
            "createdAt" : "2024-06-29T15:44:31.079Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "7さんってゲームオタク❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807077277454500227",
            "createdAt" : "2024-06-29T15:42:51.508Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [
              {
                "senderId" : "1117358395969814529",
                "reactionKey" : "agree",
                "eventId" : "1807077239328321536",
                "createdAt" : "2024-06-29T15:42:42.410Z"
              }
            ],
            "urls" : [ ],
            "text" : "弁明可能な誤字でよかった",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807077216238625283",
            "createdAt" : "2024-06-29T15:42:36.912Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "それは悲しいですね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807077087830069617",
            "createdAt" : "2024-06-29T15:42:06.298Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あわあわ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807077030540013922",
            "createdAt" : "2024-06-29T15:41:52.635Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "って打とうとして色んな意味で誤字って焦ったっていう笑",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807076907579785612",
            "createdAt" : "2024-06-29T15:41:23.320Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ゲームで汗かくのなんてリングフィットぐらいだと思ってた",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807076887824646268",
            "createdAt" : "2024-06-29T15:41:18.616Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "でこれは何?",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807076496680575103",
            "createdAt" : "2024-06-29T15:39:45.359Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "気をつけてください❗️",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807076396826861809",
            "createdAt" : "2024-06-29T15:39:21.565Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "気をつけよ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807076335065735340",
            "createdAt" : "2024-06-29T15:39:06.824Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "LINEの使いすぎだった",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807076209366536434",
            "createdAt" : "2024-06-29T15:38:36.854Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "dmで失言したら終わるらしい",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807076207210774571",
            "createdAt" : "2024-06-29T15:38:36.339Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "できないよ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807076134053687571",
            "createdAt" : "2024-06-29T15:38:18.895Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "これって送信取り消しできるん？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807076091720556909",
            "createdAt" : "2024-06-29T15:38:08.801Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "落ち着いて",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807076088709067114",
            "createdAt" : "2024-06-29T15:38:08.093Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807076023529550111",
            "createdAt" : "2024-06-29T15:37:52.542Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "待てミスった",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807076016390889713",
            "createdAt" : "2024-06-29T15:37:50.850Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "スポーツで汗駆の",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807075942084600160",
            "createdAt" : "2024-06-29T15:37:33.123Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "実際汗ダラダラになるくらいには疲れるし",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807075634604298740",
            "createdAt" : "2024-06-29T15:36:19.818Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "最初は音に合わせて叩くの楽しい❗️みたいな感覚だけど今はスポーツみたいな感覚",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807075573401096690",
            "createdAt" : "2024-06-29T15:36:05.226Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "なるほど…やっぱ音ゲーは突き詰めると大変そうだ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807075334438998213",
            "createdAt" : "2024-06-29T15:35:08.266Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "指高速で動かすとか",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807075135146651945",
            "createdAt" : "2024-06-29T15:34:20.743Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "指5本以上使うとなるとトレーニング必要かも",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807074929831190649",
            "createdAt" : "2024-06-29T15:33:31.799Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "いまだに空きなくてすごい",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807074727380549884",
            "createdAt" : "2024-06-29T15:32:43.535Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "音ゲーってけっこう指捌き的ななんかが関わってくるの？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807074671717962006",
            "createdAt" : "2024-06-29T15:32:30.255Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/On0yMcMnKd",
                "expanded" : "https://twitter.com/messages/media/1807074653044883607",
                "display" : "pic.twitter.com/On0yMcMnKd"
              }
            ],
            "text" : "こう言う指5本使うやつとかね https://t.co/On0yMcMnKd",
            "mediaUrls" : [
              "https://ton.twitter.com/dm/1807074653044883607/1807074609562554368/-HWRksEc.jpg"
            ],
            "senderId" : "1117358395969814529",
            "id" : "1807074653044883607",
            "createdAt" : "2024-06-29T15:32:25.849Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ピアノやってなかったのがデメリットになる段階きてる今",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807074422278520966",
            "createdAt" : "2024-06-29T15:31:30.779Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "熱中ってすごいね…！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807074410651902382",
            "createdAt" : "2024-06-29T15:31:28.012Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "2年ないくらいで",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807074228291965291",
            "createdAt" : "2024-06-29T15:30:44.529Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "すっげえ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807074188026626100",
            "createdAt" : "2024-06-29T15:30:34.927Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "10万以上積んでるからね〜",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807074119093277165",
            "createdAt" : "2024-06-29T15:30:18.492Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ちょっとだけやってた",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807074066240836078",
            "createdAt" : "2024-06-29T15:30:05.895Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ピアノとかできる？",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807074017603686583",
            "createdAt" : "2024-06-29T15:29:54.320Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "できる人尊敬",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807074012704702916",
            "createdAt" : "2024-06-29T15:29:53.131Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "私逆に音ゲー苦手かも",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807073978839924889",
            "createdAt" : "2024-06-29T15:29:45.055Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "音楽ゲームしかやってない😥",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807073822979579938",
            "createdAt" : "2024-06-29T15:29:07.892Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "知らないな〜",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807073728335126594",
            "createdAt" : "2024-06-29T15:28:45.328Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "最近はティアキンやってるよ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807073641747894431",
            "createdAt" : "2024-06-29T15:28:24.689Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ゲーム何してるの?",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807073473958912197",
            "createdAt" : "2024-06-29T15:27:44.707Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "深夜テンションとか言うやつ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807072719579881572",
            "createdAt" : "2024-06-29T15:24:44.825Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "言ってみたくなった",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807072689645068378",
            "createdAt" : "2024-06-29T15:24:37.690Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "うお、どうした！？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1807072594274947221",
            "createdAt" : "2024-06-29T15:24:14.954Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "77777777777777",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1807072205580509388",
            "createdAt" : "2024-06-29T15:22:42.280Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "agree",
                "eventId" : "1802270151510994944",
                "createdAt" : "2024-06-16T09:21:03.347Z"
              }
            ],
            "urls" : [ ],
            "text" : "けど確証ないので実質知らないのと同じです",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1802269791610392940",
            "createdAt" : "2024-06-16T09:19:37.558Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "この人かもしれないってのは一人いる",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1802268843039211595",
            "createdAt" : "2024-06-16T09:15:51.401Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "私的にはそれはそれで全然いいね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1802266256109973512",
            "createdAt" : "2024-06-16T09:05:34.627Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "わかりませんね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1802260959115034699",
            "createdAt" : "2024-06-16T08:44:31.732Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "んー",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1802260753900245254",
            "createdAt" : "2024-06-16T08:43:42.798Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "3つしか開けてないよ",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1802251065091350871",
            "createdAt" : "2024-06-16T08:05:12.811Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ピアス結構開けてる人?",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1802233008155705740",
            "createdAt" : "2024-06-16T06:53:27.700Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "わかりました",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1802232080123957579",
            "createdAt" : "2024-06-16T06:49:46.441Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "なるほど",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1802231892449927546",
            "createdAt" : "2024-06-16T06:49:01.697Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "健康論入ってるのに木5にいれたので、変えてくださいって言われて木2",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1802220917067796919",
            "createdAt" : "2024-06-16T06:05:24.964Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "俺元々、木5でしたよ",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1802220738264580201",
            "createdAt" : "2024-06-16T06:04:42.331Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "最初は木2にしようとしててギリギリで木5に変えたんだよな…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1802219688950370335",
            "createdAt" : "2024-06-16T06:00:32.152Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "discordの木2の選中のとこにいたからそうかと思ってた",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1802215727426105583",
            "createdAt" : "2024-06-16T05:44:47.663Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "違うんかい",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1802215268305039373",
            "createdAt" : "2024-06-16T05:42:58.197Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "じゃあ違うね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1802213162760216713",
            "createdAt" : "2024-06-16T05:34:36.188Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "木2",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1802207939325010113",
            "createdAt" : "2024-06-16T05:13:50.821Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "え、何限？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1802207241153741197",
            "createdAt" : "2024-06-16T05:11:04.367Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "てか、選択中国の方が同じかもしれないらしい",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1802083671589130596",
            "createdAt" : "2024-06-15T21:00:03.089Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "surprised",
                "eventId" : "1800012052825866240",
                "createdAt" : "2024-06-10T03:48:10.681Z"
              }
            ],
            "urls" : [ ],
            "text" : "じゃあ違うらしい",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1800011429745205332",
            "createdAt" : "2024-06-10T03:45:42.140Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "違う",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1800009852359757952",
            "createdAt" : "2024-06-10T03:39:26.055Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "二限？",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1800005765744509240",
            "createdAt" : "2024-06-10T03:23:11.728Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "だけど時間違うかも",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1800004392684573098",
            "createdAt" : "2024-06-10T03:17:44.378Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "俺も鷲巣らしい",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1799982096867635677",
            "createdAt" : "2024-06-10T01:49:08.641Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [
              {
                "senderId" : "1117358395969814529",
                "reactionKey" : "funny",
                "eventId" : "1798345279466602496",
                "createdAt" : "2024-06-05T13:25:00.930Z"
              }
            ],
            "urls" : [ ],
            "text" : "大丈夫です",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1798340970641326268",
            "createdAt" : "2024-06-05T13:07:53.647Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ごめんなさい🙏",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1798340655544258892",
            "createdAt" : "2024-06-05T13:06:38.519Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "！？！？こわ！？",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1798340482767974616",
            "createdAt" : "2024-06-05T13:05:57.332Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "適当に言ったらあたってもうた",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1798340192346284198",
            "createdAt" : "2024-06-05T13:04:48.086Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "…そうですけど😨",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1798339908437979231",
            "createdAt" : "2024-06-05T13:03:40.395Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "必修鷲巣❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1798339542757605859",
            "createdAt" : "2024-06-05T13:02:13.216Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "そうです",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1798339324397969511",
            "createdAt" : "2024-06-05T13:01:21.154Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あなたもしかして中国語選択❓",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1798339261621743662",
            "createdAt" : "2024-06-05T13:01:06.195Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [
              {
                "senderId" : "1117358395969814529",
                "reactionKey" : "funny",
                "eventId" : "1798339126741401600",
                "createdAt" : "2024-06-05T13:00:34.014Z"
              }
            ],
            "urls" : [ ],
            "text" : "教えてくれてありがとうございましたw",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1798338917114266042",
            "createdAt" : "2024-06-05T12:59:44.046Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "流石にビビりました",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1798338422349922621",
            "createdAt" : "2024-06-05T12:57:46.086Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ですよね",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1798338390137639332",
            "createdAt" : "2024-06-05T12:57:38.418Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1117358395969814529",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あー…垢ミスってますねwww",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1798338217143582726",
            "createdAt" : "2024-06-05T12:56:57.161Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "なんかいいね欄に異様なものが混じってますけど大丈夫ですか？",
            "mediaUrls" : [ ],
            "senderId" : "1117358395969814529",
            "id" : "1798308724085506423",
            "createdAt" : "2024-06-05T10:59:45.466Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1765218063530815488-1765658836759957505",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "なるなる",
            "mediaUrls" : [ ],
            "senderId" : "1765218063530815488",
            "id" : "1869031463368446086",
            "createdAt" : "2024-12-17T14:46:40.488Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765218063530815488",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "リサーチ不足だな笑",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1869031420251013461",
            "createdAt" : "2024-12-17T14:46:30.204Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765218063530815488",
            "reactions" : [
              {
                "senderId" : "1765218063530815488",
                "reactionKey" : "emoji",
                "eventId" : "1869031444779274240",
                "createdAt" : "2024-12-17T14:46:36.029Z"
              }
            ],
            "urls" : [ ],
            "text" : "新宿までは全然いい感じだったけど、想定とは違うホームに到着しちゃって",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1869031364848394603",
            "createdAt" : "2024-12-17T14:46:16.997Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "電車なかったらどの道ダメか",
            "mediaUrls" : [ ],
            "senderId" : "1765218063530815488",
            "id" : "1869031081657426225",
            "createdAt" : "2024-12-17T14:45:09.485Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "すまぬ(っ◞‸◟c)\nもうちょい早く歩けばよかったかも。",
            "mediaUrls" : [ ],
            "senderId" : "1765218063530815488",
            "id" : "1869031048782471325",
            "createdAt" : "2024-12-17T14:45:01.675Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765218063530815488",
            "reactions" : [
              {
                "senderId" : "1765218063530815488",
                "reactionKey" : "emoji",
                "eventId" : "1869031135172562944",
                "createdAt" : "2024-12-17T14:45:22.218Z"
              }
            ],
            "urls" : [ ],
            "text" : "でも危なかった笑",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1869030333913686317",
            "createdAt" : "2024-12-17T14:42:11.203Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765218063530815488",
            "reactions" : [
              {
                "senderId" : "1765218063530815488",
                "reactionKey" : "emoji",
                "eventId" : "1869031110682034176",
                "createdAt" : "2024-12-17T14:45:16.371Z"
              }
            ],
            "urls" : [ ],
            "text" : "間に合ったー！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1869030262581133715",
            "createdAt" : "2024-12-17T14:41:54.209Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "終電間に合った？",
            "mediaUrls" : [ ],
            "senderId" : "1765218063530815488",
            "id" : "1869028525132726465",
            "createdAt" : "2024-12-17T14:34:59.969Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ども",
            "mediaUrls" : [ ],
            "senderId" : "1765218063530815488",
            "id" : "1869028488994607131",
            "createdAt" : "2024-12-17T14:34:51.336Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1765658836759957505-1773596084914495488",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "excited",
                "eventId" : "1907310589200019456",
                "createdAt" : "2025-04-02T05:54:15.247Z"
              }
            ],
            "urls" : [ ],
            "text" : "頑張ろう！",
            "mediaUrls" : [ ],
            "senderId" : "1773596084914495488",
            "id" : "1907310463165296690",
            "createdAt" : "2025-04-02T05:53:45.223Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1773596084914495488",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "お互いプロ分けも頑張りましょう！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1907309238361465097",
            "createdAt" : "2025-04-02T05:48:53.216Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1773596084914495488",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "私はメディア情報プログラムです",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1907309191771099354",
            "createdAt" : "2025-04-02T05:48:42.101Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "プログラムはどこを考えてます？\n自分は経営プログラムです",
            "mediaUrls" : [ ],
            "senderId" : "1773596084914495488",
            "id" : "1907288199552184463",
            "createdAt" : "2025-04-02T04:25:17.160Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "あ！\nたしかに同じでした！\n名前みて思い出しました",
            "mediaUrls" : [ ],
            "senderId" : "1773596084914495488",
            "id" : "1907288055435923825",
            "createdAt" : "2025-04-02T04:24:42.806Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1773596084914495488",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "元5クラの佐藤菜々と申します。確かキャリキとかで同じクラスでしたよね？こちらこそよろしくお願いします！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1907279137091518754",
            "createdAt" : "2025-04-02T03:49:16.511Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "はじめまして！\n元6クラスの森といいます\n転類仲間同士これからよろしくお願いしますm(_ _)m",
            "mediaUrls" : [ ],
            "senderId" : "1773596084914495488",
            "id" : "1907267994843333028",
            "createdAt" : "2025-04-02T03:04:59.988Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1765658836759957505-1774740097734422528",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [
              {
                "senderId" : "1765658836759957505",
                "reactionKey" : "sad",
                "eventId" : "1914580254636863488",
                "createdAt" : "2025-04-22T07:21:18.552Z"
              }
            ],
            "urls" : [ ],
            "text" : "すみません急にお願いした自分が悪いです。ご無礼いたしまいた。すみません🙇",
            "mediaUrls" : [ ],
            "senderId" : "1774740097734422528",
            "id" : "1914559034482680074",
            "createdAt" : "2025-04-22T05:56:59.300Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1774740097734422528",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "他の人に当たってみてください…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1914536672815145446",
            "createdAt" : "2025-04-22T04:28:07.863Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1774740097734422528",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "うーん、過去問はサークルの後輩とか、リアルとかでも面識ある人にしかあげてないから、ちょっとごめんなさい…",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1914536169863569601",
            "createdAt" : "2025-04-22T04:26:07.957Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "なるほど、良ければ過去問見せていただけ無いでしょうか？お礼などします！",
            "mediaUrls" : [ ],
            "senderId" : "1774740097734422528",
            "id" : "1914529981407092810",
            "createdAt" : "2025-04-22T04:01:32.504Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1774740097734422528",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "やっとくと、雰囲気は掴めるって感じですね",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1914526650588651847",
            "createdAt" : "2025-04-22T03:48:18.380Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1774740097734422528",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "多かったです笑",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1914526481398816778",
            "createdAt" : "2025-04-22T03:47:38.051Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "結構幅広いんですね過去問ゲーって訳でもない感じですか？",
            "mediaUrls" : [ ],
            "senderId" : "1774740097734422528",
            "id" : "1914523046792298717",
            "createdAt" : "2025-04-22T03:33:59.164Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "やっぱそうですよね授業切ってる人の方が多かったですか？",
            "mediaUrls" : [ ],
            "senderId" : "1774740097734422528",
            "id" : "1914522840990409074",
            "createdAt" : "2025-04-22T03:33:10.111Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1774740097734422528",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "頑張ってください！",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1914520983794540677",
            "createdAt" : "2025-04-22T03:25:47.318Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1774740097734422528",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "ぶっちゃけあの人の字の解読むずすぎなので、数演とか、自習とかで頑張るとかでもいけると思います",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1914520971094188494",
            "createdAt" : "2025-04-22T03:25:44.295Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1774740097734422528",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "去年、前期微積第一では、期末のみのテストでした。\n問題数は少なく、ただ定積分、広義積分を解く問題や、極限求める問題、年によっては〜を示せみたいな問題がでていました。\n比較的簡単なほうではあると思います。",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1914520630093078761",
            "createdAt" : "2025-04-22T03:24:22.978Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1774740097734422528",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "わかりました。覚えてる範囲で教えます。",
            "mediaUrls" : [ ],
            "senderId" : "1765658836759957505",
            "id" : "1914520585188860119",
            "createdAt" : "2025-04-22T03:24:12.278Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1765658836759957505",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "DM失礼します。25生の11クラの者なんですけど、微積の天野先生のテストについて知りたくdmさせてもらいました\n天野先生のテストについて教えて頂けませんか？",
            "mediaUrls" : [ ],
            "senderId" : "1774740097734422528",
            "id" : "1914497436506317264",
            "createdAt" : "2025-04-22T01:52:13.194Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  }
]