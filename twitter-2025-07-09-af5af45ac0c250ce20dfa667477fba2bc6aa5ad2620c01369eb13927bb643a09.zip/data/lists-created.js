window.YTD.lists_created.part0 = [
  {
    "userListInfo" : {
      "url" : "https://twitter.com/joyjoy_7shichi7/lists/1937303839281139787"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/joyjoy_7shichi7/lists/1934287440174584271"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/joyjoy_7shichi7/lists/1908108199368224897"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/joyjoy_7shichi7/lists/1897636380618166680"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/joyjoy_7shichi7/lists/1886232681375261160"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/joyjoy_7shichi7/lists/1886231994000150855"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/joyjoy_7shichi7/lists/1884736668869308747"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/joyjoy_7shichi7/lists/1802622132868018211"
    }
  }
]