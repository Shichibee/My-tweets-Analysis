window.YTD.periscope_account_information.part0 = [
  {
    "periscopeAccountInformation" : {
      "displayName" : "七億円",
      "digitsId" : "",
      "username" : "joyman_7shichi7",
      "twitterId" : "1765658836759957505",
      "id" : "1WgKgPeBRnzjv",
      "twitterScreenName" : "joyjoy_7shichi7",
      "isTwitterUser" : true,
      "createdAt" : "2024-03-09T13:43:40.474584229Z"
    }
  }
]