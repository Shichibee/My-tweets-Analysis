window.YTD.sso.part0 = [
  {
    "singleSignOnMetaValues" : {
      "ssoId" : "112730481636704371858",
      "ssoEmail" : "liqi3452@gmail.com",
      "associationMethodType" : "Signup",
      "createdAt" : "2024-03-07T08:41:03.504Z"
    }
  }
]