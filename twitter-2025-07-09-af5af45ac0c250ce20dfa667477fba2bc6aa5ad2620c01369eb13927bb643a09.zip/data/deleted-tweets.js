window.YTD.deleted_tweets.part0 = [
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1942906084114735478"
          ],
          "editableUntil" : "2025-07-09T12:18:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "56"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1942905757596627240",
      "id_str" : "1942906084114735478",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1942906084114735478",
      "in_reply_to_status_id" : "1942905757596627240",
      "created_at" : "Wed Jul 09 11:18:02 +0000 2025",
      "favorited" : false,
      "full_text" : "普通にモザイクかけようと思ったら、いつも使ってるアプリに新しいぼかし機能できてて使ったら逆にわざとらしくなったな",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505",
      "deleted_at" : "Wed Jul 09 13:06:02 +0000 2025"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1941357724274741289"
          ],
          "editableUntil" : "2025-07-05T05:45:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "103"
      ],
      "favorite_count" : "0",
      "id_str" : "1941357724274741289",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1941357724274741289",
      "created_at" : "Sat Jul 05 04:45:24 +0000 2025",
      "favorited" : false,
      "full_text" : "普段ほんとに政治に興味なくてどねツイートするため投票してるようなもんだから、10人ちょいの選挙公約も全部見きれなかった。(あと探すのむずい)\nあんま考えず投票するのは投票率は上がるが、本当にいいのだろうか。",
      "lang" : "ja",
      "deleted_at" : "Sat Jul 05 04:51:50 +0000 2025"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1941107316130254975"
          ],
          "editableUntil" : "2025-07-04T13:10:22.852Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "七億円",
            "screen_name" : "joyjoy_7shichi7",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "1765658836759957505",
            "id" : "1765658836759957505"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "0",
      "id_str" : "1941107316130254975",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1941107316130254975",
      "created_at" : "Fri Jul 04 12:10:22 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @joyjoy_7shichi7: 全部人身事故！！！どうしてもアタシを帰らせたくないのね！！！",
      "lang" : "ja",
      "deleted_at" : "Fri Jul 04 12:10:25 +0000 2025"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1940904288164929851"
          ],
          "editableUntil" : "2025-07-03T23:43:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "44"
      ],
      "favorite_count" : "0",
      "id_str" : "1940904288164929851",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1940904288164929851",
      "created_at" : "Thu Jul 03 22:43:37 +0000 2025",
      "favorited" : false,
      "full_text" : "去年の今日の日記読んでたら、MOのレポートを実験やったその日に終わらせてたらしくてキモい",
      "lang" : "ja",
      "deleted_at" : "Thu Jul 03 22:44:42 +0000 2025"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1940641704455164328"
          ],
          "editableUntil" : "2025-07-03T06:20:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "47"
      ],
      "favorite_count" : "0",
      "id_str" : "1940641704455164328",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1940641704455164328",
      "created_at" : "Thu Jul 03 05:20:12 +0000 2025",
      "favorited" : false,
      "full_text" : "ほんとはバイトしなきゃだけど学生は勉強すべきだと言ってくれる母親のせいでマジでやる気でねぇーー",
      "lang" : "ja",
      "deleted_at" : "Thu Jul 03 05:20:21 +0000 2025"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1940337114127954074"
          ],
          "editableUntil" : "2025-07-02T10:09:52.385Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "日本スポーツチャンバラ学生連盟",
            "screen_name" : "spochan_univers",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "2439667002",
            "id" : "2439667002"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "68"
      ],
      "favorite_count" : "0",
      "id_str" : "1940337114127954074",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1940337114127954074",
      "created_at" : "Wed Jul 02 09:09:52 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @spochan_univers: 渡辺謙信選手、なんと新人男子小太刀・長剣連覇で今大会打突無敗でした！\nおめでとうございます！！",
      "deleted_at" : "Fri Jul 04 14:46:40 +0000 2025"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1936020261343838261"
          ],
          "editableUntil" : "2025-06-20T12:16:14.478Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "^^🐻‍❄️",
            "screen_name" : "mayrain0930",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "1774609745946738688",
            "id" : "1774609745946738688"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/eQF6ZEGNyA",
            "indices" : [
              "115",
              "138"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "id_str" : "1936020261343838261",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1936020261343838261",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jun 20 11:16:14 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @mayrain0930: 50人分のアンケートを英語の課題で取らなきゃいけないです\n助けてください\n雑にすぐ答えられます\n他学年、他大の方もぜひ🥹🥹\n（イケメンなマクレラン先生と違って簡単に50人も友達集められません🥲）\nhttps://t.co/eQF6ZEGNyA",
      "deleted_at" : "Thu Jun 26 11:19:08 +0000 2025"
    }
  }
]