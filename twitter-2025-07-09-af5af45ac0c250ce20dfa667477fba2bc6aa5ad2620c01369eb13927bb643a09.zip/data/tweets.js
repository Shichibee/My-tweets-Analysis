window.YTD.tweets.part0 = [
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1942905757596627240"
          ],
          "editableUntil" : "2025-07-09T12:16:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1942905757596627240/photo/1",
            "indices" : [
              "11",
              "34"
            ],
            "url" : "https://t.co/uFXxaWW2WA",
            "media_url" : "http://pbs.twimg.com/media/GvaWb5BboAAfjsj.jpg",
            "id_str" : "1942905695164407808",
            "id" : "1942905695164407808",
            "media_url_https" : "https://pbs.twimg.com/media/GvaWb5BboAAfjsj.jpg",
            "sizes" : {
              "medium" : {
                "w" : "850",
                "h" : "1200",
                "resize" : "fit"
              },
              "small" : {
                "w" : "481",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "999",
                "h" : "1411",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/uFXxaWW2WA"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "12",
      "id_str" : "1942905757596627240",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1942905757596627240",
      "possibly_sensitive" : false,
      "created_at" : "Wed Jul 09 11:16:44 +0000 2025",
      "favorited" : false,
      "full_text" : "これどうやってけすの https://t.co/uFXxaWW2WA",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1942905757596627240/photo/1",
            "indices" : [
              "11",
              "34"
            ],
            "url" : "https://t.co/uFXxaWW2WA",
            "media_url" : "http://pbs.twimg.com/media/GvaWb5BboAAfjsj.jpg",
            "id_str" : "1942905695164407808",
            "id" : "1942905695164407808",
            "media_url_https" : "https://pbs.twimg.com/media/GvaWb5BboAAfjsj.jpg",
            "sizes" : {
              "medium" : {
                "w" : "850",
                "h" : "1200",
                "resize" : "fit"
              },
              "small" : {
                "w" : "481",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "999",
                "h" : "1411",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/uFXxaWW2WA"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1942353658546737652"
          ],
          "editableUntil" : "2025-07-07T23:42:54.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "13"
      ],
      "favorite_count" : "0",
      "id_str" : "1942353658546737652",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1942353658546737652",
      "created_at" : "Mon Jul 07 22:42:54 +0000 2025",
      "favorited" : false,
      "full_text" : "Twitterアプリ消す車",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1942048891983290668"
          ],
          "editableUntil" : "2025-07-07T03:31:52.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "6",
      "id_str" : "1942048891983290668",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1942048891983290668",
      "created_at" : "Mon Jul 07 02:31:52 +0000 2025",
      "favorited" : false,
      "full_text" : "色欲って言ってんのかと思ってたら主記憶だった。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1941873640578191404"
          ],
          "editableUntil" : "2025-07-06T15:55:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "0",
      "id_str" : "1941873640578191404",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1941873640578191404",
      "created_at" : "Sun Jul 06 14:55:28 +0000 2025",
      "favorited" : false,
      "full_text" : "ろっぱでじぇらってるようじゃなおさらね。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1941873515898298479"
          ],
          "editableUntil" : "2025-07-06T15:54:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "75"
      ],
      "favorite_count" : "3",
      "id_str" : "1941873515898298479",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1941873515898298479",
      "created_at" : "Sun Jul 06 14:54:59 +0000 2025",
      "favorited" : false,
      "full_text" : "所属してるだけで強制的に技術が向上しそうで素晴らしいサークルってかんじだけど、私あたりはじぇらしーを感じて吐きそうになるだろうから入ってなくて良かった",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1941783698627846640"
          ],
          "editableUntil" : "2025-07-06T09:58:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/5gHv2vXjfV",
            "expanded_url" : "https://youtu.be/OodEsjZ88TQ?si=ANd4tdgAOKsV8FH5",
            "display_url" : "youtu.be/OodEsjZ88TQ?si…",
            "indices" : [
              "42",
              "65"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "2",
      "id_str" : "1941783698627846640",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1941783698627846640",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jul 06 08:58:05 +0000 2025",
      "favorited" : false,
      "full_text" : "今日もマックはかっこいい洋楽流してるな〜って思ってたら藤井風かい笑。かっこいいな〜\nhttps://t.co/5gHv2vXjfV",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1941510409305063663"
          ],
          "editableUntil" : "2025-07-05T15:52:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "13"
      ],
      "favorite_count" : "2",
      "id_str" : "1941510409305063663",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1941510409305063663",
      "created_at" : "Sat Jul 05 14:52:07 +0000 2025",
      "favorited" : false,
      "full_text" : "サークルの人たちびっぐらぶ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1941359559999881261"
          ],
          "editableUntil" : "2025-07-05T05:52:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "4",
      "id_str" : "1941359559999881261",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1941359559999881261",
      "created_at" : "Sat Jul 05 04:52:42 +0000 2025",
      "favorited" : false,
      "full_text" : "政治関係と野球関係と宗教関係の話は出さないほうが良いとされており、ツイ消し",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1941354479041085777"
          ],
          "editableUntil" : "2025-07-05T05:32:31.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "7"
      ],
      "favorite_count" : "4",
      "id_str" : "1941354479041085777",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1941354479041085777",
      "created_at" : "Sat Jul 05 04:32:31 +0000 2025",
      "favorited" : false,
      "full_text" : "期日前投票どね",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1941084594138402995"
          ],
          "editableUntil" : "2025-07-04T11:40:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "3",
      "id_str" : "1941084594138402995",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1941084594138402995",
      "created_at" : "Fri Jul 04 10:40:05 +0000 2025",
      "favorited" : false,
      "full_text" : "全部人身事故！！！どうしてもアタシを帰らせたくないのね！！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1941081636734656874"
          ],
          "editableUntil" : "2025-07-04T11:28:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "1",
      "id_str" : "1941081636734656874",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1941081636734656874",
      "created_at" : "Fri Jul 04 10:28:20 +0000 2025",
      "favorited" : false,
      "full_text" : "ちなみに我々の世代のメンバーは1人も賞取れなかったっていう()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1941074704061829591"
          ],
          "editableUntil" : "2025-07-04T11:00:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "2",
      "id_str" : "1941074704061829591",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1941074704061829591",
      "created_at" : "Fri Jul 04 10:00:47 +0000 2025",
      "favorited" : false,
      "full_text" : "高校の写真部の子たちが3人も賞取ってて嬉しい。この子たち私が勧誘したんだよな〜",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1940611692721066169"
          ],
          "editableUntil" : "2025-07-03T04:20:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "13"
      ],
      "favorite_count" : "1",
      "id_str" : "1940611692721066169",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1940611692721066169",
      "created_at" : "Thu Jul 03 03:20:57 +0000 2025",
      "favorited" : false,
      "full_text" : "私の今日の装い仮装大会()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1940570511295307823"
          ],
          "editableUntil" : "2025-07-03T01:37:18.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "9"
      ],
      "favorite_count" : "1",
      "id_str" : "1940570511295307823",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1940570511295307823",
      "created_at" : "Thu Jul 03 00:37:18 +0000 2025",
      "favorited" : false,
      "full_text" : "誰だブックマーク笑",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1940412380493832662"
          ],
          "editableUntil" : "2025-07-02T15:08:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "57"
      ],
      "favorite_count" : "14",
      "id_str" : "1940412380493832662",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1940412380493832662",
      "created_at" : "Wed Jul 02 14:08:57 +0000 2025",
      "favorited" : false,
      "full_text" : "なんか今年見る数演の点数が去年より低めな人しかいない気がする。\nというか、24生が自慢したがり屋さんだったのかな…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1940410571536679170"
          ],
          "editableUntil" : "2025-07-02T15:01:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "1",
      "id_str" : "1940410571536679170",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1940410571536679170",
      "created_at" : "Wed Jul 02 14:01:45 +0000 2025",
      "favorited" : false,
      "full_text" : "昨日のわけわからん打撲が今さら痛みだした。なぜ今？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1940291881789006028"
          ],
          "editableUntil" : "2025-07-02T07:10:08.155Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "電気通信大学",
            "screen_name" : "uectokyo",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "368206211",
            "id" : "368206211"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/nEQYmSYteG",
            "expanded_url" : "https://www.uec.ac.jp/news/prize/2025/20250702_7066.html",
            "display_url" : "uec.ac.jp/news/prize/202…",
            "indices" : [
              "84",
              "107"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "107"
      ],
      "favorite_count" : "0",
      "id_str" : "1940291881789006028",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1940291881789006028",
      "possibly_sensitive" : false,
      "created_at" : "Wed Jul 02 06:10:08 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uectokyo: UECスポーツチャンバラ同好会の渡辺謙信さん（Ⅰ類（情報系）１年）、狗飼倫太郎さん（Ⅱ類（融合系）１年）が第30回春季関東学生大会にて入賞\nhttps://t.co/nEQYmSYteG",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1940182794006929497"
          ],
          "editableUntil" : "2025-07-01T23:56:39.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "1",
      "id_str" : "1940182794006929497",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1940182794006929497",
      "created_at" : "Tue Jul 01 22:56:39 +0000 2025",
      "favorited" : false,
      "full_text" : "ツイートすることで忘れなくなるというライフハック",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1940182660904886706"
          ],
          "editableUntil" : "2025-07-01T23:56:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "0",
      "id_str" : "1940182660904886706",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1940182660904886706",
      "created_at" : "Tue Jul 01 22:56:07 +0000 2025",
      "favorited" : false,
      "full_text" : "自分で日にち決めたのに今日の部会忘れそう()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1940060363640512728"
          ],
          "editableUntil" : "2025-07-01T15:50:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "いな",
            "screen_name" : "ina_uec24",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1771568167615414272",
            "id" : "1771568167615414272"
          },
          {
            "name" : "琥珀",
            "screen_name" : "mezase_kenzenn",
            "indices" : [
              "11",
              "26"
            ],
            "id_str" : "1570697638068252674",
            "id" : "1570697638068252674"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "41"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1940060098698911911",
      "id_str" : "1940060363640512728",
      "in_reply_to_user_id" : "1771568167615414272",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1940060363640512728",
      "in_reply_to_status_id" : "1940060098698911911",
      "created_at" : "Tue Jul 01 14:50:09 +0000 2025",
      "favorited" : false,
      "full_text" : "@ina_uec24 @mezase_kenzenn そうか…\n晒したのはすまない",
      "lang" : "ja",
      "in_reply_to_screen_name" : "ina_uec24",
      "in_reply_to_user_id_str" : "1771568167615414272"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1940060187106451617"
          ],
          "editableUntil" : "2025-07-01T15:49:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "琥珀",
            "screen_name" : "mezase_kenzenn",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1570697638068252674",
            "id" : "1570697638068252674"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1940059737057533992",
      "id_str" : "1940060187106451617",
      "in_reply_to_user_id" : "1570697638068252674",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1940060187106451617",
      "in_reply_to_status_id" : "1940059737057533992",
      "created_at" : "Tue Jul 01 14:49:27 +0000 2025",
      "favorited" : false,
      "full_text" : "@mezase_kenzenn いやだって同時に来たらおもろいもん笑",
      "lang" : "ja",
      "in_reply_to_screen_name" : "mezase_kenzenn",
      "in_reply_to_user_id_str" : "1570697638068252674"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1940060006176768311"
          ],
          "editableUntil" : "2025-07-01T15:48:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "琥珀",
            "screen_name" : "mezase_kenzenn",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1570697638068252674",
            "id" : "1570697638068252674"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1940059533948441087",
      "id_str" : "1940060006176768311",
      "in_reply_to_user_id" : "1570697638068252674",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1940060006176768311",
      "in_reply_to_status_id" : "1940059533948441087",
      "created_at" : "Tue Jul 01 14:48:44 +0000 2025",
      "favorited" : false,
      "full_text" : "@mezase_kenzenn そうなの？ならまあ良くないかもだけどよかった",
      "lang" : "ja",
      "in_reply_to_screen_name" : "mezase_kenzenn",
      "in_reply_to_user_id_str" : "1570697638068252674"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1940058765795213422"
          ],
          "editableUntil" : "2025-07-01T15:43:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "11"
      ],
      "favorite_count" : "0",
      "id_str" : "1940058765795213422",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1940058765795213422",
      "created_at" : "Tue Jul 01 14:43:48 +0000 2025",
      "favorited" : false,
      "full_text" : "ムーブミスったか？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1940031606900892062"
          ],
          "editableUntil" : "2025-07-01T13:55:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "4",
      "id_str" : "1940031606900892062",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1940031606900892062",
      "created_at" : "Tue Jul 01 12:55:53 +0000 2025",
      "favorited" : false,
      "full_text" : "電車に乗ってる女子大生が「持ち込み不可のテストって初めてで…」って言ってて()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1939327164983505122"
          ],
          "editableUntil" : "2025-06-29T15:16:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/qqyTYoPZJD",
            "expanded_url" : "https://youtu.be/0pGOFX1D_jg?si=w64PkWlNmMtNnM7F",
            "display_url" : "youtu.be/0pGOFX1D_jg?si…",
            "indices" : [
              "31",
              "54"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "54"
      ],
      "favorite_count" : "0",
      "id_str" : "1939327164983505122",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1939327164983505122",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jun 29 14:16:41 +0000 2025",
      "favorited" : false,
      "full_text" : "「Lave Me Do」 聴くとミッフィーちゃんの曲思い出す\nhttps://t.co/qqyTYoPZJD",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1939326152864305572"
          ],
          "editableUntil" : "2025-06-29T15:12:40.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "68"
      ],
      "favorite_count" : "0",
      "id_str" : "1939326152864305572",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1939326152864305572",
      "created_at" : "Sun Jun 29 14:12:40 +0000 2025",
      "favorited" : false,
      "full_text" : "最近同じ邦楽のプレイリストしか聴いてなくて飽きちゃったから、beatles聴いたらマジで良い。大体の曲が街かテレビかで聴いたことあるし。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1939288188494975028"
          ],
          "editableUntil" : "2025-06-29T12:41:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "0",
      "id_str" : "1939288188494975028",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1939288188494975028",
      "created_at" : "Sun Jun 29 11:41:49 +0000 2025",
      "favorited" : false,
      "full_text" : "私以外の出場者はどこかしらで一回は勝ってるのにな",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1939286736850530446"
          ],
          "editableUntil" : "2025-06-29T12:36:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "3",
      "id_str" : "1939286736850530446",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1939286736850530446",
      "created_at" : "Sun Jun 29 11:36:02 +0000 2025",
      "favorited" : false,
      "full_text" : "試合はだめだめだしさーやばいよーこの1年何の成果もなかったー",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1939286568625459609"
          ],
          "editableUntil" : "2025-06-29T12:35:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "6",
      "id_str" : "1939286568625459609",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1939286568625459609",
      "created_at" : "Sun Jun 29 11:35:22 +0000 2025",
      "favorited" : false,
      "full_text" : "待って時間経って考えたらおれ1人で✨キラキラ女子大生✨に混じってインスタのリールに出演する可能性あるのやばいのでは…？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1939101807596445764"
          ],
          "editableUntil" : "2025-06-29T00:21:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "1",
      "id_str" : "1939101807596445764",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1939101807596445764",
      "created_at" : "Sat Jun 28 23:21:12 +0000 2025",
      "favorited" : false,
      "full_text" : "今ツイートしたところで誰も起きてないんだよな()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1939101206254845994"
          ],
          "editableUntil" : "2025-06-29T00:18:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "1",
      "id_str" : "1939101206254845994",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1939101206254845994",
      "created_at" : "Sat Jun 28 23:18:48 +0000 2025",
      "favorited" : false,
      "full_text" : "てか私も希望ヶ丘で男子の応援したい！！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1939101099467911474"
          ],
          "editableUntil" : "2025-06-29T00:18:23.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "36"
      ],
      "favorite_count" : "0",
      "id_str" : "1939101099467911474",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1939101099467911474",
      "created_at" : "Sat Jun 28 23:18:23 +0000 2025",
      "favorited" : false,
      "full_text" : "ぜんぶまけちゃったらはずかしいのでオリセン午後応援はふたりくらいでいいよ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1938484727746597210"
          ],
          "editableUntil" : "2025-06-27T07:29:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "1",
      "id_str" : "1938484727746597210",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1938484727746597210",
      "created_at" : "Fri Jun 27 06:29:09 +0000 2025",
      "favorited" : false,
      "full_text" : "さっき引いたばっかのガチャガチャがTLに流れてきた",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1938250571930370291"
          ],
          "editableUntil" : "2025-06-26T15:58:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "2",
      "id_str" : "1938250571930370291",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1938250571930370291",
      "created_at" : "Thu Jun 26 14:58:41 +0000 2025",
      "favorited" : false,
      "full_text" : "待って！！！痩せた！！！\nほぼ何も食ってないみたいなもんだもんね笑",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1914686735164039653"
          ],
          "editableUntil" : "2025-04-22T15:24:25.479Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1914678199667318967/photo/1",
            "source_status_id" : "1914678199667318967",
            "indices" : [
              "98",
              "121"
            ],
            "url" : "https://t.co/3lsNNnGuy5",
            "media_url" : "http://pbs.twimg.com/media/GpJNrQvakAArn9K.jpg",
            "id_str" : "1914678197209436160",
            "source_user_id" : "1624283203870801920",
            "id" : "1914678197209436160",
            "media_url_https" : "https://pbs.twimg.com/media/GpJNrQvakAArn9K.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1080",
                "h" : "1080",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1080",
                "h" : "1080",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1914678199667318967",
            "display_url" : "pic.x.com/3lsNNnGuy5"
          }
        ],
        "hashtags" : [
          {
            "text" : "uec25",
            "indices" : [
              "80",
              "86"
            ]
          },
          {
            "text" : "スポーツチャンバラ",
            "indices" : [
              "87",
              "97"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "121"
      ],
      "favorite_count" : "0",
      "id_str" : "1914686735164039653",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1914686735164039653",
      "possibly_sensitive" : false,
      "created_at" : "Tue Apr 22 14:24:25 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 【お知らせ】\n現時点で18名の方が入部してくれました✨\n2年生以上の方も大歓迎です！\n一緒にスポチャン楽しみましょう😊⚔️\n#uec25\n#スポーツチャンバラ https://t.co/3lsNNnGuy5",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1914678199667318967/photo/1",
            "source_status_id" : "1914678199667318967",
            "indices" : [
              "98",
              "121"
            ],
            "url" : "https://t.co/3lsNNnGuy5",
            "media_url" : "http://pbs.twimg.com/media/GpJNrQvakAArn9K.jpg",
            "id_str" : "1914678197209436160",
            "source_user_id" : "1624283203870801920",
            "id" : "1914678197209436160",
            "media_url_https" : "https://pbs.twimg.com/media/GpJNrQvakAArn9K.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1080",
                "h" : "1080",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1080",
                "h" : "1080",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1914678199667318967",
            "display_url" : "pic.x.com/3lsNNnGuy5"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1914432582240047477"
          ],
          "editableUntil" : "2025-04-21T22:34:30.700Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1914432582240047477",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1914432582240047477",
      "created_at" : "Mon Apr 21 21:34:30 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: スポーツチャンバラ同好会では例年\n9月にスポチャン合宿、2月にスキー合宿に行っていて、休日にバーベキューをしたりお食事会などあります。大学生らしくワイワイしたい人はぜひ！今日も第二体育館で16:30〜18:00で体験会を行います。皆さんの参加…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1914257141604749724"
          ],
          "editableUntil" : "2025-04-21T10:57:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "3",
      "in_reply_to_status_id_str" : "1914256920527135004",
      "id_str" : "1914257141604749724",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1914257141604749724",
      "in_reply_to_status_id" : "1914256920527135004",
      "created_at" : "Mon Apr 21 09:57:22 +0000 2025",
      "favorited" : false,
      "full_text" : "あ、知ってる曲も知らない曲も楽しかったです",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1914256920527135004"
          ],
          "editableUntil" : "2025-04-21T10:56:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "5",
      "id_str" : "1914256920527135004",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1914256920527135004",
      "created_at" : "Mon Apr 21 09:56:29 +0000 2025",
      "favorited" : false,
      "full_text" : "若者だらけのライブにぽつんといるおばさんの気持ちを先行体験するなど。1年のうちに行くべきだったね。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1914115532372287824"
          ],
          "editableUntil" : "2025-04-21T01:34:40.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "1",
      "id_str" : "1914115532372287824",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1914115532372287824",
      "created_at" : "Mon Apr 21 00:34:40 +0000 2025",
      "favorited" : false,
      "full_text" : "コミケ公開30分で爆速提出したけど、速すぎは色々良くない気がしてきてあせあせ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1913987935634116984"
          ],
          "editableUntil" : "2025-04-20T17:07:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "1",
      "id_str" : "1913987935634116984",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1913987935634116984",
      "created_at" : "Sun Apr 20 16:07:38 +0000 2025",
      "favorited" : false,
      "full_text" : "マグネットジェルネイルのやり方分からんすぎて、マグネットの効果使う前に硬化しちゃった。ておくれ。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1913955155973967888"
          ],
          "editableUntil" : "2025-04-20T14:57:23.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "76"
      ],
      "favorite_count" : "1",
      "id_str" : "1913955155973967888",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1913955155973967888",
      "created_at" : "Sun Apr 20 13:57:23 +0000 2025",
      "favorited" : false,
      "full_text" : "ライブだと、手拍子とか、手振るやつとか、みんなに合わせなきゃって考えてばかりで本来聴くべき音楽、演出に集中できないのが自分の良くないところだなって思う。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1913746127591248165"
          ],
          "editableUntil" : "2025-04-20T01:06:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "1",
      "id_str" : "1913746127591248165",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1913746127591248165",
      "created_at" : "Sun Apr 20 00:06:47 +0000 2025",
      "favorited" : false,
      "full_text" : "最近元々入ってたサークルのディスコも改造して使いやすくなってたし、ディスコって使いやすいのではと気付き始めた…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1913745520595722672"
          ],
          "editableUntil" : "2025-04-20T01:04:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "2",
      "id_str" : "1913745520595722672",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1913745520595722672",
      "created_at" : "Sun Apr 20 00:04:22 +0000 2025",
      "favorited" : false,
      "full_text" : "ポケモンサークルのディスコも最近入ったけど使いやすそうっておもった",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1913745202160058814"
          ],
          "editableUntil" : "2025-04-20T01:03:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "1",
      "id_str" : "1913745202160058814",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1913745202160058814",
      "created_at" : "Sun Apr 20 00:03:06 +0000 2025",
      "favorited" : false,
      "full_text" : "uec25のディスコが活発すぎてすげえ…ってなってきた(部外者なので即脱退)",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1913599006175039783"
          ],
          "editableUntil" : "2025-04-19T15:22:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "15"
      ],
      "favorite_count" : "2",
      "id_str" : "1913599006175039783",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1913599006175039783",
      "created_at" : "Sat Apr 19 14:22:10 +0000 2025",
      "favorited" : false,
      "full_text" : "ゲッタバンバン歌うの楽しすぎた",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1913234815505273075"
          ],
          "editableUntil" : "2025-04-18T15:15:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "26"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1913228590382301533",
      "id_str" : "1913234815505273075",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1913234815505273075",
      "in_reply_to_status_id" : "1913228590382301533",
      "created_at" : "Fri Apr 18 14:15:00 +0000 2025",
      "favorited" : false,
      "full_text" : "なんかこれ人数に八つ当たりするのは違う気がするぞ？笑",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1913228590382301533"
          ],
          "editableUntil" : "2025-04-18T14:50:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "44"
      ],
      "favorite_count" : "6",
      "id_str" : "1913228590382301533",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1913228590382301533",
      "created_at" : "Fri Apr 18 13:50:16 +0000 2025",
      "favorited" : false,
      "full_text" : "なぜ人類はラーメン屋に大人数グループでくるのだろうか。多くて5人くらいじゃないのか？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1913130003883315638"
          ],
          "editableUntil" : "2025-04-18T08:18:31.819Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1913127116226629671/photo/1",
            "source_status_id" : "1913127116226629671",
            "indices" : [
              "76",
              "99"
            ],
            "url" : "https://t.co/D7UHaiSLEX",
            "media_url" : "http://pbs.twimg.com/media/GozK-M_aEAAwUhs.jpg",
            "id_str" : "1913127111713492992",
            "source_user_id" : "1624283203870801920",
            "id" : "1913127111713492992",
            "media_url_https" : "https://pbs.twimg.com/media/GozK-M_aEAAwUhs.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "1320",
                "h" : "729",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "663",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "376",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1913127116226629671",
            "display_url" : "pic.x.com/D7UHaiSLEX"
          }
        ],
        "hashtags" : [
          {
            "text" : "uec25",
            "indices" : [
              "61",
              "67"
            ]
          },
          {
            "text" : "春から電通大",
            "indices" : [
              "68",
              "75"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "99"
      ],
      "favorite_count" : "0",
      "id_str" : "1913130003883315638",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1913130003883315638",
      "possibly_sensitive" : false,
      "created_at" : "Fri Apr 18 07:18:31 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 調布駅周辺のカラオケ屋さんの所感をザックリまとめました！是非参考にしてみてください！\n#uec25\n#春から電通大 https://t.co/D7UHaiSLEX",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1913127116226629671/photo/1",
            "source_status_id" : "1913127116226629671",
            "indices" : [
              "76",
              "99"
            ],
            "url" : "https://t.co/D7UHaiSLEX",
            "media_url" : "http://pbs.twimg.com/media/GozK-M_aEAAwUhs.jpg",
            "id_str" : "1913127111713492992",
            "source_user_id" : "1624283203870801920",
            "id" : "1913127111713492992",
            "media_url_https" : "https://pbs.twimg.com/media/GozK-M_aEAAwUhs.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "1320",
                "h" : "729",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "663",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "376",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1913127116226629671",
            "display_url" : "pic.x.com/D7UHaiSLEX"
          },
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1913127116226629671/photo/1",
            "source_status_id" : "1913127116226629671",
            "indices" : [
              "76",
              "99"
            ],
            "url" : "https://t.co/D7UHaiSLEX",
            "media_url" : "http://pbs.twimg.com/media/GozK-MzawAA337O.jpg",
            "id_str" : "1913127111663206400",
            "source_user_id" : "1624283203870801920",
            "id" : "1913127111663206400",
            "media_url_https" : "https://pbs.twimg.com/media/GozK-MzawAA337O.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "1320",
                "h" : "743",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1913127116226629671",
            "display_url" : "pic.x.com/D7UHaiSLEX"
          },
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1913127116226629671/photo/1",
            "source_status_id" : "1913127116226629671",
            "indices" : [
              "76",
              "99"
            ],
            "url" : "https://t.co/D7UHaiSLEX",
            "media_url" : "http://pbs.twimg.com/media/GozK-MsaAAAuYPh.jpg",
            "id_str" : "1913127111633797120",
            "source_user_id" : "1624283203870801920",
            "id" : "1913127111633797120",
            "media_url_https" : "https://pbs.twimg.com/media/GozK-MsaAAAuYPh.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "681",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "386",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1320",
                "h" : "749",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1913127116226629671",
            "display_url" : "pic.x.com/D7UHaiSLEX"
          },
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1913127116226629671/photo/1",
            "source_status_id" : "1913127116226629671",
            "indices" : [
              "76",
              "99"
            ],
            "url" : "https://t.co/D7UHaiSLEX",
            "media_url" : "http://pbs.twimg.com/media/GozK-MwbYAAq3tG.jpg",
            "id_str" : "1913127111650664448",
            "source_user_id" : "1624283203870801920",
            "id" : "1913127111650664448",
            "media_url_https" : "https://pbs.twimg.com/media/GozK-MwbYAAq3tG.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "1320",
                "h" : "716",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "651",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "369",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1913127116226629671",
            "display_url" : "pic.x.com/D7UHaiSLEX"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1912809659221872907"
          ],
          "editableUntil" : "2025-04-17T11:05:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "62"
      ],
      "favorite_count" : "1",
      "id_str" : "1912809659221872907",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1912809659221872907",
      "created_at" : "Thu Apr 17 10:05:35 +0000 2025",
      "favorited" : false,
      "full_text" : "おいまて、せっかく自力で調べてc#書こうとしてるのにvscodeのAI補完が仕事しまくるんだが。いや、ありがたいんだけどさ…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1912805599194333527"
          ],
          "editableUntil" : "2025-04-17T10:49:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "59"
      ],
      "favorite_count" : "0",
      "id_str" : "1912805599194333527",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1912805599194333527",
      "created_at" : "Thu Apr 17 09:49:27 +0000 2025",
      "favorited" : false,
      "full_text" : "Google検索だけで今作りたいジャンルのゲームの作り方を検索してもヒットしないんだよな。このジャンルまだ早いかもな…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1912805306897469592"
          ],
          "editableUntil" : "2025-04-17T10:48:18.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "73"
      ],
      "favorite_count" : "6",
      "id_str" : "1912805306897469592",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1912805306897469592",
      "created_at" : "Thu Apr 17 09:48:18 +0000 2025",
      "favorited" : false,
      "full_text" : "ﾁｬｯﾋﾟｰに甘えることで、ゲーム制作への心のハードルを下げる\nvs苦しんででも重い腰を上げて、自分でゲーム制作できるようにする\n\nvsダークライ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1912796917911965859"
          ],
          "editableUntil" : "2025-04-17T10:14:57.935Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1912775139269439959/photo/1",
            "source_status_id" : "1912775139269439959",
            "indices" : [
              "51",
              "74"
            ],
            "url" : "https://t.co/HcCYB8CdiK",
            "media_url" : "http://pbs.twimg.com/media/GouK2hEacAEGW9P.jpg",
            "id_str" : "1912775135943356417",
            "source_user_id" : "1624283203870801920",
            "id" : "1912775135943356417",
            "media_url_https" : "https://pbs.twimg.com/media/GouK2hEacAEGW9P.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "medium" : {
                "w" : "535",
                "h" : "532",
                "resize" : "fit"
              },
              "small" : {
                "w" : "535",
                "h" : "532",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "535",
                "h" : "532",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1912775139269439959",
            "display_url" : "pic.x.com/HcCYB8CdiK"
          }
        ],
        "hashtags" : [
          {
            "text" : "uec25",
            "indices" : [
              "36",
              "42"
            ]
          },
          {
            "text" : "春から電通大",
            "indices" : [
              "43",
              "50"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "74"
      ],
      "favorite_count" : "0",
      "id_str" : "1912796917911965859",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1912796917911965859",
      "possibly_sensitive" : false,
      "created_at" : "Thu Apr 17 09:14:57 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: １年生の時にやって良かったこと！\n\n#uec25\n#春から電通大 https://t.co/HcCYB8CdiK",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1912775139269439959/photo/1",
            "source_status_id" : "1912775139269439959",
            "indices" : [
              "51",
              "74"
            ],
            "url" : "https://t.co/HcCYB8CdiK",
            "media_url" : "http://pbs.twimg.com/media/GouK2hEacAEGW9P.jpg",
            "id_str" : "1912775135943356417",
            "source_user_id" : "1624283203870801920",
            "id" : "1912775135943356417",
            "media_url_https" : "https://pbs.twimg.com/media/GouK2hEacAEGW9P.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "medium" : {
                "w" : "535",
                "h" : "532",
                "resize" : "fit"
              },
              "small" : {
                "w" : "535",
                "h" : "532",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "535",
                "h" : "532",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1912775139269439959",
            "display_url" : "pic.x.com/HcCYB8CdiK"
          },
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1912775139269439959/photo/1",
            "source_status_id" : "1912775139269439959",
            "indices" : [
              "51",
              "74"
            ],
            "url" : "https://t.co/HcCYB8CdiK",
            "media_url" : "http://pbs.twimg.com/media/GouK2hhawAA0x0k.jpg",
            "id_str" : "1912775136065011712",
            "source_user_id" : "1624283203870801920",
            "id" : "1912775136065011712",
            "media_url_https" : "https://pbs.twimg.com/media/GouK2hhawAA0x0k.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "medium" : {
                "w" : "530",
                "h" : "537",
                "resize" : "fit"
              },
              "large" : {
                "w" : "530",
                "h" : "537",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "530",
                "h" : "537",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1912775139269439959",
            "display_url" : "pic.x.com/HcCYB8CdiK"
          },
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1912775139269439959/photo/1",
            "source_status_id" : "1912775139269439959",
            "indices" : [
              "51",
              "74"
            ],
            "url" : "https://t.co/HcCYB8CdiK",
            "media_url" : "http://pbs.twimg.com/media/GouK2jeacAMIVDm.jpg",
            "id_str" : "1912775136589279235",
            "source_user_id" : "1624283203870801920",
            "id" : "1912775136589279235",
            "media_url_https" : "https://pbs.twimg.com/media/GouK2jeacAMIVDm.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "small" : {
                "w" : "528",
                "h" : "535",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "528",
                "h" : "535",
                "resize" : "fit"
              },
              "large" : {
                "w" : "528",
                "h" : "535",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1912775139269439959",
            "display_url" : "pic.x.com/HcCYB8CdiK"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1912519802482225361"
          ],
          "editableUntil" : "2025-04-16T15:53:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "41"
      ],
      "favorite_count" : "2",
      "id_str" : "1912519802482225361",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1912519802482225361",
      "created_at" : "Wed Apr 16 14:53:48 +0000 2025",
      "favorited" : false,
      "full_text" : "なんかもっと英語の補習しろっていう誓約書を送らされた()\n7割\"未満\"にしてくれ…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1912390792766976203"
          ],
          "editableUntil" : "2025-04-16T07:21:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "46"
      ],
      "favorite_count" : "1",
      "id_str" : "1912390792766976203",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1912390792766976203",
      "created_at" : "Wed Apr 16 06:21:10 +0000 2025",
      "favorited" : false,
      "full_text" : "前のほうから聞こえた内容を数分後にTwitterでもう一度目にする世界に私は生きているのだ。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1911804931285405881"
          ],
          "editableUntil" : "2025-04-14T16:33:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "11"
      ],
      "favorite_count" : "1",
      "id_str" : "1911804931285405881",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1911804931285405881",
      "created_at" : "Mon Apr 14 15:33:09 +0000 2025",
      "favorited" : false,
      "full_text" : "オタクマシマシだな()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1911804717967265989"
          ],
          "editableUntil" : "2025-04-14T16:32:19.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "ジャンププラス",
            "indices" : [
              "109",
              "117"
            ]
          },
          {
            "text" : "半人前の恋人",
            "indices" : [
              "118",
              "125"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/MJljmRmoAx",
            "expanded_url" : "https://shonenjumpplus.com/app/episode/ew125040",
            "display_url" : "shonenjumpplus.com/app/episode/ew…",
            "indices" : [
              "126",
              "149"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "149"
      ],
      "favorite_count" : "0",
      "id_str" : "1911804717967265989",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1911804717967265989",
      "possibly_sensitive" : false,
      "created_at" : "Mon Apr 14 15:32:19 +0000 2025",
      "favorited" : false,
      "full_text" : "初回全話無料のマンガアプリ「少年ジャンプ＋」で『半人前の恋人』を読んでます！\n\nもうね、電車の中なのに5話ごとにサイレント拍手しまくったよね。本当に素晴らしく美しいものを読ませていただいた。これからも読み続けます。\n #ジャンププラス #半人前の恋人 https://t.co/MJljmRmoAx",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1911731616562725052"
          ],
          "editableUntil" : "2025-04-14T11:41:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "67"
      ],
      "favorite_count" : "1",
      "id_str" : "1911731616562725052",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1911731616562725052",
      "created_at" : "Mon Apr 14 10:41:50 +0000 2025",
      "favorited" : false,
      "full_text" : "2年になって時間増えたから、自分のAI頼りまくりホームページもちょっと変えてみるか。そもそもあんだけ自慢してる類すら変えてないもんな。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1911731012377387102"
          ],
          "editableUntil" : "2025-04-14T11:39:26.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "32"
      ],
      "favorite_count" : "0",
      "id_str" : "1911731012377387102",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1911731012377387102",
      "created_at" : "Mon Apr 14 10:39:26 +0000 2025",
      "favorited" : false,
      "full_text" : "新たなサークルに入ったが、1つの絵文字じゃ表せなくなってきたぞー",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1911629028311933024"
          ],
          "editableUntil" : "2025-04-14T04:54:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "15"
      ],
      "favorite_count" : "2",
      "id_str" : "1911629028311933024",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1911629028311933024",
      "created_at" : "Mon Apr 14 03:54:11 +0000 2025",
      "favorited" : false,
      "full_text" : "空きコマ多すぎて怖くなってくる",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1911425440134181324"
          ],
          "editableUntil" : "2025-04-13T15:25:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "2",
      "id_str" : "1911425440134181324",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1911425440134181324",
      "created_at" : "Sun Apr 13 14:25:12 +0000 2025",
      "favorited" : false,
      "full_text" : "焼き肉したあとの臭いが残るのはさすがに知ってたけど、しゃぶしゃぶしたあとの臭いもしっかり残るんだな…って",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1911316812966621454"
          ],
          "editableUntil" : "2025-04-13T08:13:33.417Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "uec25",
            "indices" : [
              "104",
              "110"
            ]
          },
          {
            "text" : "スポチャン",
            "indices" : [
              "111",
              "117"
            ]
          },
          {
            "text" : "スポーツチャンバラ",
            "indices" : [
              "118",
              "128"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "128"
      ],
      "favorite_count" : "0",
      "id_str" : "1911316812966621454",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1911316812966621454",
      "created_at" : "Sun Apr 13 07:13:33 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 「剣を握ってみたかった」「ちょっと強そうって言われたい」\nそんなあなたに…スポチャン、あります。\n初心者9割！安心して始められるスポーツです！\n見学・体験いつでも大歓迎！\n#uec25 #スポチャン #スポーツチャンバラ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1911300838179684418"
          ],
          "editableUntil" : "2025-04-13T07:10:04.731Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "電通舞研25",
            "indices" : [
              "114",
              "121"
            ]
          },
          {
            "text" : "電通舞研新歓25",
            "indices" : [
              "122",
              "131"
            ]
          },
          {
            "text" : "春から電通大",
            "indices" : [
              "132",
              "139"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "電気通信大学競技ダンス部 新歓アカウント",
            "screen_name" : "uec20ballroom",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1222152454256513024",
            "id" : "1222152454256513024"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1911300838179684418",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1911300838179684418",
      "created_at" : "Sun Apr 13 06:10:04 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uec20ballroom: メンスト新歓実施中です💕\n\nシールラリー最終日ということでネットで大人気⁉️の新歓委員長とスリーショットに成功‼️\n\nモザイクの条件付きで掲載許可ももらったので記念にアップしちゃいます💓\n\n#電通舞研25\n#電通舞研新歓25\n#春から電通大…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1911262548038754584"
          ],
          "editableUntil" : "2025-04-13T04:37:55.650Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1911253493350055998/photo/1",
            "source_status_id" : "1911253493350055998",
            "indices" : [
              "102",
              "125"
            ],
            "url" : "https://t.co/KhOMfGZAMB",
            "media_url" : "http://pbs.twimg.com/media/GoYi6vGWQAIqOlw.jpg",
            "id_str" : "1911253484336201730",
            "source_user_id" : "1624283203870801920",
            "id" : "1911253484336201730",
            "media_url_https" : "https://pbs.twimg.com/media/GoYi6vGWQAIqOlw.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1911253493350055998",
            "display_url" : "pic.x.com/KhOMfGZAMB"
          }
        ],
        "hashtags" : [
          {
            "text" : "uec25",
            "indices" : [
              "76",
              "82"
            ]
          },
          {
            "text" : "春から電通大",
            "indices" : [
              "83",
              "90"
            ]
          },
          {
            "text" : "スポーツチャンバラ",
            "indices" : [
              "91",
              "101"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "125"
      ],
      "favorite_count" : "0",
      "id_str" : "1911262548038754584",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1911262548038754584",
      "possibly_sensitive" : false,
      "created_at" : "Sun Apr 13 03:37:55 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 本日、A201で説明会をしています！！\nスポチャンについて知りたい方や暇な方、雨宿りしたい方はぜひお越しください！\n#uec25\n#春から電通大\n#スポーツチャンバラ https://t.co/KhOMfGZAMB",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1911253493350055998/photo/1",
            "source_status_id" : "1911253493350055998",
            "indices" : [
              "102",
              "125"
            ],
            "url" : "https://t.co/KhOMfGZAMB",
            "media_url" : "http://pbs.twimg.com/media/GoYi6vGWQAIqOlw.jpg",
            "id_str" : "1911253484336201730",
            "source_user_id" : "1624283203870801920",
            "id" : "1911253484336201730",
            "media_url_https" : "https://pbs.twimg.com/media/GoYi6vGWQAIqOlw.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1911253493350055998",
            "display_url" : "pic.x.com/KhOMfGZAMB"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1911053217217253481"
          ],
          "editableUntil" : "2025-04-12T14:46:07.293Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1911011538045112816/video/1",
            "source_status_id" : "1911011538045112816",
            "indices" : [
              "61",
              "84"
            ],
            "url" : "https://t.co/CtaJrvxBAf",
            "media_url" : "http://pbs.twimg.com/amplify_video_thumb/1911011440179183616/img/Fez833DSsGx1tGHb.jpg",
            "id_str" : "1911011440179183616",
            "source_user_id" : "1624283203870801920",
            "id" : "1911011440179183616",
            "media_url_https" : "https://pbs.twimg.com/amplify_video_thumb/1911011440179183616/img/Fez833DSsGx1tGHb.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1911011538045112816",
            "display_url" : "pic.x.com/CtaJrvxBAf"
          }
        ],
        "hashtags" : [
          {
            "text" : "スポーツチャンバラ",
            "indices" : [
              "43",
              "53"
            ]
          },
          {
            "text" : "uec25",
            "indices" : [
              "54",
              "60"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "84"
      ],
      "favorite_count" : "0",
      "id_str" : "1911053217217253481",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1911053217217253481",
      "possibly_sensitive" : false,
      "created_at" : "Sat Apr 12 13:46:07 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: どっちが勝ったでしょう！\n正解は明日の説明会で！\n#スポーツチャンバラ\n#uec25 https://t.co/CtaJrvxBAf",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1911011538045112816/video/1",
            "source_status_id" : "1911011538045112816",
            "indices" : [
              "61",
              "84"
            ],
            "url" : "https://t.co/CtaJrvxBAf",
            "media_url" : "http://pbs.twimg.com/amplify_video_thumb/1911011440179183616/img/Fez833DSsGx1tGHb.jpg",
            "id_str" : "1911011440179183616",
            "video_info" : {
              "aspect_ratio" : [
                "16",
                "9"
              ],
              "duration_millis" : "10573",
              "variants" : [
                {
                  "bitrate" : "2176000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/amplify_video/1911011440179183616/vid/avc1/1280x720/yEK6jga2iDZd8giM.mp4?tag=14"
                },
                {
                  "bitrate" : "288000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/amplify_video/1911011440179183616/vid/avc1/480x270/EuYZzXEGVL_j3PYH.mp4?tag=14"
                },
                {
                  "bitrate" : "832000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/amplify_video/1911011440179183616/vid/avc1/640x360/Il3YU1pgRZYW-Azb.mp4?tag=14"
                },
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/amplify_video/1911011440179183616/pl/fJKZHz3vgV8gpOVI.m3u8?tag=14&v=cfc"
                }
              ]
            },
            "source_user_id" : "1624283203870801920",
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1911011440179183616",
            "media_url_https" : "https://pbs.twimg.com/amplify_video_thumb/1911011440179183616/img/Fez833DSsGx1tGHb.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "source_status_id_str" : "1911011538045112816",
            "display_url" : "pic.x.com/CtaJrvxBAf"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1910900255950070232"
          ],
          "editableUntil" : "2025-04-12T04:38:18.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "63"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1910889053920125284",
      "id_str" : "1910900255950070232",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1910900255950070232",
      "in_reply_to_status_id" : "1910889053920125284",
      "created_at" : "Sat Apr 12 03:38:18 +0000 2025",
      "favorited" : false,
      "full_text" : "サイゼの青豆の温サラダはうまいぞ。オリーブオイルをかけるともっとうまいぞ。ただ、時間ないときに頼んじゃってちょっと後悔したぞ。",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1910889053920125284"
          ],
          "editableUntil" : "2025-04-12T03:53:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "17"
      ],
      "favorite_count" : "0",
      "id_str" : "1910889053920125284",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1910889053920125284",
      "created_at" : "Sat Apr 12 02:53:47 +0000 2025",
      "favorited" : false,
      "full_text" : "土曜お昼どきのサイゼをナメてた()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1910671870921498956"
          ],
          "editableUntil" : "2025-04-11T13:30:47.251Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1910141009641775300/video/1",
            "source_status_id" : "1910141009641775300",
            "indices" : [
              "37",
              "60"
            ],
            "url" : "https://t.co/vAFoQdWRFS",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1910140959335305216/pu/img/hEqU7KMba3vZwsSd.jpg",
            "id_str" : "1910140959335305216",
            "source_user_id" : "1624283203870801920",
            "id" : "1910140959335305216",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1910140959335305216/pu/img/hEqU7KMba3vZwsSd.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1910141009641775300",
            "display_url" : "pic.x.com/vAFoQdWRFS"
          }
        ],
        "hashtags" : [
          {
            "text" : "uec25",
            "indices" : [
              "18",
              "24"
            ]
          },
          {
            "text" : "スポーツチャンバラ",
            "indices" : [
              "26",
              "36"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "60"
      ],
      "favorite_count" : "0",
      "id_str" : "1910671870921498956",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1910671870921498956",
      "possibly_sensitive" : false,
      "created_at" : "Fri Apr 11 12:30:47 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: #uec25 \n#スポーツチャンバラ https://t.co/vAFoQdWRFS",
      "lang" : "qme",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1910141009641775300/video/1",
            "source_status_id" : "1910141009641775300",
            "indices" : [
              "37",
              "60"
            ],
            "url" : "https://t.co/vAFoQdWRFS",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1910140959335305216/pu/img/hEqU7KMba3vZwsSd.jpg",
            "id_str" : "1910140959335305216",
            "video_info" : {
              "aspect_ratio" : [
                "16",
                "9"
              ],
              "duration_millis" : "44100",
              "variants" : [
                {
                  "bitrate" : "256000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1910140959335305216/pu/vid/avc1/480x270/XT_U6EVXlaBc5Dhc.mp4?tag=12"
                },
                {
                  "bitrate" : "832000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1910140959335305216/pu/vid/avc1/640x360/ciWQI4-Th17lbahZ.mp4?tag=12"
                },
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/1910140959335305216/pu/pl/w4yuC8u4EerbCE-W.m3u8?tag=12"
                },
                {
                  "bitrate" : "2176000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1910140959335305216/pu/vid/avc1/1280x720/4YailfMwz5Vsxe6E.mp4?tag=12"
                }
              ]
            },
            "source_user_id" : "1624283203870801920",
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1910140959335305216",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1910140959335305216/pu/img/hEqU7KMba3vZwsSd.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "source_status_id_str" : "1910141009641775300",
            "display_url" : "pic.x.com/vAFoQdWRFS"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1910671527240229090"
          ],
          "editableUntil" : "2025-04-11T13:29:25.311Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "144"
      ],
      "favorite_count" : "0",
      "id_str" : "1910671527240229090",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1910671527240229090",
      "created_at" : "Fri Apr 11 12:29:25 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 【個人的落とさない方がいい授業3選】\n1.基礎科学実験\n作成したレポート分もう一度やり直すのは辛すぎる。夜にはD棟から落単者の唸り声が聞こえるとか聞こえないとか…\n2.ASE &amp; AWE\n大半の授業で話し合いが発生。再履がバレるとやや気まずく…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1910334263217832308"
          ],
          "editableUntil" : "2025-04-10T15:09:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "1",
      "id_str" : "1910334263217832308",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1910334263217832308",
      "created_at" : "Thu Apr 10 14:09:15 +0000 2025",
      "favorited" : false,
      "full_text" : "ポケスリ、あと3日しかないのにダークライ捕まえられるかな…もう寝よ。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1910270028517396534"
          ],
          "editableUntil" : "2025-04-10T10:54:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "17"
      ],
      "favorite_count" : "0",
      "id_str" : "1910270028517396534",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1910270028517396534",
      "created_at" : "Thu Apr 10 09:54:00 +0000 2025",
      "favorited" : false,
      "full_text" : "ブックオフで教科書さがすのむずすぎ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1910264300436136131"
          ],
          "editableUntil" : "2025-04-10T10:31:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "16"
      ],
      "favorite_count" : "0",
      "id_str" : "1910264300436136131",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1910264300436136131",
      "created_at" : "Thu Apr 10 09:31:14 +0000 2025",
      "favorited" : false,
      "full_text" : "まさかご褒美になるとは思わなんだ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1910264215023370549"
          ],
          "editableUntil" : "2025-04-10T10:30:54.511Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "スポーツチャンバラ",
            "indices" : [
              "122",
              "132"
            ]
          },
          {
            "text" : "uec25",
            "indices" : [
              "133",
              "139"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1910264215023370549",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1910264215023370549",
      "created_at" : "Thu Apr 10 09:30:54 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 第二回体験会終了しました！\n本日は31人の方にお越しいただきました🥳\n\n次回の体験会は4/15(木)の16:30〜18:00になります！ぜひお越しください！\n※16:30〜17:00は女子体験会になります\n\n#スポーツチャンバラ\n#uec25…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1910206413202448509"
          ],
          "editableUntil" : "2025-04-10T06:41:13.483Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1910196211119968612/photo/1",
            "source_status_id" : "1910196211119968612",
            "indices" : [
              "81",
              "104"
            ],
            "url" : "https://t.co/SRl1ANwlO5",
            "media_url" : "http://pbs.twimg.com/media/GoJhVLNbAAAsk63.jpg",
            "id_str" : "1910196208372744192",
            "source_user_id" : "1624283203870801920",
            "id" : "1910196208372744192",
            "media_url_https" : "https://pbs.twimg.com/media/GoJhVLNbAAAsk63.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "medium" : {
                "w" : "720",
                "h" : "895",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "547",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "720",
                "h" : "895",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1910196211119968612",
            "display_url" : "pic.x.com/SRl1ANwlO5"
          }
        ],
        "hashtags" : [
          {
            "text" : "uec25",
            "indices" : [
              "62",
              "68"
            ]
          },
          {
            "text" : "スポーツチャンバラ",
            "indices" : [
              "70",
              "80"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "104"
      ],
      "favorite_count" : "0",
      "id_str" : "1910206413202448509",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1910206413202448509",
      "possibly_sensitive" : false,
      "created_at" : "Thu Apr 10 05:41:13 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 今日も体験会やります！\n※16:30〜17:00は女子体験会🌼\nぜひお越しください😊\n\n#uec25 \n#スポーツチャンバラ https://t.co/SRl1ANwlO5",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1910196211119968612/photo/1",
            "source_status_id" : "1910196211119968612",
            "indices" : [
              "81",
              "104"
            ],
            "url" : "https://t.co/SRl1ANwlO5",
            "media_url" : "http://pbs.twimg.com/media/GoJhVLNbAAAsk63.jpg",
            "id_str" : "1910196208372744192",
            "source_user_id" : "1624283203870801920",
            "id" : "1910196208372744192",
            "media_url_https" : "https://pbs.twimg.com/media/GoJhVLNbAAAsk63.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "medium" : {
                "w" : "720",
                "h" : "895",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "547",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "720",
                "h" : "895",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1910196211119968612",
            "display_url" : "pic.x.com/SRl1ANwlO5"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1910130139083767815"
          ],
          "editableUntil" : "2025-04-10T01:38:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "1",
      "id_str" : "1910130139083767815",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1910130139083767815",
      "created_at" : "Thu Apr 10 00:38:08 +0000 2025",
      "favorited" : false,
      "full_text" : "今更今日4限だけだよな…って不安になってきた",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1909977199765283241"
          ],
          "editableUntil" : "2025-04-09T15:30:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "1",
      "id_str" : "1909977199765283241",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1909977199765283241",
      "created_at" : "Wed Apr 09 14:30:24 +0000 2025",
      "favorited" : false,
      "full_text" : "RT増えたからってのもあるけどいつの間にか500ツイート超えてるのさすがにまずい。1000は超えたくない。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1909964430898790499"
          ],
          "editableUntil" : "2025-04-09T14:39:40.406Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1909964430898790499",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1909964430898790499",
      "created_at" : "Wed Apr 09 13:39:40 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: ｴｯﾎｴｯﾎ\n\nスポーツチャンバラサークルは\n\n☆新入生は部費1000円/年\n☆用具は貸出し可能\n☆女子部員3人いる\n☆練習参加は自由\n☆土曜日も自主練可能(13:00〜16:30)\n☆兼部・兼サー可能\n\nって伝えなきゃ\n\nｴｯﾎｴｯﾎ ht…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1909963493677351086"
          ],
          "editableUntil" : "2025-04-09T14:35:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "1",
      "id_str" : "1909963493677351086",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1909963493677351086",
      "created_at" : "Wed Apr 09 13:35:56 +0000 2025",
      "favorited" : false,
      "full_text" : "弟がリージョン違い欲しいからって理由じゃなくて、ただカッコいいからって理由でポケポケの言語英語にしてんの草",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1909956436815397248"
          ],
          "editableUntil" : "2025-04-09T14:07:54.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "0",
      "id_str" : "1909956436815397248",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1909956436815397248",
      "created_at" : "Wed Apr 09 13:07:54 +0000 2025",
      "favorited" : false,
      "full_text" : "降りる駅の2駅前でまじよかったけど、電車で貧血起こした…。心当たりが3つ以上あるぞ…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1909891889819697633"
          ],
          "editableUntil" : "2025-04-09T09:51:25.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "2",
      "id_str" : "1909891889819697633",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1909891889819697633",
      "created_at" : "Wed Apr 09 08:51:25 +0000 2025",
      "favorited" : false,
      "full_text" : "高校の頃からいつもスライドか穴埋めプリントが手元にあったせいで、本来のノートの取り方がわからなくなっている",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1909594272070021434"
          ],
          "editableUntil" : "2025-04-08T14:08:47.664Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "スポーツチャンバラ",
            "indices" : [
              "121",
              "131"
            ]
          },
          {
            "text" : "uec25",
            "indices" : [
              "132",
              "138"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1909594272070021434",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1909594272070021434",
      "created_at" : "Tue Apr 08 13:08:47 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 体験会初日終了しました✨\n本日は37人の方にお越しいただきました！\n\n次回の体験会は4/10(木)の16:30〜18:00になります！ぜひお越しください！\n※16:30〜17:00は女子体験会になります\n\n#スポーツチャンバラ\n#uec25…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1909559326001492241"
          ],
          "editableUntil" : "2025-04-08T11:49:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "4",
      "id_str" : "1909559326001492241",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1909559326001492241",
      "created_at" : "Tue Apr 08 10:49:55 +0000 2025",
      "favorited" : false,
      "full_text" : "スポチャンが賑わってて楽しかったです！！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1909454997332672619"
          ],
          "editableUntil" : "2025-04-08T04:55:21.979Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1909454997332672619",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1909454997332672619",
      "created_at" : "Tue Apr 08 03:55:21 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 【履修登録について】\n授業によっては動画を見てフォームを送ったり、教授にメールを送らないとそもそも履修できない科目もあるから要注意！(担当者は1個申請し忘れてて履修できませんでした…)。履修登録出来たら、友達と確認し合うのもオススメ！夏ターム…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1909435376605053046"
          ],
          "editableUntil" : "2025-04-08T03:37:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "2",
      "id_str" : "1909435376605053046",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1909435376605053046",
      "created_at" : "Tue Apr 08 02:37:24 +0000 2025",
      "favorited" : false,
      "full_text" : "今日ガチ目に1限から一言も言葉発してないぞ？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1909393046846029979"
          ],
          "editableUntil" : "2025-04-08T00:49:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "2",
      "id_str" : "1909393046846029979",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1909393046846029979",
      "created_at" : "Mon Apr 07 23:49:11 +0000 2025",
      "favorited" : false,
      "full_text" : "1人で授業受けることってそんなになかったから、どこ座ればいいかすらわからん",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1909248381245104542"
          ],
          "editableUntil" : "2025-04-07T15:14:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "10"
      ],
      "favorite_count" : "0",
      "id_str" : "1909248381245104542",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1909248381245104542",
      "created_at" : "Mon Apr 07 14:14:20 +0000 2025",
      "favorited" : false,
      "full_text" : "あー明日から不安だー",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1909139721776939061"
          ],
          "editableUntil" : "2025-04-07T08:02:34.429Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1909091725337149952/photo/1",
            "source_status_id" : "1909091725337149952",
            "indices" : [
              "116",
              "139"
            ],
            "url" : "https://t.co/M2g5VU4WLZ",
            "media_url" : "http://pbs.twimg.com/media/Gn50zfpbUAAivNj.jpg",
            "id_str" : "1909091720069074944",
            "source_user_id" : "1624283203870801920",
            "id" : "1909091720069074944",
            "media_url_https" : "https://pbs.twimg.com/media/Gn50zfpbUAAivNj.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1909091725337149952",
            "display_url" : "pic.x.com/M2g5VU4WLZ"
          }
        ],
        "hashtags" : [
          {
            "text" : "スポチャン",
            "indices" : [
              "94",
              "100"
            ]
          },
          {
            "text" : "春から電通大",
            "indices" : [
              "101",
              "108"
            ]
          },
          {
            "text" : "uec25",
            "indices" : [
              "109",
              "115"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1909139721776939061",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1909139721776939061",
      "possibly_sensitive" : false,
      "created_at" : "Mon Apr 07 07:02:34 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: スポーツチャンバラ同好会です！\n本日4/7の新歓は西5-209で行っています！\n体験会直前の説明会となっていますので、気になる方はぜひお越しください！\n#スポチャン\n#春から電通大\n#uec25 https://t.co/M2g5VU4WLZ",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1909091725337149952/photo/1",
            "source_status_id" : "1909091725337149952",
            "indices" : [
              "116",
              "139"
            ],
            "url" : "https://t.co/M2g5VU4WLZ",
            "media_url" : "http://pbs.twimg.com/media/Gn50zfpbUAAivNj.jpg",
            "id_str" : "1909091720069074944",
            "source_user_id" : "1624283203870801920",
            "id" : "1909091720069074944",
            "media_url_https" : "https://pbs.twimg.com/media/Gn50zfpbUAAivNj.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1909091725337149952",
            "display_url" : "pic.x.com/M2g5VU4WLZ"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1909139066538586406"
          ],
          "editableUntil" : "2025-04-07T07:59:58.208Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "春から電通大",
            "indices" : [
              "130",
              "137"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1909139066538586406",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1909139066538586406",
      "created_at" : "Mon Apr 07 06:59:58 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 電通大スポーツチャンバラ同好会の練習は、基本火曜日、木曜日16:30〜18:00にやっています。しかし！参加するのは来れる時に、5分でもOK！兼サーもしやすく(私も他に2つしている)、気軽に練習に参加できるのが良い点です！\n#春から電通大\n#…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1908721402095821086"
          ],
          "editableUntil" : "2025-04-06T04:20:19.245Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1908721402095821086",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1908721402095821086",
      "created_at" : "Sun Apr 06 03:20:19 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 【電通大で教職取る人へ】\n実は電通大でも「中高の数学・情報の教員免許」取れます。\n理工学系でも「先生」を目指せるって知ってた？\n教職は単位も取れて就職活動にも有利に働く、まさに一石二鳥！\n気になる人は早めに教職センターで相談してみて！\n#電通…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1908444934371500454"
          ],
          "editableUntil" : "2025-04-05T10:01:44.203Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1908434621056049629/photo/1",
            "source_status_id" : "1908434621056049629",
            "indices" : [
              "108",
              "131"
            ],
            "url" : "https://t.co/kPUISkZJIy",
            "media_url" : "http://pbs.twimg.com/media/GnwfKcZbYAE7taY.jpg",
            "id_str" : "1908434606380244993",
            "source_user_id" : "1624283203870801920",
            "id" : "1908434606380244993",
            "media_url_https" : "https://pbs.twimg.com/media/GnwfKcZbYAE7taY.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "2048",
                "h" : "1126",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "660",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "374",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1908434621056049629",
            "display_url" : "pic.x.com/kPUISkZJIy"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "131"
      ],
      "favorite_count" : "0",
      "id_str" : "1908444934371500454",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1908444934371500454",
      "possibly_sensitive" : false,
      "created_at" : "Sat Apr 05 09:01:44 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 本日は五名の方が来てくれました！！！！！！\nみなさん休日にも関わらず来てくださりありがとうございました♪\n体験会は4/8,16:30~18:00にやってます！ぜひ来てください！！ https://t.co/kPUISkZJIy",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1908434621056049629/photo/1",
            "source_status_id" : "1908434621056049629",
            "indices" : [
              "108",
              "131"
            ],
            "url" : "https://t.co/kPUISkZJIy",
            "media_url" : "http://pbs.twimg.com/media/GnwfKcZbYAE7taY.jpg",
            "id_str" : "1908434606380244993",
            "source_user_id" : "1624283203870801920",
            "id" : "1908434606380244993",
            "media_url_https" : "https://pbs.twimg.com/media/GnwfKcZbYAE7taY.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "2048",
                "h" : "1126",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "660",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "374",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1908434621056049629",
            "display_url" : "pic.x.com/kPUISkZJIy"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1908392948800381185"
          ],
          "editableUntil" : "2025-04-05T06:35:09.877Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1908374221648257257/video/1",
            "source_status_id" : "1908374221648257257",
            "indices" : [
              "98",
              "121"
            ],
            "url" : "https://t.co/ipLX8YgSHl",
            "media_url" : "http://pbs.twimg.com/amplify_video_thumb/1908374152538673152/img/063kLwZpg6Vl0h_k.jpg",
            "id_str" : "1908374152538673152",
            "source_user_id" : "1624283203870801920",
            "id" : "1908374152538673152",
            "media_url_https" : "https://pbs.twimg.com/amplify_video_thumb/1908374152538673152/img/063kLwZpg6Vl0h_k.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1908374221648257257",
            "display_url" : "pic.x.com/ipLX8YgSHl"
          }
        ],
        "hashtags" : [
          {
            "text" : "春から電通大",
            "indices" : [
              "72",
              "79"
            ]
          },
          {
            "text" : "uec25",
            "indices" : [
              "80",
              "86"
            ]
          },
          {
            "text" : "スポーツチャンバラ",
            "indices" : [
              "87",
              "97"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "121"
      ],
      "favorite_count" : "0",
      "id_str" : "1908392948800381185",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1908392948800381185",
      "possibly_sensitive" : false,
      "created_at" : "Sat Apr 05 05:35:09 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 実は今日も練習してます！\n16:00まで第二体育館の二階で練習してるので興味ある方はぜひきてみてください！\n#春から電通大\n#uec25\n#スポーツチャンバラ https://t.co/ipLX8YgSHl",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1908374221648257257/video/1",
            "source_status_id" : "1908374221648257257",
            "indices" : [
              "98",
              "121"
            ],
            "url" : "https://t.co/ipLX8YgSHl",
            "media_url" : "http://pbs.twimg.com/amplify_video_thumb/1908374152538673152/img/063kLwZpg6Vl0h_k.jpg",
            "id_str" : "1908374152538673152",
            "video_info" : {
              "aspect_ratio" : [
                "16",
                "9"
              ],
              "duration_millis" : "6335",
              "variants" : [
                {
                  "bitrate" : "832000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/amplify_video/1908374152538673152/vid/avc1/640x360/dpSWJJoYohuvpwf9.mp4?tag=14"
                },
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/amplify_video/1908374152538673152/pl/0vPTnUGG4l4kVxsl.m3u8?tag=14"
                },
                {
                  "bitrate" : "288000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/amplify_video/1908374152538673152/vid/avc1/480x270/KCdHc-qDGtZkA9yR.mp4?tag=14"
                },
                {
                  "bitrate" : "2176000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/amplify_video/1908374152538673152/vid/avc1/1280x720/zrTYN00dmyq9HLuJ.mp4?tag=14"
                }
              ]
            },
            "source_user_id" : "1624283203870801920",
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1908374152538673152",
            "media_url_https" : "https://pbs.twimg.com/amplify_video_thumb/1908374152538673152/img/063kLwZpg6Vl0h_k.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "source_status_id_str" : "1908374221648257257",
            "display_url" : "pic.x.com/ipLX8YgSHl"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1907828841529348193"
          ],
          "editableUntil" : "2025-04-03T17:13:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1907827444381614130",
      "id_str" : "1907828841529348193",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1907828841529348193",
      "in_reply_to_status_id" : "1907827444381614130",
      "created_at" : "Thu Apr 03 16:13:36 +0000 2025",
      "favorited" : false,
      "full_text" : "あれで培った技術をサークルビラ作成で使い倒してたのか。エモ笑",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1907827444381614130"
          ],
          "editableUntil" : "2025-04-03T17:08:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "2",
      "id_str" : "1907827444381614130",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1907827444381614130",
      "created_at" : "Thu Apr 03 16:08:03 +0000 2025",
      "favorited" : false,
      "full_text" : "scratchの話が出てて懐かしいね。あれはベクターイラストツールですよ！！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1907827148674707832"
          ],
          "editableUntil" : "2025-04-03T17:06:52.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "86"
      ],
      "favorite_count" : "1",
      "id_str" : "1907827148674707832",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1907827148674707832",
      "created_at" : "Thu Apr 03 16:06:52 +0000 2025",
      "favorited" : false,
      "full_text" : "弟がひっそりとYouTubeやってた(今は休止中？)ことは前々から知ってたけど、登録者が最高3.2kまでいったことあるのは初耳すぎて驚愕したw\nちなその垢は凍結したらしいw",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1907652020254957956"
          ],
          "editableUntil" : "2025-04-03T05:30:58.746Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1907635971614798129/photo/1",
            "source_status_id" : "1907635971614798129",
            "indices" : [
              "59",
              "82"
            ],
            "url" : "https://t.co/bwFlAoKnBr",
            "media_url" : "http://pbs.twimg.com/media/GnlIzmjaQAEEylH.jpg",
            "id_str" : "1907635968527712257",
            "source_user_id" : "1624283203870801920",
            "id" : "1907635968527712257",
            "media_url_https" : "https://pbs.twimg.com/media/GnlIzmjaQAEEylH.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "medium" : {
                "w" : "960",
                "h" : "1200",
                "resize" : "fit"
              },
              "small" : {
                "w" : "544",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1080",
                "h" : "1350",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1907635971614798129",
            "display_url" : "pic.x.com/bwFlAoKnBr"
          }
        ],
        "hashtags" : [
          {
            "text" : "uec25",
            "indices" : [
              "33",
              "39"
            ]
          },
          {
            "text" : "春から電通大",
            "indices" : [
              "40",
              "47"
            ]
          },
          {
            "text" : "スポーツチャンバラ",
            "indices" : [
              "48",
              "58"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "82"
      ],
      "favorite_count" : "0",
      "id_str" : "1907652020254957956",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1907652020254957956",
      "possibly_sensitive" : false,
      "created_at" : "Thu Apr 03 04:30:58 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: インスタ、フォローしてる？\n\n#uec25\n#春から電通大\n#スポーツチャンバラ https://t.co/bwFlAoKnBr",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1907635971614798129/photo/1",
            "source_status_id" : "1907635971614798129",
            "indices" : [
              "59",
              "82"
            ],
            "url" : "https://t.co/bwFlAoKnBr",
            "media_url" : "http://pbs.twimg.com/media/GnlIzmjaQAEEylH.jpg",
            "id_str" : "1907635968527712257",
            "source_user_id" : "1624283203870801920",
            "id" : "1907635968527712257",
            "media_url_https" : "https://pbs.twimg.com/media/GnlIzmjaQAEEylH.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "medium" : {
                "w" : "960",
                "h" : "1200",
                "resize" : "fit"
              },
              "small" : {
                "w" : "544",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1080",
                "h" : "1350",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1907635971614798129",
            "display_url" : "pic.x.com/bwFlAoKnBr"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1907283830605807941"
          ],
          "editableUntil" : "2025-04-02T05:07:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1907283082773995962",
      "id_str" : "1907283830605807941",
      "in_reply_to_user_id" : "1890782086174584832",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1907283830605807941",
      "in_reply_to_status_id" : "1907283082773995962",
      "created_at" : "Wed Apr 02 04:07:55 +0000 2025",
      "favorited" : false,
      "full_text" : "@ic_uec24 ポータルで見れますよ〜",
      "lang" : "ja",
      "in_reply_to_user_id_str" : "1890782086174584832"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1907280739353149705"
          ],
          "editableUntil" : "2025-04-02T04:55:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "41"
      ],
      "favorite_count" : "0",
      "id_str" : "1907280739353149705",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1907280739353149705",
      "created_at" : "Wed Apr 02 03:55:38 +0000 2025",
      "favorited" : false,
      "full_text" : "Bクラに変わった唯一のメリットはAESだと。そう思ってた時期が私にもありました（）",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1907027136063377714"
          ],
          "editableUntil" : "2025-04-01T12:07:54.745Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1907027136063377714",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1907027136063377714",
      "created_at" : "Tue Apr 01 11:07:54 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 2025年度入学の皆さん、改めておめでとうございます！\nスポチャンでは4月に以下の新歓を行いますので、ぜひお越しください！\n\n⭐️説明会@Ａ棟201\n→4,7,13日\n\n⭐️体験会@第二体育館2階\n→毎週火,木曜日(10,15日は女子限定体験…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1906980444807025151"
          ],
          "editableUntil" : "2025-04-01T09:02:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "いんてら",
            "screen_name" : "n_777intera",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1770628107323785216",
            "id" : "1770628107323785216"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "26"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1906980345586876677",
      "id_str" : "1906980444807025151",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1906980444807025151",
      "in_reply_to_status_id" : "1906980345586876677",
      "created_at" : "Tue Apr 01 08:02:22 +0000 2025",
      "favorited" : false,
      "full_text" : "@n_777intera 前泊しなくて済みそうです！",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1906980345586876677"
          ],
          "editableUntil" : "2025-04-01T09:01:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "いんてら",
            "screen_name" : "n_777intera",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1770628107323785216",
            "id" : "1770628107323785216"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1906980046226755630",
      "id_str" : "1906980345586876677",
      "in_reply_to_user_id" : "1770628107323785216",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1906980345586876677",
      "in_reply_to_status_id" : "1906980046226755630",
      "created_at" : "Tue Apr 01 08:01:59 +0000 2025",
      "favorited" : false,
      "full_text" : "@n_777intera もしもの時のために前泊しようと思ってたので、それなら安心ですね！",
      "lang" : "ja",
      "in_reply_to_screen_name" : "n_777intera",
      "in_reply_to_user_id_str" : "1770628107323785216"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1906978933398262185"
          ],
          "editableUntil" : "2025-04-01T08:56:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "いんてら",
            "screen_name" : "n_777intera",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1770628107323785216",
            "id" : "1770628107323785216"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1906977105768050934",
      "id_str" : "1906978933398262185",
      "in_reply_to_user_id" : "1770628107323785216",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1906978933398262185",
      "in_reply_to_status_id" : "1906977105768050934",
      "created_at" : "Tue Apr 01 07:56:22 +0000 2025",
      "favorited" : false,
      "full_text" : "@n_777intera JREって電車の遅延で遅刻したとかでも不可ですか？",
      "lang" : "ja",
      "in_reply_to_screen_name" : "n_777intera",
      "in_reply_to_user_id_str" : "1770628107323785216"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1906976475414491177"
          ],
          "editableUntil" : "2025-04-01T08:46:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "3",
      "id_str" : "1906976475414491177",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1906976475414491177",
      "created_at" : "Tue Apr 01 07:46:36 +0000 2025",
      "favorited" : false,
      "full_text" : "さっきまで作ってたのと比べて、金曜一限が新しく生えてきたの許せないわね",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1906976285534089702"
          ],
          "editableUntil" : "2025-04-01T08:45:51.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "わたあめ",
            "screen_name" : "plcbo_",
            "indices" : [
              "0",
              "7"
            ],
            "id_str" : "1898114274431770624",
            "id" : "1898114274431770624"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "17"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1906973979212136779",
      "id_str" : "1906976285534089702",
      "in_reply_to_user_id" : "1898114274431770624",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1906976285534089702",
      "in_reply_to_status_id" : "1906973979212136779",
      "created_at" : "Tue Apr 01 07:45:51 +0000 2025",
      "favorited" : false,
      "full_text" : "@plcbo_ そうみたいです…🥲",
      "lang" : "ja",
      "in_reply_to_screen_name" : "plcbo_",
      "in_reply_to_user_id_str" : "1898114274431770624"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1906970204107874329"
          ],
          "editableUntil" : "2025-04-01T08:21:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "6",
      "id_str" : "1906970204107874329",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1906970204107874329",
      "created_at" : "Tue Apr 01 07:21:41 +0000 2025",
      "favorited" : false,
      "full_text" : "Cクラかと思ってたらBクラでした！！！時間割作ってました！！許せない！！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1906969295545872759"
          ],
          "editableUntil" : "2025-04-01T08:18:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "0",
      "id_str" : "1906969295545872759",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1906969295545872759",
      "created_at" : "Tue Apr 01 07:18:04 +0000 2025",
      "favorited" : false,
      "full_text" : "！？！？時間割作っちゃったよーーーーーー",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1906887757387256094"
          ],
          "editableUntil" : "2025-04-01T02:54:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "1",
      "id_str" : "1906887757387256094",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1906887757387256094",
      "created_at" : "Tue Apr 01 01:54:04 +0000 2025",
      "favorited" : false,
      "full_text" : "エイプリルフールに際してアイコン変えた人たちをリツイートする人にリツイートされてて草",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1906885393515159935"
          ],
          "editableUntil" : "2025-04-01T02:44:40.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1906885393515159935/photo/1",
            "indices" : [
              "23",
              "46"
            ],
            "url" : "https://t.co/oemZAM8HHe",
            "media_url" : "http://pbs.twimg.com/media/GnaeKQDbwAAhm7r.jpg",
            "id_str" : "1906885391183233024",
            "id" : "1906885391183233024",
            "media_url_https" : "https://pbs.twimg.com/media/GnaeKQDbwAAhm7r.jpg",
            "sizes" : {
              "large" : {
                "w" : "224",
                "h" : "224",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "224",
                "h" : "224",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "224",
                "h" : "224",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/oemZAM8HHe"
          }
        ],
        "hashtags" : [
          {
            "text" : "新しいプロフィール画像",
            "indices" : [
              "0",
              "12"
            ]
          },
          {
            "text" : "エイプリルフール",
            "indices" : [
              "13",
              "22"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "46"
      ],
      "favorite_count" : "3",
      "id_str" : "1906885393515159935",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1906885393515159935",
      "possibly_sensitive" : false,
      "created_at" : "Tue Apr 01 01:44:40 +0000 2025",
      "favorited" : false,
      "full_text" : "#新しいプロフィール画像\n#エイプリルフール https://t.co/oemZAM8HHe",
      "lang" : "qme",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1906885393515159935/photo/1",
            "indices" : [
              "23",
              "46"
            ],
            "url" : "https://t.co/oemZAM8HHe",
            "media_url" : "http://pbs.twimg.com/media/GnaeKQDbwAAhm7r.jpg",
            "id_str" : "1906885391183233024",
            "id" : "1906885391183233024",
            "media_url_https" : "https://pbs.twimg.com/media/GnaeKQDbwAAhm7r.jpg",
            "sizes" : {
              "large" : {
                "w" : "224",
                "h" : "224",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "224",
                "h" : "224",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "224",
                "h" : "224",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/oemZAM8HHe"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1906883473371169073"
          ],
          "editableUntil" : "2025-04-01T02:37:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "0",
      "id_str" : "1906883473371169073",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1906883473371169073",
      "created_at" : "Tue Apr 01 01:37:02 +0000 2025",
      "favorited" : false,
      "full_text" : "Twitterバグってアイコン変えられない()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1906688389388325354"
          ],
          "editableUntil" : "2025-03-31T13:41:51.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "0",
      "id_str" : "1906688389388325354",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1906688389388325354",
      "created_at" : "Mon Mar 31 12:41:51 +0000 2025",
      "favorited" : false,
      "full_text" : "思えば✨キラキラリア充高校✨の中で3年間自分を貫き続けられた私はすごいかもしれない。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1906687380914061445"
          ],
          "editableUntil" : "2025-03-31T13:37:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "100"
      ],
      "favorite_count" : "4",
      "id_str" : "1906687380914061445",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1906687380914061445",
      "created_at" : "Mon Mar 31 12:37:50 +0000 2025",
      "favorited" : false,
      "full_text" : "新入生交流会ではⅠ類に転類できたと勘違いしてⅠ類の子ばっかりと話した思い出。結局授業始まってからでも同クラで友達はできると分かった。\nただ！最初からグループができてる転類後のクラスでは不安で仕方ない。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1906627850842918982"
          ],
          "editableUntil" : "2025-03-31T09:41:17.730Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "144"
      ],
      "favorite_count" : "0",
      "id_str" : "1906627850842918982",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1906627850842918982",
      "created_at" : "Mon Mar 31 08:41:17 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 「スポチャンQ&amp;A」\nQ: 痛くないの？ → A: 柔らかい武器だから安心！\nQ: ルールが難しそう → A: 「相手より先に当てたら勝ち！」これが基本！\nQ: 初心者でもできる？ → A: もちろん！ ほぼ全員が初心者スタート！\n気になった…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1905964610592842030"
          ],
          "editableUntil" : "2025-03-29T13:45:48.932Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1905964610592842030",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1905964610592842030",
      "created_at" : "Sat Mar 29 12:45:48 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: [キャリア教育基礎について]\nキャリア教育基礎は月曜一限にあるため、起きるのが得意でない人は注意👀⚠️\nただ、他クラスの色々なメンバーと話すことができる貴重な機会で、TAの先輩にさまざまな話を聞くことができるのがおすすめ！\n朝起きれるor家が…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1905598896539402603"
          ],
          "editableUntil" : "2025-03-28T13:32:35.907Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "スポチャン",
            "indices" : [
              "96",
              "102"
            ]
          },
          {
            "text" : "春から電通大",
            "indices" : [
              "103",
              "110"
            ]
          },
          {
            "text" : "uec25",
            "indices" : [
              "111",
              "117"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1905598896539402603",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1905598896539402603",
      "created_at" : "Fri Mar 28 12:32:35 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 明らかに自分が勝ってるのに判定に納得がいかず審判に抗議する相手(123456789012345671回(←素数)の抗議によるビデオ判定で逆転勝利)(出禁)\n#スポチャン\n#春から電通大\n#uec25 https://t.co/MH7n7rge…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1905493460754526573"
          ],
          "editableUntil" : "2025-03-28T06:33:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "11"
      ],
      "favorite_count" : "10",
      "in_reply_to_status_id_str" : "1905493393901584443",
      "id_str" : "1905493460754526573",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1905493460754526573",
      "in_reply_to_status_id" : "1905493393901584443",
      "created_at" : "Fri Mar 28 05:33:38 +0000 2025",
      "favorited" : false,
      "full_text" : "お　お　よ　ろ　こ　び",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1905493393901584443"
          ],
          "editableUntil" : "2025-03-28T06:33:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "16",
      "in_reply_to_status_id_str" : "1905490573764821483",
      "id_str" : "1905493393901584443",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1905493393901584443",
      "in_reply_to_status_id" : "1905490573764821483",
      "created_at" : "Fri Mar 28 05:33:22 +0000 2025",
      "favorited" : false,
      "full_text" : "pdfの右上の日付は令和7年で合ってたから\nⅡ類→Ⅰ類確定！",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1905490700818428023"
          ],
          "editableUntil" : "2025-03-28T06:22:40.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "0",
      "id_str" : "1905490700818428023",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1905490700818428023",
      "created_at" : "Fri Mar 28 05:22:40 +0000 2025",
      "favorited" : false,
      "full_text" : "いやまて令和6年度って書いてあるぞ🤔🤔🤔",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1905490573764821483"
          ],
          "editableUntil" : "2025-03-28T06:22:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "31",
      "id_str" : "1905490573764821483",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1905490573764821483",
      "created_at" : "Fri Mar 28 05:22:09 +0000 2025",
      "favorited" : false,
      "full_text" : "私はⅠ類落ちのⅡ類なんだけど、転類選考結果に学籍番号があるってことは転類願が受理された可能性があるってコト！？激アツかもしれん…！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1905340523092869563"
          ],
          "editableUntil" : "2025-03-27T20:25:54.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "1",
      "id_str" : "1905340523092869563",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1905340523092869563",
      "created_at" : "Thu Mar 27 19:25:54 +0000 2025",
      "favorited" : false,
      "full_text" : "ニンダイ待機してたら寝落ちしていつの間にかこんな時間…！？\n浦島太郎になった気分だぜ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1905109153887961150"
          ],
          "editableUntil" : "2025-03-27T05:06:32.160Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1905109153887961150",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1905109153887961150",
      "created_at" : "Thu Mar 27 04:06:32 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 🗡スポーツチャンバラの武器紹介！Part②⚔️\n槍は最もリーチが長く、扱いにくい武器。圧倒的なリーチ差を活かして相手を攻撃出来る！杖や棒は両端に攻撃する部分がついてて、形が特徴的！\n槍と棒は200cm以下、杖は140cmと長さが決められてる。…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1905109118412894431"
          ],
          "editableUntil" : "2025-03-27T05:06:23.702Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1905109118412894431",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1905109118412894431",
      "created_at" : "Thu Mar 27 04:06:23 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 【第二言語の選択】\n電通大の一年次では必修として英語以外の第二言語の授業に取り組む必要があります！！✅\n種類は『中国語🇨🇳』『ドイツ語🇩🇪』『韓国語🇰🇷』『ロシア語🇷🇺』『フランス語🇫🇷』です。\n今のうちからどの言語を勉強したいか考えておくの…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1905106034928357625"
          ],
          "editableUntil" : "2025-03-27T04:54:08.542Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1905051749213524110/video/1",
            "source_status_id" : "1905051749213524110",
            "indices" : [
              "44",
              "67"
            ],
            "url" : "https://t.co/FpOJ0Dlo1a",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1905051719056400385/pu/img/S5YZ2TSh_JVfBsqy.jpg",
            "id_str" : "1905051719056400385",
            "source_user_id" : "1624283203870801920",
            "id" : "1905051719056400385",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1905051719056400385/pu/img/S5YZ2TSh_JVfBsqy.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1905051749213524110",
            "display_url" : "pic.x.com/FpOJ0Dlo1a"
          }
        ],
        "hashtags" : [
          {
            "text" : "uec25",
            "indices" : [
              "28",
              "34"
            ]
          },
          {
            "text" : "春から電通大",
            "indices" : [
              "36",
              "43"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "67"
      ],
      "favorite_count" : "0",
      "id_str" : "1905106034928357625",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1905106034928357625",
      "possibly_sensitive" : false,
      "created_at" : "Thu Mar 27 03:54:08 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: フル単するために…\n#uec25 \n#春から電通大 https://t.co/FpOJ0Dlo1a",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1905051749213524110/video/1",
            "source_status_id" : "1905051749213524110",
            "indices" : [
              "44",
              "67"
            ],
            "url" : "https://t.co/FpOJ0Dlo1a",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1905051719056400385/pu/img/S5YZ2TSh_JVfBsqy.jpg",
            "id_str" : "1905051719056400385",
            "video_info" : {
              "aspect_ratio" : [
                "16",
                "9"
              ],
              "duration_millis" : "38800",
              "variants" : [
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/1905051719056400385/pu/pl/Rzr8c3kC3VerAsK7.m3u8?tag=12&v=cfc"
                },
                {
                  "bitrate" : "2176000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1905051719056400385/pu/vid/avc1/1280x720/J0NZtyWwBZ6L-4Wk.mp4?tag=12"
                },
                {
                  "bitrate" : "832000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1905051719056400385/pu/vid/avc1/640x360/IxFIUf_cT8o-TfQA.mp4?tag=12"
                },
                {
                  "bitrate" : "256000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1905051719056400385/pu/vid/avc1/480x270/R_pa3t-pGcf9e48Z.mp4?tag=12"
                }
              ]
            },
            "source_user_id" : "1624283203870801920",
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1905051719056400385",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1905051719056400385/pu/img/S5YZ2TSh_JVfBsqy.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "source_status_id_str" : "1905051749213524110",
            "display_url" : "pic.x.com/FpOJ0Dlo1a"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1904845683330605200"
          ],
          "editableUntil" : "2025-03-26T11:39:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1904845683330605200/photo/1",
            "indices" : [
              "12",
              "35"
            ],
            "url" : "https://t.co/UIYGbkBJHJ",
            "media_url" : "http://pbs.twimg.com/media/Gm9fDXnbYAQfBS9.jpg",
            "id_str" : "1904845678884642820",
            "id" : "1904845678884642820",
            "media_url_https" : "https://pbs.twimg.com/media/Gm9fDXnbYAQfBS9.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "800",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "453",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "2048",
                "h" : "1365",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/UIYGbkBJHJ"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "9",
      "id_str" : "1904845683330605200",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1904845683330605200",
      "possibly_sensitive" : false,
      "created_at" : "Wed Mar 26 10:39:35 +0000 2025",
      "favorited" : false,
      "full_text" : "ﾈｺﾁｬﾝ撮れたﾖ!! https://t.co/UIYGbkBJHJ",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1904845683330605200/photo/1",
            "indices" : [
              "12",
              "35"
            ],
            "url" : "https://t.co/UIYGbkBJHJ",
            "media_url" : "http://pbs.twimg.com/media/Gm9fDXnbYAQfBS9.jpg",
            "id_str" : "1904845678884642820",
            "id" : "1904845678884642820",
            "media_url_https" : "https://pbs.twimg.com/media/Gm9fDXnbYAQfBS9.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "800",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "453",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "2048",
                "h" : "1365",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/UIYGbkBJHJ"
          },
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1904845683330605200/photo/1",
            "indices" : [
              "12",
              "35"
            ],
            "url" : "https://t.co/UIYGbkBJHJ",
            "media_url" : "http://pbs.twimg.com/media/Gm9fDZmakAAPOzR.jpg",
            "id_str" : "1904845679417266176",
            "id" : "1904845679417266176",
            "media_url_https" : "https://pbs.twimg.com/media/Gm9fDZmakAAPOzR.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "453",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1365",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "800",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/UIYGbkBJHJ"
          },
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1904845683330605200/photo/1",
            "indices" : [
              "12",
              "35"
            ],
            "url" : "https://t.co/UIYGbkBJHJ",
            "media_url" : "http://pbs.twimg.com/media/Gm9fDX3bYAAelw1.jpg",
            "id_str" : "1904845678951751680",
            "id" : "1904845678951751680",
            "media_url_https" : "https://pbs.twimg.com/media/Gm9fDX3bYAAelw1.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1620",
                "h" : "1080",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "800",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "453",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/UIYGbkBJHJ"
          },
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1904845683330605200/photo/1",
            "indices" : [
              "12",
              "35"
            ],
            "url" : "https://t.co/UIYGbkBJHJ",
            "media_url" : "http://pbs.twimg.com/media/Gm9fDebagAAP8a6.jpg",
            "id_str" : "1904845680713302016",
            "id" : "1904845680713302016",
            "media_url_https" : "https://pbs.twimg.com/media/Gm9fDebagAAP8a6.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "453",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "800",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1620",
                "h" : "1080",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/UIYGbkBJHJ"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1904832446967013614"
          ],
          "editableUntil" : "2025-03-26T10:47:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "2",
      "id_str" : "1904832446967013614",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1904832446967013614",
      "created_at" : "Wed Mar 26 09:47:00 +0000 2025",
      "favorited" : false,
      "full_text" : "昨日焼肉、今日バイキングで最近豪華なもの食いすぎなんだよなあ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1904185115301064956"
          ],
          "editableUntil" : "2025-03-24T15:54:44.193Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "春から電通大",
            "indices" : [
              "110",
              "117"
            ]
          },
          {
            "text" : "uec25",
            "indices" : [
              "118",
              "124"
            ]
          },
          {
            "text" : "スポーツチャンバラ",
            "indices" : [
              "125",
              "135"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1904185115301064956",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1904185115301064956",
      "created_at" : "Mon Mar 24 14:54:44 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 電通大スポーツチャンバラ同好会です！\n今日はスポチャンに使う主要な武器、防具について、部員の画像も交えて紹介します⚔️\n興味を持った方は説明会、体験会にお越しいただけると嬉しいです🥰\n#春から電通大\n#uec25\n#スポーツチャンバラ htt…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1904158125663674745"
          ],
          "editableUntil" : "2025-03-24T14:07:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "0",
      "id_str" : "1904158125663674745",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1904158125663674745",
      "created_at" : "Mon Mar 24 13:07:29 +0000 2025",
      "favorited" : false,
      "full_text" : "もしかしてイヤホンの右が溺死した？？？\nゲリラ豪雨ガチ許さん",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1904105839692218734"
          ],
          "editableUntil" : "2025-03-24T10:39:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "18"
      ],
      "favorite_count" : "0",
      "id_str" : "1904105839692218734",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1904105839692218734",
      "created_at" : "Mon Mar 24 09:39:43 +0000 2025",
      "favorited" : false,
      "full_text" : "ゲリラ豪雨に降られてもはや着衣泳()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1903964146884084186"
          ],
          "editableUntil" : "2025-03-24T01:16:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "62"
      ],
      "favorite_count" : "0",
      "id_str" : "1903964146884084186",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1903964146884084186",
      "created_at" : "Mon Mar 24 00:16:41 +0000 2025",
      "favorited" : false,
      "full_text" : "俺に…俺にもっと力があれば…！！！タイミーで\n「20kg以上の物を運ぶ作業があります」\nって言ってる現場に行けるのに……！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1903829944381387024"
          ],
          "editableUntil" : "2025-03-23T16:23:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "14"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1903829840446513608",
      "id_str" : "1903829944381387024",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1903829944381387024",
      "in_reply_to_status_id" : "1903829840446513608",
      "created_at" : "Sun Mar 23 15:23:24 +0000 2025",
      "favorited" : false,
      "full_text" : "別々の穴からなのもやめてね。",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1903829840446513608"
          ],
          "editableUntil" : "2025-03-23T16:23:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "0",
      "id_str" : "1903829840446513608",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1903829840446513608",
      "created_at" : "Sun Mar 23 15:23:00 +0000 2025",
      "favorited" : false,
      "full_text" : "外出中に鼻血出るのやめてね。マスク持ってないときとかさらにやめてね。PART2",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1903806844553875961"
          ],
          "editableUntil" : "2025-03-23T14:51:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "0",
      "id_str" : "1903806844553875961",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1903806844553875961",
      "created_at" : "Sun Mar 23 13:51:37 +0000 2025",
      "favorited" : false,
      "full_text" : "外出中に鼻血出るのやめてね。マスク持ってないときとかさらにやめてね。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1903404799120330806"
          ],
          "editableUntil" : "2025-03-22T12:14:02.318Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "スポチャン",
            "indices" : [
              "98",
              "104"
            ]
          },
          {
            "text" : "春から電通大",
            "indices" : [
              "105",
              "112"
            ]
          },
          {
            "text" : "UEC25",
            "indices" : [
              "114",
              "120"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1903404799120330806",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1903404799120330806",
      "created_at" : "Sat Mar 22 11:14:02 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 名誉教授を、叩きます！\n\n教授を合法的にしばけるのはスポーツチャンバラサークルだけ！👀\nぜひしばきにきてください！\n\n⚠️しばかれた場合の責任は一切持ちません\n#スポチャン\n#春から電通大 \n#UEC25 https://t.co/HK0Pu…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1903275687093604408"
          ],
          "editableUntil" : "2025-03-22T03:40:59.612Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "電気通信大学 写真研究部",
            "screen_name" : "uec_photo",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "2388772040",
            "id" : "2388772040"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1903275687093604408",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1903275687093604408",
      "created_at" : "Sat Mar 22 02:40:59 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uec_photo: 新入生の皆さま\n入試お疲れさまでした\nそして合格おめでとうございます🌸\n\n公認サークル「写真研究部」です\n月1回程度の撮影会と夏季休暇中の合宿をメインに、ゆる〜く活動しています\nカメラに興味のある方もスマホで写真を撮るのが好きな方も大歓迎です\nぜひ…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1903275527278039213"
          ],
          "editableUntil" : "2025-03-22T03:40:21.509Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1903275527278039213",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1903275527278039213",
      "created_at" : "Sat Mar 22 02:40:21 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 後期試験に合格された皆さん、おめでとうございます🌸電通大スポーツチャンバラ同好会です\n毎週火・木曜日、第2体育館2階で活動しています！経験の有無を問わず募集しています！ガッツリ運動をしたい方・運動不足解消のため軽く運動をしたい方どちらも大歓迎…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1903275327553691801"
          ],
          "editableUntil" : "2025-03-22T03:39:33.891Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "電気通信大学 2025年度新入生歓迎会【公式】",
            "screen_name" : "uecshinkan_info",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "1346102096148324353",
            "id" : "1346102096148324353"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/uecshinkan_info/status/1903250273885360584/video/1",
            "source_status_id" : "1903250273885360584",
            "indices" : [
              "75",
              "98"
            ],
            "url" : "https://t.co/l6InCm2bx4",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1903014816190697479/pu/img/6cad6yj70hPxRsrk.jpg",
            "id_str" : "1903014816190697479",
            "source_user_id" : "1346102096148324353",
            "id" : "1903014816190697479",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1903014816190697479/pu/img/6cad6yj70hPxRsrk.jpg",
            "source_user_id_str" : "1346102096148324353",
            "sizes" : {
              "large" : {
                "w" : "1920",
                "h" : "1080",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1903250273885360584",
            "display_url" : "pic.x.com/l6InCm2bx4"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "98"
      ],
      "favorite_count" : "0",
      "id_str" : "1903275327553691801",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1903275327553691801",
      "possibly_sensitive" : false,
      "created_at" : "Sat Mar 22 02:39:33 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecshinkan_info: X680x0同好会の紹介です！\n\nゲーム , 絵 , 音楽の制作に興味のある人！\nぜひX680x0同好会へ https://t.co/l6InCm2bx4",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/uecshinkan_info/status/1903250273885360584/video/1",
            "source_status_id" : "1903250273885360584",
            "indices" : [
              "75",
              "98"
            ],
            "url" : "https://t.co/l6InCm2bx4",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1903014816190697479/pu/img/6cad6yj70hPxRsrk.jpg",
            "id_str" : "1903014816190697479",
            "video_info" : {
              "aspect_ratio" : [
                "16",
                "9"
              ],
              "duration_millis" : "136649",
              "variants" : [
                {
                  "bitrate" : "256000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1903014816190697479/pu/vid/avc1/480x270/zzmeuXkYYH0tpFu8.mp4?tag=12"
                },
                {
                  "bitrate" : "2176000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1903014816190697479/pu/vid/avc1/1280x720/wuSRPp_XoBFCUnjO.mp4?tag=12"
                },
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/1903014816190697479/pu/pl/u6EbxNFouzJ5oRyu.m3u8?tag=12&v=97a"
                },
                {
                  "bitrate" : "832000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1903014816190697479/pu/vid/avc1/640x360/P7V3as0Cx5OHdIxB.mp4?tag=12"
                }
              ]
            },
            "source_user_id" : "1346102096148324353",
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1903014816190697479",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1903014816190697479/pu/img/6cad6yj70hPxRsrk.jpg",
            "source_user_id_str" : "1346102096148324353",
            "sizes" : {
              "large" : {
                "w" : "1920",
                "h" : "1080",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "source_status_id_str" : "1903250273885360584",
            "display_url" : "pic.x.com/l6InCm2bx4"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1903023933919727860"
          ],
          "editableUntil" : "2025-03-21T11:00:36.978Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "uec25",
            "indices" : [
              "113",
              "119"
            ]
          },
          {
            "text" : "春から電通大",
            "indices" : [
              "120",
              "127"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "電気通信大学 2025年度新入生歓迎会【公式】",
            "screen_name" : "uecshinkan_info",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "1346102096148324353",
            "id" : "1346102096148324353"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1903023933919727860",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1903023933919727860",
      "created_at" : "Fri Mar 21 10:00:36 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecshinkan_info: スポーツチャンバラ同好会の紹介です！\n\nスポーツチャンバラ同好会です！\n毎週火・木16:30～18:00に第2体育館2階で活動しています！初心者の方、軽く運動したい方大歓迎です！！\n\n#uec25 #春から電通大 https://t.c…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1902849387300261960"
          ],
          "editableUntil" : "2025-03-20T23:27:01.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1902849005065027846",
      "id_str" : "1902849387300261960",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1902849387300261960",
      "in_reply_to_status_id" : "1902849005065027846",
      "created_at" : "Thu Mar 20 22:27:01 +0000 2025",
      "favorited" : false,
      "full_text" : "でもこのカードをどう使うんか知らんのよね。圧倒的にカイちゃんのほうが使いやすい",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1902849005065027846"
          ],
          "editableUntil" : "2025-03-20T23:25:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1902849005065027846/photo/1",
            "indices" : [
              "11",
              "34"
            ],
            "url" : "https://t.co/F5ZRAQJOZY",
            "media_url" : "http://pbs.twimg.com/media/GmhHFfqaMAAoqNE.jpg",
            "id_str" : "1902849002288328704",
            "id" : "1902849002288328704",
            "media_url_https" : "https://pbs.twimg.com/media/GmhHFfqaMAAoqNE.jpg",
            "sizes" : {
              "large" : {
                "w" : "922",
                "h" : "2048",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "540",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "306",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/F5ZRAQJOZY"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "0",
      "id_str" : "1902849005065027846",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1902849005065027846",
      "possibly_sensitive" : false,
      "created_at" : "Thu Mar 20 22:25:30 +0000 2025",
      "favorited" : false,
      "full_text" : "え…しゅき…🥰😍🤩🥳 https://t.co/F5ZRAQJOZY",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1902849005065027846/photo/1",
            "indices" : [
              "11",
              "34"
            ],
            "url" : "https://t.co/F5ZRAQJOZY",
            "media_url" : "http://pbs.twimg.com/media/GmhHFfqaMAAoqNE.jpg",
            "id_str" : "1902849002288328704",
            "id" : "1902849002288328704",
            "media_url_https" : "https://pbs.twimg.com/media/GmhHFfqaMAAoqNE.jpg",
            "sizes" : {
              "large" : {
                "w" : "922",
                "h" : "2048",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "540",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "306",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/F5ZRAQJOZY"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1902842617416782255"
          ],
          "editableUntil" : "2025-03-20T23:00:07.755Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1902720893547335934/video/1",
            "source_status_id" : "1902720893547335934",
            "indices" : [
              "42",
              "65"
            ],
            "url" : "https://t.co/dOTND4ctGl",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1902720844323041280/pu/img/IcVls4q5PzU81yEn.jpg",
            "id_str" : "1902720844323041280",
            "source_user_id" : "1624283203870801920",
            "id" : "1902720844323041280",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1902720844323041280/pu/img/IcVls4q5PzU81yEn.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1902720893547335934",
            "display_url" : "pic.x.com/dOTND4ctGl"
          }
        ],
        "hashtags" : [
          {
            "text" : "春から電通大",
            "indices" : [
              "27",
              "34"
            ]
          },
          {
            "text" : "uec25",
            "indices" : [
              "35",
              "41"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "0",
      "id_str" : "1902842617416782255",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1902842617416782255",
      "possibly_sensitive" : false,
      "created_at" : "Thu Mar 20 22:00:07 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: やらかしたこと①\n#春から電通大\n#uec25 https://t.co/dOTND4ctGl",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1902720893547335934/video/1",
            "source_status_id" : "1902720893547335934",
            "indices" : [
              "42",
              "65"
            ],
            "url" : "https://t.co/dOTND4ctGl",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1902720844323041280/pu/img/IcVls4q5PzU81yEn.jpg",
            "id_str" : "1902720844323041280",
            "video_info" : {
              "aspect_ratio" : [
                "16",
                "9"
              ],
              "duration_millis" : "42154",
              "variants" : [
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/1902720844323041280/pu/pl/Od2MEY726DIOcFhH.m3u8?tag=12"
                },
                {
                  "bitrate" : "256000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1902720844323041280/pu/vid/avc1/480x270/uPJjMd84MCbEuQj8.mp4?tag=12"
                },
                {
                  "bitrate" : "2176000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1902720844323041280/pu/vid/avc1/1280x720/aajJ2pU0gWl_E9L6.mp4?tag=12"
                },
                {
                  "bitrate" : "832000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1902720844323041280/pu/vid/avc1/640x360/SD-QC2GX3O96EgrT.mp4?tag=12"
                }
              ]
            },
            "source_user_id" : "1624283203870801920",
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1902720844323041280",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1902720844323041280/pu/img/IcVls4q5PzU81yEn.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "source_status_id_str" : "1902720893547335934",
            "display_url" : "pic.x.com/dOTND4ctGl"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1902373019290378316"
          ],
          "editableUntil" : "2025-03-19T15:54:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "14"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1902371791982784937",
      "id_str" : "1902373019290378316",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1902373019290378316",
      "in_reply_to_status_id" : "1902371791982784937",
      "created_at" : "Wed Mar 19 14:54:06 +0000 2025",
      "favorited" : false,
      "full_text" : "いや、原因色々考えられるな…",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1902371791982784937"
          ],
          "editableUntil" : "2025-03-19T15:49:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1902371791982784937/photo/1",
            "indices" : [
              "41",
              "64"
            ],
            "url" : "https://t.co/mGrNS9RQIO",
            "media_url" : "http://pbs.twimg.com/media/GmaVEB0a8AIUh_6.jpg",
            "id_str" : "1902371789050933250",
            "id" : "1902371789050933250",
            "media_url_https" : "https://pbs.twimg.com/media/GmaVEB0a8AIUh_6.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/mGrNS9RQIO"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "64"
      ],
      "favorite_count" : "11",
      "id_str" : "1902371791982784937",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1902371791982784937",
      "possibly_sensitive" : false,
      "created_at" : "Wed Mar 19 14:49:14 +0000 2025",
      "favorited" : false,
      "full_text" : "高校の時に大学名隠すための折り紙巻いてたらなんかいつの間にか爆発してた…こっわ。 https://t.co/mGrNS9RQIO",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1902371791982784937/photo/1",
            "indices" : [
              "41",
              "64"
            ],
            "url" : "https://t.co/mGrNS9RQIO",
            "media_url" : "http://pbs.twimg.com/media/GmaVEB0a8AIUh_6.jpg",
            "id_str" : "1902371789050933250",
            "id" : "1902371789050933250",
            "media_url_https" : "https://pbs.twimg.com/media/GmaVEB0a8AIUh_6.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/mGrNS9RQIO"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1902371342550470901"
          ],
          "editableUntil" : "2025-03-19T15:47:27.071Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1902371342550470901",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1902371342550470901",
      "created_at" : "Wed Mar 19 14:47:27 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 【スポーツチャンバラの魅力】\n「当てたら勝ち、当てられたら負け」の分かりやすいルールで、男女問わず楽しむことができるスポーツです！！\nどんな戦い方をするかは自分次第、各々が個性的なスタイルで対戦しています！！\n\n気になった方はぜひ入学後の見学…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1902137116806791309"
          ],
          "editableUntil" : "2025-03-19T00:16:43.302Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1902137116806791309",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1902137116806791309",
      "created_at" : "Tue Mar 18 23:16:43 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 🗡️スポーツチャンバラの武器紹介！Part①⚔️\n剣は最もメジャーで扱いやすい武器。エアーソフト剣という中に空気を入れたもので当たってもほとんど痛くない！\n長さによって名前が変わり、45cmの短刀、60cmの小太刀、100cmの長剣の三種類が…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1902002556215210053"
          ],
          "editableUntil" : "2025-03-18T15:22:01.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1902002556215210053/photo/1",
            "indices" : [
              "21",
              "44"
            ],
            "url" : "https://t.co/VHZn1bjAOk",
            "media_url" : "http://pbs.twimg.com/media/GmVFPnubAAAfxxG.jpg",
            "id_str" : "1902002552297947136",
            "id" : "1902002552297947136",
            "media_url_https" : "https://pbs.twimg.com/media/GmVFPnubAAAfxxG.jpg",
            "sizes" : {
              "large" : {
                "w" : "1869",
                "h" : "2048",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1095",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "621",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/VHZn1bjAOk"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "44"
      ],
      "favorite_count" : "6",
      "id_str" : "1902002556215210053",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1902002556215210053",
      "possibly_sensitive" : false,
      "created_at" : "Tue Mar 18 14:22:01 +0000 2025",
      "favorited" : false,
      "full_text" : "部屋の掃除してたらルイージの亡霊でてきた https://t.co/VHZn1bjAOk",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1902002556215210053/photo/1",
            "indices" : [
              "21",
              "44"
            ],
            "url" : "https://t.co/VHZn1bjAOk",
            "media_url" : "http://pbs.twimg.com/media/GmVFPnubAAAfxxG.jpg",
            "id_str" : "1902002552297947136",
            "id" : "1902002552297947136",
            "media_url_https" : "https://pbs.twimg.com/media/GmVFPnubAAAfxxG.jpg",
            "sizes" : {
              "large" : {
                "w" : "1869",
                "h" : "2048",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1095",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "621",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/VHZn1bjAOk"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1901644606472892681"
          ],
          "editableUntil" : "2025-03-17T15:39:39.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "id_str" : "1901644606472892681",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1901644606472892681",
      "created_at" : "Mon Mar 17 14:39:39 +0000 2025",
      "favorited" : false,
      "full_text" : "やばいめっちゃ嬉しい…！\nまあcanvaのテンプレ使ってるんすけどね…()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1901628793313488937"
          ],
          "editableUntil" : "2025-03-17T14:36:49.537Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "スポチャン",
            "indices" : [
              "120",
              "126"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1901628793313488937",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1901628793313488937",
      "created_at" : "Mon Mar 17 13:36:49 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 🛡️スポーツチャンバラの面（メン）紹介！🛡️\n頭部を守るための防具で、フェイスガード付きのものが一般的。（計4種）\nこれをつければ、全力で戦っても安心💪✨\nスポチャンを始めるなら、まずは防具をチェック！ #スポチャン https://t.co…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1901628781905019303"
          ],
          "editableUntil" : "2025-03-17T14:36:46.817Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1900893812576145512/photo/1",
            "source_status_id" : "1900893812576145512",
            "indices" : [
              "103",
              "126"
            ],
            "url" : "https://t.co/TxgUeqrEfl",
            "media_url" : "http://pbs.twimg.com/media/GmFU1ftasAAgXrt.jpg",
            "id_str" : "1900893795748851712",
            "source_user_id" : "1624283203870801920",
            "id" : "1900893795748851712",
            "media_url_https" : "https://pbs.twimg.com/media/GmFU1ftasAAgXrt.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "511",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1280",
                "h" : "961",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "901",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1900893812576145512",
            "display_url" : "pic.x.com/TxgUeqrEfl"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "126"
      ],
      "favorite_count" : "0",
      "id_str" : "1901628781905019303",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1901628781905019303",
      "possibly_sensitive" : false,
      "created_at" : "Mon Mar 17 13:36:46 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 電通大スポーツチャンバラサークルはスポーツチャンバラだけでなく夏は花火、冬はスキーなど様々なイベントもやってます！\n\n一度きりの大学生活、いろんなことを楽しみつくそう！ https://t.co/TxgUeqrEfl",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1900893812576145512/photo/1",
            "source_status_id" : "1900893812576145512",
            "indices" : [
              "103",
              "126"
            ],
            "url" : "https://t.co/TxgUeqrEfl",
            "media_url" : "http://pbs.twimg.com/media/GmFU1ftasAAgXrt.jpg",
            "id_str" : "1900893795748851712",
            "source_user_id" : "1624283203870801920",
            "id" : "1900893795748851712",
            "media_url_https" : "https://pbs.twimg.com/media/GmFU1ftasAAgXrt.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "511",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1280",
                "h" : "961",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "901",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1900893812576145512",
            "display_url" : "pic.x.com/TxgUeqrEfl"
          },
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1900893812576145512/photo/1",
            "source_status_id" : "1900893812576145512",
            "indices" : [
              "103",
              "126"
            ],
            "url" : "https://t.co/TxgUeqrEfl",
            "media_url" : "http://pbs.twimg.com/media/GmFU1fwbcAMQw3v.jpg",
            "id_str" : "1900893795761483779",
            "source_user_id" : "1624283203870801920",
            "id" : "1900893795761483779",
            "media_url_https" : "https://pbs.twimg.com/media/GmFU1fwbcAMQw3v.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1900893812576145512",
            "display_url" : "pic.x.com/TxgUeqrEfl"
          },
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1900893812576145512/photo/1",
            "source_status_id" : "1900893812576145512",
            "indices" : [
              "103",
              "126"
            ],
            "url" : "https://t.co/TxgUeqrEfl",
            "media_url" : "http://pbs.twimg.com/media/GmFU1fuasAA8eM_.jpg",
            "id_str" : "1900893795753046016",
            "source_user_id" : "1624283203870801920",
            "id" : "1900893795753046016",
            "media_url_https" : "https://pbs.twimg.com/media/GmFU1fuasAA8eM_.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "1706",
                "h" : "960",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1900893812576145512",
            "display_url" : "pic.x.com/TxgUeqrEfl"
          },
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1900893812576145512/photo/1",
            "source_status_id" : "1900893812576145512",
            "indices" : [
              "103",
              "126"
            ],
            "url" : "https://t.co/TxgUeqrEfl",
            "media_url" : "http://pbs.twimg.com/media/GmFU1fvbcAEq1lj.jpg",
            "id_str" : "1900893795757289473",
            "source_user_id" : "1624283203870801920",
            "id" : "1900893795757289473",
            "media_url_https" : "https://pbs.twimg.com/media/GmFU1fvbcAEq1lj.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1900893812576145512",
            "display_url" : "pic.x.com/TxgUeqrEfl"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1901113600418476202"
          ],
          "editableUntil" : "2025-03-16T04:29:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "id_str" : "1901113600418476202",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1901113600418476202",
      "created_at" : "Sun Mar 16 03:29:37 +0000 2025",
      "favorited" : false,
      "full_text" : "熱いもん食っても冷てえもん食っても歯が痛えのちょっとまずい気がしてきた",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1900878228132425850"
          ],
          "editableUntil" : "2025-03-15T12:54:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "56"
      ],
      "favorite_count" : "2",
      "id_str" : "1900878228132425850",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1900878228132425850",
      "created_at" : "Sat Mar 15 11:54:20 +0000 2025",
      "favorited" : false,
      "full_text" : "小学校6年間と高校3年間、大学1年間使い続けた歩道橋がなくなっちゃうの悲しすぎる…\nまあだいぶ古かったからなあ…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1900566222540079125"
          ],
          "editableUntil" : "2025-03-14T16:14:32.923Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1900566222540079125",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1900566222540079125",
      "created_at" : "Fri Mar 14 15:14:32 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 電通大スポーツチャンバラサークルは、火・木曜日の16:30〜18:00に活動を行っています！毎日参加する人もいれば、月1くらいで参加する人、合宿だけ参加する人、大会にも出場する人がいるなど、参加頻度を比較的自由に決められるサークルです！1年生…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1900024086740557955"
          ],
          "editableUntil" : "2025-03-13T04:20:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "1",
      "id_str" : "1900024086740557955",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1900024086740557955",
      "created_at" : "Thu Mar 13 03:20:17 +0000 2025",
      "favorited" : false,
      "full_text" : "サファリパークに来たのに22mmの単焦点1本しか持ってきてないの普通に詰み()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1900023725246079143"
          ],
          "editableUntil" : "2025-03-13T04:18:51.489Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1899990855941054588/video/1",
            "source_status_id" : "1899990855941054588",
            "indices" : [
              "34",
              "57"
            ],
            "url" : "https://t.co/ECJa8wwfwG",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1899990831328534528/pu/img/fZKuX3qOOoObe_h5.jpg",
            "id_str" : "1899990831328534528",
            "source_user_id" : "1624283203870801920",
            "id" : "1899990831328534528",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1899990831328534528/pu/img/fZKuX3qOOoObe_h5.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1899990855941054588",
            "display_url" : "pic.x.com/ECJa8wwfwG"
          }
        ],
        "hashtags" : [
          {
            "text" : "春から電通大",
            "indices" : [
              "18",
              "25"
            ]
          },
          {
            "text" : "uec25",
            "indices" : [
              "27",
              "33"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "57"
      ],
      "favorite_count" : "0",
      "id_str" : "1900023725246079143",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1900023725246079143",
      "possibly_sensitive" : false,
      "created_at" : "Thu Mar 13 03:18:51 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: #春から電通大 \n#uec25 https://t.co/ECJa8wwfwG",
      "lang" : "qme",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1899990855941054588/video/1",
            "source_status_id" : "1899990855941054588",
            "indices" : [
              "34",
              "57"
            ],
            "url" : "https://t.co/ECJa8wwfwG",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1899990831328534528/pu/img/fZKuX3qOOoObe_h5.jpg",
            "id_str" : "1899990831328534528",
            "video_info" : {
              "aspect_ratio" : [
                "16",
                "9"
              ],
              "duration_millis" : "18633",
              "variants" : [
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/1899990831328534528/pu/pl/HF96impnLtd3nezn.m3u8?tag=12&v=cfc"
                },
                {
                  "bitrate" : "256000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1899990831328534528/pu/vid/avc1/480x270/r9C70_XH0OkI2v_B.mp4?tag=12"
                },
                {
                  "bitrate" : "2176000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1899990831328534528/pu/vid/avc1/1280x720/hY1qQcuTUdWCDFeM.mp4?tag=12"
                },
                {
                  "bitrate" : "832000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1899990831328534528/pu/vid/avc1/640x360/paNBHFTFPJxaNyHq.mp4?tag=12"
                }
              ]
            },
            "source_user_id" : "1624283203870801920",
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1899990831328534528",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1899990831328534528/pu/img/fZKuX3qOOoObe_h5.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "source_status_id_str" : "1899990855941054588",
            "display_url" : "pic.x.com/ECJa8wwfwG"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1899775914453725562"
          ],
          "editableUntil" : "2025-03-12T11:54:08.792Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1899581786872758729/photo/1",
            "source_status_id" : "1899581786872758729",
            "indices" : [
              "116",
              "139"
            ],
            "url" : "https://t.co/vadgHg0KTY",
            "media_url" : "http://pbs.twimg.com/media/Glyrj11aYAAixLA.jpg",
            "id_str" : "1899581775078383616",
            "source_user_id" : "1624283203870801920",
            "id" : "1899581775078383616",
            "media_url_https" : "https://pbs.twimg.com/media/Glyrj11aYAAixLA.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1899581786872758729",
            "display_url" : "pic.x.com/vadgHg0KTY"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1899775914453725562",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1899775914453725562",
      "possibly_sensitive" : false,
      "created_at" : "Wed Mar 12 10:54:08 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 本日は後期試験本番ですね。\n受験生の皆さんは今までやってきたことを信じて、落ち着いて試験に臨んでください！きっと結果はついてくるはずです！\n\n電通大スポーツチャンバラ同好会でお待ちしています！！ https://t.co/vadgHg0KTY",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1899581786872758729/photo/1",
            "source_status_id" : "1899581786872758729",
            "indices" : [
              "116",
              "139"
            ],
            "url" : "https://t.co/vadgHg0KTY",
            "media_url" : "http://pbs.twimg.com/media/Glyrj11aYAAixLA.jpg",
            "id_str" : "1899581775078383616",
            "source_user_id" : "1624283203870801920",
            "id" : "1899581775078383616",
            "media_url_https" : "https://pbs.twimg.com/media/Glyrj11aYAAixLA.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1899581786872758729",
            "display_url" : "pic.x.com/vadgHg0KTY"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1899387177324474386"
          ],
          "editableUntil" : "2025-03-11T10:09:26.638Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1899387177324474386",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1899387177324474386",
      "created_at" : "Tue Mar 11 09:09:26 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 1年生の内、半分は4月から基礎科学実験Aという科目でLaTeXを使います。コンピュータリテラシーでLaTeXを習うのは一学期の後半なので、環境構築と練習を事前にしておくと好ましいです。\n\n筆者が参考にしたサイトはこちら：https://t.c…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1899074815602184194"
          ],
          "editableUntil" : "2025-03-10T13:28:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "琥珀",
            "screen_name" : "mezase_kenzenn",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1570697638068252674",
            "id" : "1570697638068252674"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "26"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1899072988340723836",
      "id_str" : "1899074815602184194",
      "in_reply_to_user_id" : "1570697638068252674",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1899074815602184194",
      "in_reply_to_status_id" : "1899072988340723836",
      "created_at" : "Mon Mar 10 12:28:13 +0000 2025",
      "favorited" : false,
      "full_text" : "@mezase_kenzenn 私も知らんかった()",
      "lang" : "ja",
      "in_reply_to_screen_name" : "mezase_kenzenn",
      "in_reply_to_user_id_str" : "1570697638068252674"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1898732716046360722"
          ],
          "editableUntil" : "2025-03-09T14:48:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "uec24",
            "indices" : [
              "0",
              "6"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "17"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1898732248012382266",
      "id_str" : "1898732716046360722",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1898732716046360722",
      "in_reply_to_status_id" : "1898732248012382266",
      "created_at" : "Sun Mar 09 13:48:50 +0000 2025",
      "favorited" : false,
      "full_text" : "#uec24 \n1年Ⅱ類 5クラス",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1898732248012382266"
          ],
          "editableUntil" : "2025-03-09T14:46:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1898732248012382266/photo/1",
            "indices" : [
              "99",
              "122"
            ],
            "url" : "https://t.co/RKeEYVeTjH",
            "media_url" : "http://pbs.twimg.com/media/Glmm6lSbAAA7pSr.jpg",
            "id_str" : "1898732243285377024",
            "id" : "1898732243285377024",
            "media_url_https" : "https://pbs.twimg.com/media/Glmm6lSbAAA7pSr.jpg",
            "sizes" : {
              "small" : {
                "w" : "635",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1080",
                "h" : "1156",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1080",
                "h" : "1156",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/RKeEYVeTjH"
          }
        ],
        "hashtags" : [
          {
            "text" : "uec_review",
            "indices" : [
              "0",
              "11"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "122"
      ],
      "favorite_count" : "14",
      "id_str" : "1898732248012382266",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1898732248012382266",
      "possibly_sensitive" : false,
      "created_at" : "Sun Mar 09 13:46:59 +0000 2025",
      "favorited" : false,
      "full_text" : "#uec_review\n今日暇だったので書いてみました。\n・1限が少ないのはまだ良かったです。\n・GPAは高くも低くもなく面白みがないので公開しません。\n・先生のつづり合ってる確証ないです...。 https://t.co/RKeEYVeTjH",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1898732248012382266/photo/1",
            "indices" : [
              "99",
              "122"
            ],
            "url" : "https://t.co/RKeEYVeTjH",
            "media_url" : "http://pbs.twimg.com/media/Glmm6lSbAAA7pSr.jpg",
            "id_str" : "1898732243285377024",
            "id" : "1898732243285377024",
            "media_url_https" : "https://pbs.twimg.com/media/Glmm6lSbAAA7pSr.jpg",
            "sizes" : {
              "small" : {
                "w" : "635",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1080",
                "h" : "1156",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1080",
                "h" : "1156",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/RKeEYVeTjH"
          },
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1898732248012382266/photo/1",
            "indices" : [
              "99",
              "122"
            ],
            "url" : "https://t.co/RKeEYVeTjH",
            "media_url" : "http://pbs.twimg.com/media/Glmm6liaEAAX5oJ.jpg",
            "id_str" : "1898732243352424448",
            "id" : "1898732243352424448",
            "media_url_https" : "https://pbs.twimg.com/media/Glmm6liaEAAX5oJ.jpg",
            "sizes" : {
              "small" : {
                "w" : "641",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1080",
                "h" : "1145",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1080",
                "h" : "1145",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/RKeEYVeTjH"
          },
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1898732248012382266/photo/1",
            "indices" : [
              "99",
              "122"
            ],
            "url" : "https://t.co/RKeEYVeTjH",
            "media_url" : "http://pbs.twimg.com/media/Glmm6rAa4AAyy_E.jpg",
            "id_str" : "1898732244820484096",
            "id" : "1898732244820484096",
            "media_url_https" : "https://pbs.twimg.com/media/Glmm6rAa4AAyy_E.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "481",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "848",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1430",
                "h" : "1011",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/RKeEYVeTjH"
          },
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1898732248012382266/photo/1",
            "indices" : [
              "99",
              "122"
            ],
            "url" : "https://t.co/RKeEYVeTjH",
            "media_url" : "http://pbs.twimg.com/media/Glmm6uEasAAfLqz.jpg",
            "id_str" : "1898732245642555392",
            "id" : "1898732245642555392",
            "media_url_https" : "https://pbs.twimg.com/media/Glmm6uEasAAfLqz.jpg",
            "sizes" : {
              "large" : {
                "w" : "1430",
                "h" : "1011",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "481",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "848",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/RKeEYVeTjH"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1898694268040143233"
          ],
          "editableUntil" : "2025-03-09T12:16:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1898694268040143233/photo/1",
            "indices" : [
              "55",
              "78"
            ],
            "url" : "https://t.co/Ec0Fdb5XcB",
            "media_url" : "http://pbs.twimg.com/media/GlmEYBbbwAAlL2f.jpg",
            "id_str" : "1898694266148601856",
            "id" : "1898694266148601856",
            "media_url_https" : "https://pbs.twimg.com/media/GlmEYBbbwAAlL2f.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1080",
                "h" : "588",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "370",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1080",
                "h" : "588",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/Ec0Fdb5XcB"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "78"
      ],
      "favorite_count" : "0",
      "id_str" : "1898694268040143233",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1898694268040143233",
      "possibly_sensitive" : false,
      "created_at" : "Sun Mar 09 11:16:04 +0000 2025",
      "favorited" : false,
      "full_text" : "大学の情報を吐いてそうなやつはじゃんじゃん入れるぞー！目指せ50人！！！\nとかやってるとブロックされそう() https://t.co/Ec0Fdb5XcB",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1898694268040143233/photo/1",
            "indices" : [
              "55",
              "78"
            ],
            "url" : "https://t.co/Ec0Fdb5XcB",
            "media_url" : "http://pbs.twimg.com/media/GlmEYBbbwAAlL2f.jpg",
            "id_str" : "1898694266148601856",
            "id" : "1898694266148601856",
            "media_url_https" : "https://pbs.twimg.com/media/GlmEYBbbwAAlL2f.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1080",
                "h" : "588",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "370",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1080",
                "h" : "588",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/Ec0Fdb5XcB"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1898679395289813095"
          ],
          "editableUntil" : "2025-03-09T11:16:58.251Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1898679395289813095",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1898679395289813095",
      "created_at" : "Sun Mar 09 10:16:58 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 春から電通大に入学する皆さんへ！1年次には『基礎プログラミング』というC言語の授業があります。最初は戸惑うかもしれませんが、事前に少し触れておくとかなり楽になります！\nそこでオススメなのが…\n📖『動かして学ぶ！C言語ゲームプログラミング入門』…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1898365815621386655"
          ],
          "editableUntil" : "2025-03-08T14:30:55.032Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "春から電通大",
            "indices" : [
              "22",
              "29"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "電気通信大学X680x0同好会",
            "screen_name" : "x68uec",
            "indices" : [
              "3",
              "10"
            ],
            "id_str" : "1184772032",
            "id" : "1184772032"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1898365815621386655",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1898365815621386655",
      "created_at" : "Sat Mar 08 13:30:55 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @x68uec: 少々遅れましたが…\n#春から電通大 の皆様、\n合格おめでとうございます🌸\n\nX680x0同好会はゲーム制作を中心にプログラミングや楽曲制作、イラスト作成を行うサークルです。未経験でも講座を通して学べます！\n\nゲーム制作・イラスト・作曲に興味のある方はぜひ…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1898364830928744841"
          ],
          "editableUntil" : "2025-03-08T14:27:00.263Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1898300620572139719/photo/1",
            "source_status_id" : "1898300620572139719",
            "indices" : [
              "86",
              "109"
            ],
            "url" : "https://t.co/mJ5y3PBQC6",
            "media_url" : "http://pbs.twimg.com/media/GlgeWBgaUAA1G92.jpg",
            "id_str" : "1898300606646996992",
            "source_user_id" : "1624283203870801920",
            "id" : "1898300606646996992",
            "media_url_https" : "https://pbs.twimg.com/media/GlgeWBgaUAA1G92.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "780",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1332",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "442",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1898300620572139719",
            "display_url" : "pic.x.com/mJ5y3PBQC6"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "109"
      ],
      "favorite_count" : "0",
      "id_str" : "1898364830928744841",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1898364830928744841",
      "possibly_sensitive" : false,
      "created_at" : "Sat Mar 08 13:27:00 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: こんにちは、電通大スポーツチャンバラ同好会です！\n\n本日は電通大生のお昼ご飯事情について紹介します🤩\n\nぜひ参考にしてみてくださいね♫ https://t.co/mJ5y3PBQC6",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1898300620572139719/photo/1",
            "source_status_id" : "1898300620572139719",
            "indices" : [
              "86",
              "109"
            ],
            "url" : "https://t.co/mJ5y3PBQC6",
            "media_url" : "http://pbs.twimg.com/media/GlgeWBgaUAA1G92.jpg",
            "id_str" : "1898300606646996992",
            "source_user_id" : "1624283203870801920",
            "id" : "1898300606646996992",
            "media_url_https" : "https://pbs.twimg.com/media/GlgeWBgaUAA1G92.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "780",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1332",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "442",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1898300620572139719",
            "display_url" : "pic.x.com/mJ5y3PBQC6"
          },
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1898300620572139719/photo/1",
            "source_status_id" : "1898300620572139719",
            "indices" : [
              "86",
              "109"
            ],
            "url" : "https://t.co/mJ5y3PBQC6",
            "media_url" : "http://pbs.twimg.com/media/GlgeWBdaoAA6ypU.jpg",
            "id_str" : "1898300606634434560",
            "source_user_id" : "1624283203870801920",
            "id" : "1898300606634434560",
            "media_url_https" : "https://pbs.twimg.com/media/GlgeWBdaoAA6ypU.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "442",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1332",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "780",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1898300620572139719",
            "display_url" : "pic.x.com/mJ5y3PBQC6"
          },
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1898300620572139719/photo/1",
            "source_status_id" : "1898300620572139719",
            "indices" : [
              "86",
              "109"
            ],
            "url" : "https://t.co/mJ5y3PBQC6",
            "media_url" : "http://pbs.twimg.com/media/GlgeWBdbkAAL5oR.jpg",
            "id_str" : "1898300606634496000",
            "source_user_id" : "1624283203870801920",
            "id" : "1898300606634496000",
            "media_url_https" : "https://pbs.twimg.com/media/GlgeWBdbkAAL5oR.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "442",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1332",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "780",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1898300620572139719",
            "display_url" : "pic.x.com/mJ5y3PBQC6"
          },
          {
            "expanded_url" : "https://x.com/uecspochan25/status/1898300620572139719/photo/1",
            "source_status_id" : "1898300620572139719",
            "indices" : [
              "86",
              "109"
            ],
            "url" : "https://t.co/mJ5y3PBQC6",
            "media_url" : "http://pbs.twimg.com/media/GlgeWBebUAADxkD.jpg",
            "id_str" : "1898300606638673920",
            "source_user_id" : "1624283203870801920",
            "id" : "1898300606638673920",
            "media_url_https" : "https://pbs.twimg.com/media/GlgeWBebUAADxkD.jpg",
            "source_user_id_str" : "1624283203870801920",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "780",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "442",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1332",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1898300620572139719",
            "display_url" : "pic.x.com/mJ5y3PBQC6"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1897982071362159021"
          ],
          "editableUntil" : "2025-03-07T13:06:03.271Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "84"
      ],
      "favorite_count" : "0",
      "id_str" : "1897982071362159021",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1897982071362159021",
      "created_at" : "Fri Mar 07 12:06:03 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 電通大スポーツチャンバラサークルは経験の有無に関わらず募集しています！！\n少しでも興味があれば是非来てみてください！！待ってます！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1897837106162286810"
          ],
          "editableUntil" : "2025-03-07T03:30:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1897837106162286810/photo/1",
            "indices" : [
              "43",
              "66"
            ],
            "url" : "https://t.co/12bCV85YVt",
            "media_url" : "http://pbs.twimg.com/media/GlZ4ynmbwAE0R5A.jpg",
            "id_str" : "1897837104002220033",
            "id" : "1897837104002220033",
            "media_url_https" : "https://pbs.twimg.com/media/GlZ4ynmbwAE0R5A.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1920",
                "h" : "1080",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/12bCV85YVt"
          }
        ],
        "hashtags" : [
          {
            "text" : "MyXAnniversary",
            "indices" : [
              "27",
              "42"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "66"
      ],
      "favorite_count" : "0",
      "id_str" : "1897837106162286810",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1897837106162286810",
      "possibly_sensitive" : false,
      "created_at" : "Fri Mar 07 02:30:00 +0000 2025",
      "favorited" : false,
      "full_text" : "Xに登録した日を覚えていますか？\n1日遅れだったんだ #MyXAnniversary https://t.co/12bCV85YVt",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1897837106162286810/photo/1",
            "indices" : [
              "43",
              "66"
            ],
            "url" : "https://t.co/12bCV85YVt",
            "media_url" : "http://pbs.twimg.com/media/GlZ4ynmbwAE0R5A.jpg",
            "id_str" : "1897837104002220033",
            "id" : "1897837104002220033",
            "media_url_https" : "https://pbs.twimg.com/media/GlZ4ynmbwAE0R5A.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1920",
                "h" : "1080",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/12bCV85YVt"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1897625960608043343"
          ],
          "editableUntil" : "2025-03-06T13:30:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "0",
      "id_str" : "1897625960608043343",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1897625960608043343",
      "created_at" : "Thu Mar 06 12:30:59 +0000 2025",
      "favorited" : false,
      "full_text" : "もしかしたら去年の3月にffだったけど、わざと私をブロ解した人もいるのか。申し訳ないです。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1897624706498629828"
          ],
          "editableUntil" : "2025-03-06T13:26:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "27"
      ],
      "favorite_count" : "0",
      "id_str" : "1897624706498629828",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1897624706498629828",
      "created_at" : "Thu Mar 06 12:26:00 +0000 2025",
      "favorited" : false,
      "full_text" : "どさくさにフォローしたかった人たちフォロー飛ばしていく",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1897524882113749004"
          ],
          "editableUntil" : "2025-03-06T06:49:20.860Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "春から電通大",
            "indices" : [
              "128",
              "135"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UECスポーツチャンバラ同好会",
            "screen_name" : "uecspochan25",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1624283203870801920",
            "id" : "1624283203870801920"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1897524882113749004",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1897524882113749004",
      "created_at" : "Thu Mar 06 05:49:20 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uecspochan25: 初めまして！\nスポーツチャンバラ同好会です！\n前期試験に合格された皆さん、おめでとうございます🌸\n\nこれからスポーツチャンバラに関すること+お役立ち(？)情報をたくさん発信していくので、ぜひフォローしてみてください😊\n\n#春から電通大\n#ue…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1897476699962650636"
          ],
          "editableUntil" : "2025-03-06T03:37:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "uec25",
            "indices" : [
              "59",
              "65"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "2",
      "id_str" : "1897476699962650636",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1897476699962650636",
      "created_at" : "Thu Mar 06 02:37:53 +0000 2025",
      "favorited" : false,
      "full_text" : "Ⅰ類合格かと思っていたらⅡ類だったを見かけて去年を思い出している。\nでも全ての電通大合格者の方おめでとうございます！\n#uec25",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1896877863712051462"
          ],
          "editableUntil" : "2025-03-04T11:58:19.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1896800172367401361",
      "id_str" : "1896877863712051462",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1896877863712051462",
      "in_reply_to_status_id" : "1896800172367401361",
      "created_at" : "Tue Mar 04 10:58:19 +0000 2025",
      "favorited" : false,
      "full_text" : "そういえばめちゃ美味かった。\n逆にいうと失敗してればすぐさま画像付きで自慢してた。良くない思考ですね。",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1896800172367401361"
          ],
          "editableUntil" : "2025-03-04T06:49:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "63"
      ],
      "favorite_count" : "6",
      "id_str" : "1896800172367401361",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1896800172367401361",
      "created_at" : "Tue Mar 04 05:49:36 +0000 2025",
      "favorited" : false,
      "full_text" : "あの、パウンドケーキはまだ簡単って言ったやつ誰ですか？\n卵混ぜるのすら難しいじゃねーか！！！そもそも割るのすらむずいのに！！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1896374017713729932"
          ],
          "editableUntil" : "2025-03-03T02:36:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "32"
      ],
      "favorite_count" : "3",
      "id_str" : "1896374017713729932",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1896374017713729932",
      "created_at" : "Mon Mar 03 01:36:13 +0000 2025",
      "favorited" : false,
      "full_text" : "成績発表よりひな祭りでひなあられ食べられることを喜びませんか‼️",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1896372886417596675"
          ],
          "editableUntil" : "2025-03-03T02:31:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "1",
      "id_str" : "1896372886417596675",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1896372886417596675",
      "created_at" : "Mon Mar 03 01:31:43 +0000 2025",
      "favorited" : false,
      "full_text" : "フル単ではあるが何をするにもGPA足りんな",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1896176799245320260"
          ],
          "editableUntil" : "2025-03-02T13:32:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "4",
      "id_str" : "1896176799245320260",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1896176799245320260",
      "created_at" : "Sun Mar 02 12:32:32 +0000 2025",
      "favorited" : false,
      "full_text" : "なんかずっと変な臭いするなと思ったら、結ぶの忘れた私の髪がラーメンのスープに浸かってついた臭いでした()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1895372795900760406"
          ],
          "editableUntil" : "2025-02-28T08:17:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1895372508616081552",
      "id_str" : "1895372795900760406",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1895372795900760406",
      "in_reply_to_status_id" : "1895372508616081552",
      "created_at" : "Fri Feb 28 07:17:43 +0000 2025",
      "favorited" : false,
      "full_text" : "靴痛すぎて辛かったし、給料も予想よりもらえない🥲",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1895372508616081552"
          ],
          "editableUntil" : "2025-02-28T08:16:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "6"
      ],
      "favorite_count" : "0",
      "id_str" : "1895372508616081552",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1895372508616081552",
      "created_at" : "Fri Feb 28 07:16:35 +0000 2025",
      "favorited" : false,
      "full_text" : "5連勤バおわ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1895242807562117577"
          ],
          "editableUntil" : "2025-02-27T23:41:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "id_str" : "1895242807562117577",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1895242807562117577",
      "created_at" : "Thu Feb 27 22:41:11 +0000 2025",
      "favorited" : false,
      "full_text" : "電車の中で爆音アラームをかけることで乗り過ごしを回避する覚悟が私には、ある。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1895043219089694912"
          ],
          "editableUntil" : "2025-02-27T10:28:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "0",
      "id_str" : "1895043219089694912",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1895043219089694912",
      "created_at" : "Thu Feb 27 09:28:06 +0000 2025",
      "favorited" : false,
      "full_text" : "スーツの女が一人でゲーセンで遊んでんのって異様なのでは？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1894745402399998117"
          ],
          "editableUntil" : "2025-02-26T14:44:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "41"
      ],
      "favorite_count" : "0",
      "id_str" : "1894745402399998117",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1894745402399998117",
      "created_at" : "Wed Feb 26 13:44:41 +0000 2025",
      "favorited" : false,
      "full_text" : "慣れない靴のせいで足の小指がずっと痺れている()\nあと2日はこの靴使うんだけどな…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1894406954308833466"
          ],
          "editableUntil" : "2025-02-25T16:19:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "0",
      "id_str" : "1894406954308833466",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1894406954308833466",
      "created_at" : "Tue Feb 25 15:19:48 +0000 2025",
      "favorited" : false,
      "full_text" : "ピアス増やしたいけどさすがにもう痛いか。あと父親の反応が怖い。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1894401506012758354"
          ],
          "editableUntil" : "2025-02-25T15:58:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "54"
      ],
      "favorite_count" : "1",
      "id_str" : "1894401506012758354",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1894401506012758354",
      "created_at" : "Tue Feb 25 14:58:09 +0000 2025",
      "favorited" : false,
      "full_text" : "上司にやる気あるやつだと思われてまずい。ポンコツ人間なのにちょっと責任重めの仕事振られそうでほんとにまずい。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1893618378205765741"
          ],
          "editableUntil" : "2025-02-23T12:06:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "1",
      "id_str" : "1893618378205765741",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1893618378205765741",
      "created_at" : "Sun Feb 23 11:06:17 +0000 2025",
      "favorited" : false,
      "full_text" : "バイトはいれた！ただ、終業時刻が明らかに終電より遅い。駅でホームレスごっこでもすっか。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1893571757962903582"
          ],
          "editableUntil" : "2025-02-23T09:01:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "47"
      ],
      "favorite_count" : "2",
      "id_str" : "1893571757962903582",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1893571757962903582",
      "created_at" : "Sun Feb 23 08:01:02 +0000 2025",
      "favorited" : false,
      "full_text" : "バ先からの電話にタイミング合わなすぎてすぐさま出れないから、できたかもしれない仕事ができない…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1893142888151974323"
          ],
          "editableUntil" : "2025-02-22T04:36:52.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "8"
      ],
      "favorite_count" : "0",
      "id_str" : "1893142888151974323",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1893142888151974323",
      "created_at" : "Sat Feb 22 03:36:52 +0000 2025",
      "favorited" : false,
      "full_text" : "ヘリを手配したい",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1893142839279665545"
          ],
          "editableUntil" : "2025-02-22T04:36:40.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "14"
      ],
      "favorite_count" : "0",
      "id_str" : "1893142839279665545",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1893142839279665545",
      "created_at" : "Sat Feb 22 03:36:40 +0000 2025",
      "favorited" : false,
      "full_text" : "ぶっちゃけもう下山飽きた()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1892146279213633903"
          ],
          "editableUntil" : "2025-02-19T10:36:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "9",
      "id_str" : "1892146279213633903",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1892146279213633903",
      "created_at" : "Wed Feb 19 09:36:41 +0000 2025",
      "favorited" : false,
      "full_text" : "やったぜ！！！星野源ライブ当たったぜ！！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1892122271793185100"
          ],
          "editableUntil" : "2025-02-19T09:01:18.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1892122271793185100/photo/1",
            "indices" : [
              "30",
              "53"
            ],
            "url" : "https://t.co/XfhkOrvUYZ",
            "media_url" : "http://pbs.twimg.com/media/GkIrLbkakAAEwvP.jpg",
            "id_str" : "1892122268828078080",
            "id" : "1892122268828078080",
            "media_url_https" : "https://pbs.twimg.com/media/GkIrLbkakAAEwvP.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/XfhkOrvUYZ"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "2",
      "id_str" : "1892122271793185100",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1892122271793185100",
      "possibly_sensitive" : false,
      "created_at" : "Wed Feb 19 08:01:18 +0000 2025",
      "favorited" : false,
      "full_text" : "私、ずっと不登校してたけどそろそろ学校行ってみようと思う。 https://t.co/XfhkOrvUYZ",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1892122271793185100/photo/1",
            "indices" : [
              "30",
              "53"
            ],
            "url" : "https://t.co/XfhkOrvUYZ",
            "media_url" : "http://pbs.twimg.com/media/GkIrLbkakAAEwvP.jpg",
            "id_str" : "1892122268828078080",
            "id" : "1892122268828078080",
            "media_url_https" : "https://pbs.twimg.com/media/GkIrLbkakAAEwvP.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/XfhkOrvUYZ"
          },
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1892122271793185100/photo/1",
            "indices" : [
              "30",
              "53"
            ],
            "url" : "https://t.co/XfhkOrvUYZ",
            "media_url" : "http://pbs.twimg.com/media/GkIrLcqbYAAHFrI.jpg",
            "id_str" : "1892122269121732608",
            "id" : "1892122269121732608",
            "media_url_https" : "https://pbs.twimg.com/media/GkIrLcqbYAAHFrI.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/XfhkOrvUYZ"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1891810007085162593"
          ],
          "editableUntil" : "2025-02-18T12:20:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "47"
      ],
      "favorite_count" : "0",
      "id_str" : "1891810007085162593",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1891810007085162593",
      "created_at" : "Tue Feb 18 11:20:28 +0000 2025",
      "favorited" : false,
      "full_text" : "ゲームの裏技自力で見つけた！\nってときは、大体調べると他の人が先に見つけてるから若干悲しくなる",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1891564655148982391"
          ],
          "editableUntil" : "2025-02-17T20:05:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1891564655148982391/photo/1",
            "indices" : [
              "19",
              "42"
            ],
            "url" : "https://t.co/QC3pfJAnNu",
            "media_url" : "http://pbs.twimg.com/media/GkAwBztaAAAm7CK.jpg",
            "id_str" : "1891564651114266624",
            "id" : "1891564651114266624",
            "media_url_https" : "https://pbs.twimg.com/media/GkAwBztaAAAm7CK.jpg",
            "sizes" : {
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/QC3pfJAnNu"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "2",
      "id_str" : "1891564655148982391",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1891564655148982391",
      "possibly_sensitive" : false,
      "created_at" : "Mon Feb 17 19:05:32 +0000 2025",
      "favorited" : false,
      "full_text" : "まだテーブルシティ行ってないんだよね https://t.co/QC3pfJAnNu",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1891564655148982391/photo/1",
            "indices" : [
              "19",
              "42"
            ],
            "url" : "https://t.co/QC3pfJAnNu",
            "media_url" : "http://pbs.twimg.com/media/GkAwBztaAAAm7CK.jpg",
            "id_str" : "1891564651114266624",
            "id" : "1891564651114266624",
            "media_url_https" : "https://pbs.twimg.com/media/GkAwBztaAAAm7CK.jpg",
            "sizes" : {
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/QC3pfJAnNu"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1891248988239622343"
          ],
          "editableUntil" : "2025-02-16T23:11:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "1",
      "id_str" : "1891248988239622343",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1891248988239622343",
      "created_at" : "Sun Feb 16 22:11:11 +0000 2025",
      "favorited" : false,
      "full_text" : "んで残り12点分はほんとにどこで間違えたん？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1891248852239347920"
          ],
          "editableUntil" : "2025-02-16T23:10:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1891248852239347920/photo/1",
            "indices" : [
              "28",
              "51"
            ],
            "url" : "https://t.co/VjOtU4r0YM",
            "media_url" : "http://pbs.twimg.com/media/Gj8QzyGb0AA7BI8.jpg",
            "id_str" : "1891248850327031808",
            "id" : "1891248850327031808",
            "media_url_https" : "https://pbs.twimg.com/media/Gj8QzyGb0AA7BI8.jpg",
            "sizes" : {
              "large" : {
                "w" : "1080",
                "h" : "608",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1080",
                "h" : "608",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/VjOtU4r0YM"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "1",
      "id_str" : "1891248852239347920",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1891248852239347920",
      "possibly_sensitive" : false,
      "created_at" : "Sun Feb 16 22:10:38 +0000 2025",
      "favorited" : false,
      "full_text" : "スタンプがジャストなタイミングで使えるとすごくうれしい https://t.co/VjOtU4r0YM",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1891248852239347920/photo/1",
            "indices" : [
              "28",
              "51"
            ],
            "url" : "https://t.co/VjOtU4r0YM",
            "media_url" : "http://pbs.twimg.com/media/Gj8QzyGb0AA7BI8.jpg",
            "id_str" : "1891248850327031808",
            "id" : "1891248850327031808",
            "media_url_https" : "https://pbs.twimg.com/media/Gj8QzyGb0AA7BI8.jpg",
            "sizes" : {
              "large" : {
                "w" : "1080",
                "h" : "608",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1080",
                "h" : "608",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/VjOtU4r0YM"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1891019132134412701"
          ],
          "editableUntil" : "2025-02-16T07:57:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "0",
      "id_str" : "1891019132134412701",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1891019132134412701",
      "created_at" : "Sun Feb 16 06:57:49 +0000 2025",
      "favorited" : false,
      "full_text" : "直接的な愛情表現が少なめの百合漫画がすき",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1890608635492933758"
          ],
          "editableUntil" : "2025-02-15T04:46:39.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "1",
      "id_str" : "1890608635492933758",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1890608635492933758",
      "created_at" : "Sat Feb 15 03:46:39 +0000 2025",
      "favorited" : false,
      "full_text" : "夏休みの時期に比べて地元のタイミー募集なさすぎんだろ！！！\nおれを面接なしで働かせろ！！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1890371959277392015"
          ],
          "editableUntil" : "2025-02-14T13:06:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "41"
      ],
      "favorite_count" : "2",
      "id_str" : "1890371959277392015",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1890371959277392015",
      "created_at" : "Fri Feb 14 12:06:11 +0000 2025",
      "favorited" : false,
      "full_text" : "今日は手作りチョコ2個(後日+1個)もらったから勝ちです。ありがとうございました。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1890182764282138872"
          ],
          "editableUntil" : "2025-02-14T00:34:23.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "13"
      ],
      "favorite_count" : "2",
      "id_str" : "1890182764282138872",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1890182764282138872",
      "created_at" : "Thu Feb 13 23:34:23 +0000 2025",
      "favorited" : false,
      "full_text" : "\"大明神の\"解析学を理解。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1889846185164521794"
          ],
          "editableUntil" : "2025-02-13T02:16:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "1",
      "id_str" : "1889846185164521794",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1889846185164521794",
      "created_at" : "Thu Feb 13 01:16:56 +0000 2025",
      "favorited" : false,
      "full_text" : "30秒おきに寝落ちするのさすがに病気なのでは？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1889629555280728147"
          ],
          "editableUntil" : "2025-02-12T11:56:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "2",
      "id_str" : "1889629555280728147",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1889629555280728147",
      "created_at" : "Wed Feb 12 10:56:08 +0000 2025",
      "favorited" : false,
      "full_text" : "20年前の辞書が使いこなせないよ〜😭\n文法覚えられないよ〜😭",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1888858939921756203"
          ],
          "editableUntil" : "2025-02-10T08:53:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "1",
      "id_str" : "1888858939921756203",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1888858939921756203",
      "created_at" : "Mon Feb 10 07:53:59 +0000 2025",
      "favorited" : false,
      "full_text" : "必修中国語落単ほぼ確定して転類失敗()まあ悪あがきするけどね",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1888567244365681026"
          ],
          "editableUntil" : "2025-02-09T13:34:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "4",
      "id_str" : "1888567244365681026",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1888567244365681026",
      "created_at" : "Sun Feb 09 12:34:53 +0000 2025",
      "favorited" : false,
      "full_text" : "こっからZONE飲んで基礎プロの勉強始めよう(基礎プロまだノー勉)",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1888479707370528792"
          ],
          "editableUntil" : "2025-02-09T07:47:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "4",
      "id_str" : "1888479707370528792",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1888479707370528792",
      "created_at" : "Sun Feb 09 06:47:03 +0000 2025",
      "favorited" : false,
      "full_text" : "テスト3科目ある日の前日にZONE無料配布するの流石に分かってるとしかいいようがない",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1888411752133705951"
          ],
          "editableUntil" : "2025-02-09T03:17:01.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "11"
      ],
      "favorite_count" : "1",
      "id_str" : "1888411752133705951",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1888411752133705951",
      "created_at" : "Sun Feb 09 02:17:01 +0000 2025",
      "favorited" : false,
      "full_text" : "技術の進化にに感動した",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1887814494010876283"
          ],
          "editableUntil" : "2025-02-07T11:43:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "1",
      "id_str" : "1887814494010876283",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1887814494010876283",
      "created_at" : "Fri Feb 07 10:43:43 +0000 2025",
      "favorited" : false,
      "full_text" : "てか謎の人物の正体がわかったの若干すっきり",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1887811545209651241"
          ],
          "editableUntil" : "2025-02-07T11:32:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "41"
      ],
      "favorite_count" : "2",
      "id_str" : "1887811545209651241",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1887811545209651241",
      "created_at" : "Fri Feb 07 10:32:00 +0000 2025",
      "favorited" : false,
      "full_text" : "人助け？をしたのでいい気分な気もする。ただ、もうちょい解決にスマートさがほしいよね",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1887445953852141892"
          ],
          "editableUntil" : "2025-02-06T11:19:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "18"
      ],
      "favorite_count" : "0",
      "id_str" : "1887445953852141892",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1887445953852141892",
      "created_at" : "Thu Feb 06 10:19:17 +0000 2025",
      "favorited" : false,
      "full_text" : "レジがまるで大人気アトラクション()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1887441166234493064"
          ],
          "editableUntil" : "2025-02-06T11:00:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "0",
      "id_str" : "1887441166234493064",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1887441166234493064",
      "created_at" : "Thu Feb 06 10:00:15 +0000 2025",
      "favorited" : false,
      "full_text" : "売りものの種類多いところを求めて新宿来たけど種類多すぎんだろ選べんて",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1887420185503584615"
          ],
          "editableUntil" : "2025-02-06T09:36:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "4",
      "id_str" : "1887420185503584615",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1887420185503584615",
      "created_at" : "Thu Feb 06 08:36:53 +0000 2025",
      "favorited" : false,
      "full_text" : "解析学をかなり理解したのはいいんだけど、優先順位おかしいんよ。こいつ最終日やんけ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1887097801475056054"
          ],
          "editableUntil" : "2025-02-05T12:15:51.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "1",
      "id_str" : "1887097801475056054",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1887097801475056054",
      "created_at" : "Wed Feb 05 11:15:51 +0000 2025",
      "favorited" : false,
      "full_text" : "文章いっぱいカキカキタイム終わったー！これをいつ提出するかだな",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1886409285191794936"
          ],
          "editableUntil" : "2025-02-03T14:39:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "1",
      "id_str" : "1886409285191794936",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1886409285191794936",
      "created_at" : "Mon Feb 03 13:39:56 +0000 2025",
      "favorited" : false,
      "full_text" : "テスト近いのにツイート数多すぎ。もうちょい自重しますね。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1886409017880387613"
          ],
          "editableUntil" : "2025-02-03T14:38:52.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "71"
      ],
      "favorite_count" : "3",
      "id_str" : "1886409017880387613",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1886409017880387613",
      "created_at" : "Mon Feb 03 13:38:52 +0000 2025",
      "favorited" : false,
      "full_text" : "今日調布から新宿に行くのに、\n調布で各駅→つつじヶ丘で快速→千歳烏山で各駅→笹塚で快速→新宿\nとかいうクソムーブかました()バカなのかな？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1886397375952064528"
          ],
          "editableUntil" : "2025-02-03T13:52:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "1",
      "id_str" : "1886397375952064528",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1886397375952064528",
      "created_at" : "Mon Feb 03 12:52:36 +0000 2025",
      "favorited" : false,
      "full_text" : "各駅を見送ることができなかった。やっぱだめだわ。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1886385680286126309"
          ],
          "editableUntil" : "2025-02-03T13:06:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "44"
      ],
      "favorite_count" : "1",
      "id_str" : "1886385680286126309",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1886385680286126309",
      "created_at" : "Mon Feb 03 12:06:08 +0000 2025",
      "favorited" : false,
      "full_text" : "ていうかさ！！！基礎プロガチらんくていいってゆったぢゃん！！\n私達の作品が恥ずかしいよ…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1886357013439123569"
          ],
          "editableUntil" : "2025-02-03T11:12:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "19"
      ],
      "favorite_count" : "5",
      "id_str" : "1886357013439123569",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1886357013439123569",
      "created_at" : "Mon Feb 03 10:12:13 +0000 2025",
      "favorited" : false,
      "full_text" : "眠すぎて物概の大問1個に2時間かかった",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1886317731404017988"
          ],
          "editableUntil" : "2025-02-03T08:36:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "74"
      ],
      "favorite_count" : "1",
      "id_str" : "1886317731404017988",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1886317731404017988",
      "created_at" : "Mon Feb 03 07:36:07 +0000 2025",
      "favorited" : false,
      "full_text" : "ミュートにしてる垢のツイートもリスト越しだと見れるのか！！そんでそのリストをTLに表示すれば、TLの整理整頓ができるじゃないか！！(今更すぎるって)",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1886081625571958988"
          ],
          "editableUntil" : "2025-02-02T16:57:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "16"
      ],
      "favorite_count" : "1",
      "id_str" : "1886081625571958988",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1886081625571958988",
      "created_at" : "Sun Feb 02 15:57:55 +0000 2025",
      "favorited" : false,
      "full_text" : "一応エリア分けも出さんとだもんね",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1885914886989090970"
          ],
          "editableUntil" : "2025-02-02T05:55:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "1",
      "id_str" : "1885914886989090970",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1885914886989090970",
      "created_at" : "Sun Feb 02 04:55:22 +0000 2025",
      "favorited" : false,
      "full_text" : "力学は私が解けたらみんな解けるんよってレベルでできない()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1885891787828715653"
          ],
          "editableUntil" : "2025-02-02T04:23:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "8"
      ],
      "favorite_count" : "0",
      "id_str" : "1885891787828715653",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1885891787828715653",
      "created_at" : "Sun Feb 02 03:23:35 +0000 2025",
      "favorited" : false,
      "full_text" : "書類書かねえとな",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1885495906029756590"
          ],
          "editableUntil" : "2025-02-01T02:10:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "32"
      ],
      "favorite_count" : "0",
      "id_str" : "1885495906029756590",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1885495906029756590",
      "created_at" : "Sat Feb 01 01:10:29 +0000 2025",
      "favorited" : false,
      "full_text" : "タラーもすなる着調といふものを、非タラーもしてみむとてするなり。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1885341848123957490"
          ],
          "editableUntil" : "2025-01-31T15:58:19.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "47"
      ],
      "favorite_count" : "0",
      "id_str" : "1885341848123957490",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1885341848123957490",
      "created_at" : "Fri Jan 31 14:58:19 +0000 2025",
      "favorited" : false,
      "full_text" : "高校のとき入ってた部活のインスタ(私が垢作成した)が2年ぶりに動いてて激アツファンタスティック",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1884907475109130298"
          ],
          "editableUntil" : "2025-01-30T11:12:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "2",
      "id_str" : "1884907475109130298",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1884907475109130298",
      "created_at" : "Thu Jan 30 10:12:16 +0000 2025",
      "favorited" : false,
      "full_text" : "新パック引き良くなくてつらいよ…\n周りに引き良すぎる奴がいるせいで余計に。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1884535547949162568"
          ],
          "editableUntil" : "2025-01-29T10:34:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "2",
      "id_str" : "1884535547949162568",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1884535547949162568",
      "created_at" : "Wed Jan 29 09:34:22 +0000 2025",
      "favorited" : false,
      "full_text" : "やべえレポート用紙が足りなくなりそう。若干頑張りすぎでは？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1884254396474876228"
          ],
          "editableUntil" : "2025-01-28T15:57:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "0",
      "id_str" : "1884254396474876228",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1884254396474876228",
      "created_at" : "Tue Jan 28 14:57:10 +0000 2025",
      "favorited" : false,
      "full_text" : "調べれば調べるほど面白くて楽しそうだし、調べれば調べるほどお堅くておもんなそう",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1884069358286360956"
          ],
          "editableUntil" : "2025-01-28T03:41:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "2",
      "id_str" : "1884069358286360956",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1884069358286360956",
      "created_at" : "Tue Jan 28 02:41:53 +0000 2025",
      "favorited" : false,
      "full_text" : "録画の画面設定だいぶミスってたんだなって。ごめんねみんな。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1883799792792555975"
          ],
          "editableUntil" : "2025-01-27T09:50:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "4",
      "id_str" : "1883799792792555975",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1883799792792555975",
      "created_at" : "Mon Jan 27 08:50:44 +0000 2025",
      "favorited" : false,
      "full_text" : "Windowsで印刷すると速いって聞いてたんだけど、立ち上がるまでが遅い（）",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1883795842169188359"
          ],
          "editableUntil" : "2025-01-27T09:35:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "7",
      "id_str" : "1883795842169188359",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1883795842169188359",
      "created_at" : "Mon Jan 27 08:35:02 +0000 2025",
      "favorited" : false,
      "full_text" : "総合実習ってガチらんくてええよな？\nな？な？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1883100124563574786"
          ],
          "editableUntil" : "2025-01-25T11:30:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1883098753877647492",
      "id_str" : "1883100124563574786",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1883100124563574786",
      "in_reply_to_status_id" : "1883098753877647492",
      "created_at" : "Sat Jan 25 10:30:30 +0000 2025",
      "favorited" : false,
      "full_text" : "未来の七億円に「なんでここにこれ入れてんだ🤔」とか、「この通りにプログラム配属されてねぇ😭」とか思われそうで…",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1883098753877647492"
          ],
          "editableUntil" : "2025-01-25T11:25:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "0",
      "id_str" : "1883098753877647492",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1883098753877647492",
      "created_at" : "Sat Jan 25 10:25:03 +0000 2025",
      "favorited" : false,
      "full_text" : "履修計画立ててる(今やることか？)けど、不安しか生まれない()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1883015786312417480"
          ],
          "editableUntil" : "2025-01-25T05:55:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "91"
      ],
      "favorite_count" : "1",
      "id_str" : "1883015786312417480",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1883015786312417480",
      "created_at" : "Sat Jan 25 04:55:22 +0000 2025",
      "favorited" : false,
      "full_text" : "自分のパソコンで基礎プロ総合課題作業をできるようにしたけど、Ubuntuとか、mingwとか、ImageMagickとか、なんだかよくわからないものばかりインストールしちゃってこわい",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1882808126128394692"
          ],
          "editableUntil" : "2025-01-24T16:10:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "16"
      ],
      "favorite_count" : "0",
      "id_str" : "1882808126128394692",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1882808126128394692",
      "created_at" : "Fri Jan 24 15:10:12 +0000 2025",
      "favorited" : false,
      "full_text" : "タクシー代ってこんな高いんだ（）",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1882806012962652238"
          ],
          "editableUntil" : "2025-01-24T16:01:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "0",
      "id_str" : "1882806012962652238",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1882806012962652238",
      "created_at" : "Fri Jan 24 15:01:48 +0000 2025",
      "favorited" : false,
      "full_text" : "電車一駅乗り過ごした()\nおそらく人生初タクシー",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1882120065283510528"
          ],
          "editableUntil" : "2025-01-22T18:36:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "0",
      "id_str" : "1882120065283510528",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1882120065283510528",
      "created_at" : "Wed Jan 22 17:36:06 +0000 2025",
      "favorited" : false,
      "full_text" : "文学部とかにしとけばよかった。私でも輝けそう。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1882119373495922759"
          ],
          "editableUntil" : "2025-01-22T18:33:21.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "44"
      ],
      "favorite_count" : "0",
      "id_str" : "1882119373495922759",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1882119373495922759",
      "created_at" : "Wed Jan 22 17:33:21 +0000 2025",
      "favorited" : false,
      "full_text" : "やっぱ理系の人たちは理解も計算スピードも速すぎる。本当にすごすぎる。\n来る大学間違えた。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1881506126652744083"
          ],
          "editableUntil" : "2025-01-21T01:56:31.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "フルクルーレン",
            "screen_name" : "b0un0hurukurA",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1771298960864661504",
            "id" : "1771298960864661504"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1881505525575332171",
      "id_str" : "1881506126652744083",
      "in_reply_to_user_id" : "1771298960864661504",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1881506126652744083",
      "in_reply_to_status_id" : "1881505525575332171",
      "created_at" : "Tue Jan 21 00:56:31 +0000 2025",
      "favorited" : false,
      "full_text" : "@b0un0hurukurA 恐らくできるんですね！教えてくれてありがとうございます！",
      "lang" : "ja",
      "in_reply_to_screen_name" : "b0un0hurukurA",
      "in_reply_to_user_id_str" : "1771298960864661504"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1881505115968098547"
          ],
          "editableUntil" : "2025-01-21T01:52:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "1",
      "id_str" : "1881505115968098547",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1881505115968098547",
      "created_at" : "Tue Jan 21 00:52:30 +0000 2025",
      "favorited" : false,
      "full_text" : "いや、まて？2限だけに欠席届を適用することはできるのか？？？大学のシステムをまだまだ理解していない",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1881502104382259649"
          ],
          "editableUntil" : "2025-01-21T01:40:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "13"
      ],
      "favorite_count" : "0",
      "id_str" : "1881502104382259649",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1881502104382259649",
      "created_at" : "Tue Jan 21 00:40:32 +0000 2025",
      "favorited" : false,
      "full_text" : "てか、領収書でいいんだよな",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1881502038829490200"
          ],
          "editableUntil" : "2025-01-21T01:40:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "1",
      "id_str" : "1881502038829490200",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1881502038829490200",
      "created_at" : "Tue Jan 21 00:40:17 +0000 2025",
      "favorited" : false,
      "full_text" : "病院の領収書を持っているので、2限半切りのところを全切りにしようかしら",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1880978244213875160"
          ],
          "editableUntil" : "2025-01-19T14:58:54.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "18"
      ],
      "favorite_count" : "1",
      "id_str" : "1880978244213875160",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1880978244213875160",
      "created_at" : "Sun Jan 19 13:58:54 +0000 2025",
      "favorited" : false,
      "full_text" : "クソデカタスクおわりー！！うれしー！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1880546024554746216"
          ],
          "editableUntil" : "2025-01-18T10:21:25.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "1",
      "id_str" : "1880546024554746216",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1880546024554746216",
      "created_at" : "Sat Jan 18 09:21:25 +0000 2025",
      "favorited" : false,
      "full_text" : "ああ！早く既読4になれ！！私は予定を早く立てたいんだ！！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1880534758062780806"
          ],
          "editableUntil" : "2025-01-18T09:36:39.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "69"
      ],
      "favorite_count" : "0",
      "id_str" : "1880534758062780806",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1880534758062780806",
      "created_at" : "Sat Jan 18 08:36:39 +0000 2025",
      "favorited" : false,
      "full_text" : "別に求められてないときならスべらなさそうな話はバンバンできるのに、いざ振られるとなんにも言えなくなるのとても悔しい。\nもっと強くなりたい。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1938248452783411599"
          ],
          "editableUntil" : "2025-06-26T15:50:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "36"
      ],
      "favorite_count" : "7",
      "id_str" : "1938248452783411599",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1938248452783411599",
      "created_at" : "Thu Jun 26 14:50:16 +0000 2025",
      "favorited" : false,
      "full_text" : "もう一生外で酒飲まん〜！！！！\nエチケット袋常備しててよかった〜！！！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1938046945748259085"
          ],
          "editableUntil" : "2025-06-26T02:29:33.694Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "電気通信大学",
            "screen_name" : "uectokyo",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "368206211",
            "id" : "368206211"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/SfsCdTa9zq",
            "expanded_url" : "https://www.uec.ac.jp/news/prize/2025/20250626_7053.html",
            "display_url" : "uec.ac.jp/news/prize/202…",
            "indices" : [
              "77",
              "100"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "100"
      ],
      "favorite_count" : "0",
      "id_str" : "1938046945748259085",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1938046945748259085",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jun 26 01:29:33 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @uectokyo: UECスポーツチャンバラ同好会の佐々木時雨さん（Ⅲ類（理工系）２年）が第30回春季関東学生大会 上級生小太刀Bクラスにて優勝\nhttps://t.co/SfsCdTa9zq",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1938031472457486650"
          ],
          "editableUntil" : "2025-06-26T01:28:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "68"
      ],
      "favorite_count" : "5",
      "id_str" : "1938031472457486650",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1938031472457486650",
      "created_at" : "Thu Jun 26 00:28:04 +0000 2025",
      "favorited" : false,
      "full_text" : "謁見であんなに使ったExcelの使い方の全てを忘却していてショック。結局AIに聞くしかなくなってる。\n\n俺の人生って一体何なんだろうな。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1937716915306397765"
          ],
          "editableUntil" : "2025-06-25T04:38:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "3",
      "id_str" : "1937716915306397765",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1937716915306397765",
      "created_at" : "Wed Jun 25 03:38:08 +0000 2025",
      "favorited" : false,
      "full_text" : "最近昼飯の量多すぎて()\n気になった商品にすぐ手を出しちゃうから…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1937660016141697145"
          ],
          "editableUntil" : "2025-06-25T00:52:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "2",
      "id_str" : "1937660016141697145",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1937660016141697145",
      "created_at" : "Tue Jun 24 23:52:02 +0000 2025",
      "favorited" : false,
      "full_text" : "国領トラップ久々に引っかかって立ち上がっちゃった",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1936317514990207337"
          ],
          "editableUntil" : "2025-06-21T07:57:25.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "2",
      "id_str" : "1936317514990207337",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1936317514990207337",
      "created_at" : "Sat Jun 21 06:57:25 +0000 2025",
      "favorited" : false,
      "full_text" : "ただね、他の火曜までのAES課題が全く終わってないんよね。やばい。普通に。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1936317334156972287"
          ],
          "editableUntil" : "2025-06-21T07:56:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/V2VlOs3gXU",
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1936023669781963167",
            "display_url" : "x.com/joyjoy_7shichi…",
            "indices" : [
              "50",
              "73"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "73"
      ],
      "favorite_count" : "6",
      "id_str" : "1936317334156972287",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1936317334156972287",
      "possibly_sensitive" : false,
      "created_at" : "Sat Jun 21 06:56:42 +0000 2025",
      "favorited" : false,
      "full_text" : "多くの方々の御協力と拡散のおかげで目標の50人集まりました！！！\n本当にありがとうございました！！ https://t.co/V2VlOs3gXU",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1936289197616480405"
          ],
          "editableUntil" : "2025-06-21T06:04:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "78"
      ],
      "favorite_count" : "0",
      "id_str" : "1936289197616480405",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1936289197616480405",
      "created_at" : "Sat Jun 21 05:04:53 +0000 2025",
      "favorited" : false,
      "full_text" : "絶対AESのアンケートで2回以上答えちゃってるフォームあるんだが()\nやったことあるような...?みたいな感情をすべてのフォームにうっすら感じつつ答えてる。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1936287527939588181"
          ],
          "editableUntil" : "2025-06-21T05:58:15.800Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "月🌙",
            "screen_name" : "Tuki_uec24",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "1765204534144663552",
            "id" : "1765204534144663552"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/GxIEolWvYw",
            "expanded_url" : "https://forms.gle/SG3CsJ5UfyHMbmBo7",
            "display_url" : "forms.gle/SG3CsJ5UfyHMbm…",
            "indices" : [
              "115",
              "138"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "138"
      ],
      "favorite_count" : "0",
      "id_str" : "1936287527939588181",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1936287527939588181",
      "possibly_sensitive" : false,
      "created_at" : "Sat Jun 21 04:58:15 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @Tuki_uec24: AESのアンケート回答があと30人分くらい必要なので協力してくださるととてもうれしいです、\n質問が少し多いので面倒ではあるんですけど難しくは全くないので数分ほど時間のある方は学年問わずお願いします\nhttps://t.co/GxIEolWvYw",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1936230065098178794"
          ],
          "editableUntil" : "2025-06-21T02:09:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "0",
      "id_str" : "1936230065098178794",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1936230065098178794",
      "created_at" : "Sat Jun 21 01:09:55 +0000 2025",
      "favorited" : false,
      "full_text" : "今でさえ毎日疲れて奇声上げてるのに、バイトなんてできねえ…\n貯金額がドンドコ減ってく…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1936228746727723217"
          ],
          "editableUntil" : "2025-06-21T02:04:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "3",
      "id_str" : "1936228746727723217",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1936228746727723217",
      "created_at" : "Sat Jun 21 01:04:41 +0000 2025",
      "favorited" : false,
      "full_text" : "私の名前は七億円です。\n私の月収は千円です。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1936074817108877618"
          ],
          "editableUntil" : "2025-06-20T15:53:01.586Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "よもぎ",
            "screen_name" : "ymgknsn_univ",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "1776215519781347328",
            "id" : "1776215519781347328"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/4dfybVDFIs",
            "expanded_url" : "https://docs.google.com/forms/d/1jHSzG9S28PiTsLU8l_NwPJRa6jeFH5E1WABCb4Udtlo/edit",
            "display_url" : "docs.google.com/forms/d/1jHSzG…",
            "indices" : [
              "82",
              "105"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "105"
      ],
      "favorite_count" : "0",
      "id_str" : "1936074817108877618",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1936074817108877618",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jun 20 14:53:01 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @ymgknsn_univ: 誰か頼んだ\n枕の課題の出し方に透明性なかったせいで内容かなり無理あるけど50人集めないといけないから人助けだと思って…………\n\nhttps://t.co/4dfybVDFIs",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1936067425503780902"
          ],
          "editableUntil" : "2025-06-20T15:23:39.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "2",
      "id_str" : "1936067425503780902",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1936067425503780902",
      "created_at" : "Fri Jun 20 14:23:39 +0000 2025",
      "favorited" : false,
      "full_text" : "元大学教授の趣味全開ゲキなが文章(レポート？)が送られてきておもろい。そして内容は普通に役に立つし面白い。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1936023953467928743"
          ],
          "editableUntil" : "2025-06-20T12:30:54.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "1",
      "id_str" : "1936023953467928743",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1936023953467928743",
      "created_at" : "Fri Jun 20 11:30:54 +0000 2025",
      "favorited" : false,
      "full_text" : "ちょっともう最下位層タラーだからって手段を選ぶことができなくなってきましたぞ…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1936023669781963167"
          ],
          "editableUntil" : "2025-06-20T12:29:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/DewtiiU5Ob",
            "expanded_url" : "https://forms.gle/r1XdFFGCRi3bmkMd6",
            "display_url" : "forms.gle/r1XdFFGCRi3bmk…",
            "indices" : [
              "134",
              "157"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "157"
      ],
      "favorite_count" : "7",
      "id_str" : "1936023669781963167",
      "truncated" : false,
      "retweet_count" : "5",
      "id" : "1936023669781963167",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jun 20 11:29:47 +0000 2025",
      "favorited" : false,
      "full_text" : "英語の授業(AES)(枕)の課題で、「電通大生の第二外国語の学習について」のアンケートをすることになりました。\n数分程度、メルアドの収集もしておりませんので、ぜひ御協力をお願いいたします。(まだかなりの回答数が足りません!!)\n\n↓こちらがgoogleフォームです。\nhttps://t.co/DewtiiU5Ob",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1935877071320105465"
          ],
          "editableUntil" : "2025-06-20T02:47:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ススキ",
            "screen_name" : "susuki_uec24",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1774432006467878912",
            "id" : "1774432006467878912"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1935864816708862374",
      "id_str" : "1935877071320105465",
      "in_reply_to_user_id" : "1774432006467878912",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1935877071320105465",
      "in_reply_to_status_id" : "1935864816708862374",
      "created_at" : "Fri Jun 20 01:47:15 +0000 2025",
      "favorited" : false,
      "full_text" : "@susuki_uec24 ありがとー！",
      "lang" : "ja",
      "in_reply_to_screen_name" : "susuki_uec24",
      "in_reply_to_user_id_str" : "1774432006467878912"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1935877019889520928"
          ],
          "editableUntil" : "2025-06-20T02:47:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "コタロー。",
            "screen_name" : "sinnkasinai_810",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1431578087938924548",
            "id" : "1431578087938924548"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1935862933302788246",
      "id_str" : "1935877019889520928",
      "in_reply_to_user_id" : "1431578087938924548",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1935877019889520928",
      "in_reply_to_status_id" : "1935862933302788246",
      "created_at" : "Fri Jun 20 01:47:03 +0000 2025",
      "favorited" : false,
      "full_text" : "@sinnkasinai_810 ありがとᕙ⁠(⁠ ͡⁠● ͜⁠ ⁠ʖ⁠ ͡⁠●)⁠ᕗ",
      "lang" : "ja",
      "in_reply_to_screen_name" : "sinnkasinai_810",
      "in_reply_to_user_id_str" : "1431578087938924548"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1935849849590780400"
          ],
          "editableUntil" : "2025-06-20T00:59:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "rei",
            "screen_name" : "T2413127Rei",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "1774663326456569857",
            "id" : "1774663326456569857"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "19"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1935838762145284561",
      "id_str" : "1935849849590780400",
      "in_reply_to_user_id" : "1774663326456569857",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1935849849590780400",
      "in_reply_to_status_id" : "1935838762145284561",
      "created_at" : "Thu Jun 19 23:59:05 +0000 2025",
      "favorited" : false,
      "full_text" : "@T2413127Rei ありがとう🥂",
      "lang" : "ja",
      "in_reply_to_screen_name" : "T2413127Rei",
      "in_reply_to_user_id_str" : "1774663326456569857"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1935849613438992841"
          ],
          "editableUntil" : "2025-06-20T00:58:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "猫好き",
            "screen_name" : "NewKeep_y",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1765218063530815488",
            "id" : "1765218063530815488"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "16"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1935837810915000383",
      "id_str" : "1935849613438992841",
      "in_reply_to_user_id" : "1765218063530815488",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1935849613438992841",
      "in_reply_to_status_id" : "1935837810915000383",
      "created_at" : "Thu Jun 19 23:58:08 +0000 2025",
      "favorited" : false,
      "full_text" : "@NewKeep_y ありがとー",
      "lang" : "ja",
      "in_reply_to_screen_name" : "NewKeep_y",
      "in_reply_to_user_id_str" : "1765218063530815488"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1880071261369561090"
          ],
          "editableUntil" : "2025-01-17T02:54:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "77"
      ],
      "favorite_count" : "0",
      "id_str" : "1880071261369561090",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1880071261369561090",
      "created_at" : "Fri Jan 17 01:54:53 +0000 2025",
      "favorited" : false,
      "full_text" : "マックのサイドサラダは最後のドレッシングくたくたの野菜が美味しいのに、角に引っかかってたべづらい…\nてかプラスチックに戻んねえかな。シャカシャカしたいよ。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1879676391819764167"
          ],
          "editableUntil" : "2025-01-16T00:45:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "69"
      ],
      "favorite_count" : "0",
      "id_str" : "1879676391819764167",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1879676391819764167",
      "created_at" : "Wed Jan 15 23:45:49 +0000 2025",
      "favorited" : false,
      "full_text" : "いかに自然に電車の席を譲るかを意識してるんだけど、結局バレててお礼を言われてしまう…なんかもっとcoolでsmartな譲り方考えなきゃな…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1879553808357056984"
          ],
          "editableUntil" : "2025-01-15T16:38:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "1",
      "id_str" : "1879553808357056984",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1879553808357056984",
      "created_at" : "Wed Jan 15 15:38:42 +0000 2025",
      "favorited" : false,
      "full_text" : "弟がブチギレてて怖い…😱\nガムテープ投げまくってて床抜けそう…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1877872721037775034"
          ],
          "editableUntil" : "2025-01-11T01:18:40.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "17"
      ],
      "favorite_count" : "0",
      "id_str" : "1877872721037775034",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1877872721037775034",
      "created_at" : "Sat Jan 11 00:18:40 +0000 2025",
      "favorited" : false,
      "full_text" : "結局モコモコ脱がされてた。寒すぎ。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1876801220083437940"
          ],
          "editableUntil" : "2025-01-08T02:20:54.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "id_str" : "1876801220083437940",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1876801220083437940",
      "created_at" : "Wed Jan 08 01:20:54 +0000 2025",
      "favorited" : false,
      "full_text" : "昨日久しぶりに右脚に全体重をかけたら膝がいたくなっちゃったよ〜(´；ω；｀)",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1876618793176404304"
          ],
          "editableUntil" : "2025-01-07T14:16:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "1",
      "id_str" : "1876618793176404304",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1876618793176404304",
      "created_at" : "Tue Jan 07 13:16:00 +0000 2025",
      "favorited" : false,
      "full_text" : "やべやべ献血した日の電車内でスマホ見ると気持ち悪くなるの忘れてた()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1876082505092374981"
          ],
          "editableUntil" : "2025-01-06T02:44:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1876082382627016782",
      "id_str" : "1876082505092374981",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1876082505092374981",
      "in_reply_to_status_id" : "1876082382627016782",
      "created_at" : "Mon Jan 06 01:44:59 +0000 2025",
      "favorited" : false,
      "full_text" : "電車内の人達みんなで講義受けるのもありだったか？笑",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1876082382627016782"
          ],
          "editableUntil" : "2025-01-06T02:44:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "47"
      ],
      "favorite_count" : "0",
      "id_str" : "1876082382627016782",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1876082382627016782",
      "created_at" : "Mon Jan 06 01:44:30 +0000 2025",
      "favorited" : false,
      "full_text" : "電車の中でzoom聞こうと思ってたら、設定ミスで思いっきりスマホ本体から音出てたので退出した！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1875402830850543784"
          ],
          "editableUntil" : "2025-01-04T05:44:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "57"
      ],
      "favorite_count" : "0",
      "id_str" : "1875402830850543784",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1875402830850543784",
      "created_at" : "Sat Jan 04 04:44:12 +0000 2025",
      "favorited" : false,
      "full_text" : "超絶ちなみに、うちの家には観葉植物を置くと必ず枯れる場所が存在する…！\n\nちなみに今も枯れそうなやつが置いてある。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1875398480224776500"
          ],
          "editableUntil" : "2025-01-04T05:26:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "こし(꜆꜄ ˙꒳˙)꜆꜄꜆",
            "screen_name" : "Nafu_kosi1102",
            "indices" : [
              "0",
              "14"
            ],
            "id_str" : "1427962968981921797",
            "id" : "1427962968981921797"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "47"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1875395668841476126",
      "id_str" : "1875398480224776500",
      "in_reply_to_user_id" : "1427962968981921797",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1875398480224776500",
      "in_reply_to_status_id" : "1875395668841476126",
      "created_at" : "Sat Jan 04 04:26:55 +0000 2025",
      "favorited" : false,
      "full_text" : "@Nafu_kosi1102 ありがとうございます！そうです初単焦点です！なんか楽しいっすね！",
      "lang" : "ja",
      "in_reply_to_screen_name" : "Nafu_kosi1102",
      "in_reply_to_user_id_str" : "1427962968981921797"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1875389938348507138"
          ],
          "editableUntil" : "2025-01-04T04:52:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1875389938348507138/photo/1",
            "indices" : [
              "21",
              "44"
            ],
            "url" : "https://t.co/GF0dLyRoIv",
            "media_url" : "http://pbs.twimg.com/media/Gga5Ncia8AEjx6c.jpg",
            "id_str" : "1875389935496392705",
            "id" : "1875389935496392705",
            "media_url_https" : "https://pbs.twimg.com/media/Gga5Ncia8AEjx6c.jpg",
            "sizes" : {
              "large" : {
                "w" : "1620",
                "h" : "1080",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "800",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "453",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/GF0dLyRoIv"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "44"
      ],
      "favorite_count" : "9",
      "id_str" : "1875389938348507138",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1875389938348507138",
      "possibly_sensitive" : false,
      "created_at" : "Sat Jan 04 03:52:59 +0000 2025",
      "favorited" : false,
      "full_text" : "うおー！my new gear…だぜ！！ https://t.co/GF0dLyRoIv",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1875389938348507138/photo/1",
            "indices" : [
              "21",
              "44"
            ],
            "url" : "https://t.co/GF0dLyRoIv",
            "media_url" : "http://pbs.twimg.com/media/Gga5Ncia8AEjx6c.jpg",
            "id_str" : "1875389935496392705",
            "id" : "1875389935496392705",
            "media_url_https" : "https://pbs.twimg.com/media/Gga5Ncia8AEjx6c.jpg",
            "sizes" : {
              "large" : {
                "w" : "1620",
                "h" : "1080",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "800",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "453",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/GF0dLyRoIv"
          },
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1875389938348507138/photo/1",
            "indices" : [
              "21",
              "44"
            ],
            "url" : "https://t.co/GF0dLyRoIv",
            "media_url" : "http://pbs.twimg.com/media/Gga5Nf-a8AEphyR.jpg",
            "id_str" : "1875389936419139585",
            "id" : "1875389936419139585",
            "media_url_https" : "https://pbs.twimg.com/media/Gga5Nf-a8AEphyR.jpg",
            "sizes" : {
              "large" : {
                "w" : "1024",
                "h" : "682",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "453",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1024",
                "h" : "682",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/GF0dLyRoIv"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1875281130913726576"
          ],
          "editableUntil" : "2025-01-03T21:40:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "id_str" : "1875281130913726576",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1875281130913726576",
      "created_at" : "Fri Jan 03 20:40:37 +0000 2025",
      "favorited" : false,
      "full_text" : "な、なにー！？お昼の12時からアニメを見てたら5時40分になっていたぞー！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1874788103241765329"
          ],
          "editableUntil" : "2025-01-02T13:01:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1874788103241765329/photo/1",
            "indices" : [
              "42",
              "65"
            ],
            "url" : "https://t.co/90J62RuLQ8",
            "media_url" : "http://pbs.twimg.com/media/GgSV2E6aUAA4qIS.jpg",
            "id_str" : "1874788101157179392",
            "id" : "1874788101157179392",
            "media_url_https" : "https://pbs.twimg.com/media/GgSV2E6aUAA4qIS.jpg",
            "sizes" : {
              "large" : {
                "w" : "922",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "306",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "540",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/90J62RuLQ8"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "2",
      "id_str" : "1874788103241765329",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1874788103241765329",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jan 02 12:01:30 +0000 2025",
      "favorited" : false,
      "full_text" : "なんこれ\nてか、これほかの人のプロフィールでもやっちゃったけどバレてないよね？？？ https://t.co/90J62RuLQ8",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1874788103241765329/photo/1",
            "indices" : [
              "42",
              "65"
            ],
            "url" : "https://t.co/90J62RuLQ8",
            "media_url" : "http://pbs.twimg.com/media/GgSV2E6aUAA4qIS.jpg",
            "id_str" : "1874788101157179392",
            "id" : "1874788101157179392",
            "media_url_https" : "https://pbs.twimg.com/media/GgSV2E6aUAA4qIS.jpg",
            "sizes" : {
              "large" : {
                "w" : "922",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "306",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "540",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/90J62RuLQ8"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1874783566451835199"
          ],
          "editableUntil" : "2025-01-02T12:43:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "2",
      "id_str" : "1874783566451835199",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1874783566451835199",
      "created_at" : "Thu Jan 02 11:43:28 +0000 2025",
      "favorited" : false,
      "full_text" : "やっとびっけん終わらせたぞー！本当はとっくに終わらせるつもりだったのになぁ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1874427667874996547"
          ],
          "editableUntil" : "2025-01-01T13:09:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "63"
      ],
      "favorite_count" : "1",
      "id_str" : "1874427667874996547",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1874427667874996547",
      "created_at" : "Wed Jan 01 12:09:15 +0000 2025",
      "favorited" : false,
      "full_text" : "22mmの単焦点(安くないけど安い)を買うか、18-150mmの便利そうなやつ(高いけど高い)を買うか夏から迷って年越した()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1874263247999934962"
          ],
          "editableUntil" : "2025-01-01T02:15:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "50"
      ],
      "favorite_count" : "0",
      "id_str" : "1874263247999934962",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1874263247999934962",
      "created_at" : "Wed Jan 01 01:15:55 +0000 2025",
      "favorited" : false,
      "full_text" : "なんでみんな中学時代の友達と年越ししてんの？？？仲良すぎだろ？？？なんで私にはそういうの無いの？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1873897020781682700"
          ],
          "editableUntil" : "2024-12-31T02:00:39.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "1",
      "id_str" : "1873897020781682700",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1873897020781682700",
      "created_at" : "Tue Dec 31 01:00:39 +0000 2024",
      "favorited" : false,
      "full_text" : "やべ物概小テスト10点満点にするのわすれてた。5点のやつとかあるな",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1873827100752568721"
          ],
          "editableUntil" : "2024-12-30T21:22:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "0",
      "id_str" : "1873827100752568721",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1873827100752568721",
      "created_at" : "Mon Dec 30 20:22:49 +0000 2024",
      "favorited" : false,
      "full_text" : "せっかく4時に起きて準備し終わったのに、一瞬寝転んだ時に寝てしまったので寝転んじゃだめだという教訓を得ました。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1873826486903595380"
          ],
          "editableUntil" : "2024-12-30T21:20:23.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "1",
      "id_str" : "1873826486903595380",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1873826486903595380",
      "created_at" : "Mon Dec 30 20:20:23 +0000 2024",
      "favorited" : false,
      "full_text" : "寝坊かましてバイト12分遅れでいったのに担当者も遅れてて助かった(？)",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1873721874573910439"
          ],
          "editableUntil" : "2024-12-30T14:24:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "1",
      "id_str" : "1873721874573910439",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1873721874573910439",
      "created_at" : "Mon Dec 30 13:24:41 +0000 2024",
      "favorited" : false,
      "full_text" : "まじか電車の緊急停止で電気まで止めるのは初めての経験（送電に支障があるらしい）",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1873553735500337169"
          ],
          "editableUntil" : "2024-12-30T03:16:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "id_str" : "1873553735500337169",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1873553735500337169",
      "created_at" : "Mon Dec 30 02:16:34 +0000 2024",
      "favorited" : false,
      "full_text" : "電車で隣に座った女が中学の頃の仲良かった同級生だったけど、さすがにもう話せん（）",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1873376922291618078"
          ],
          "editableUntil" : "2024-12-29T15:33:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "50"
      ],
      "favorite_count" : "1",
      "id_str" : "1873376922291618078",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1873376922291618078",
      "created_at" : "Sun Dec 29 14:33:58 +0000 2024",
      "favorited" : false,
      "full_text" : "イナズマイレブン1期の一気見したけど、あの世界にはとりあえずレッドカードを導入したほうがいいと思う。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1873156885026881802"
          ],
          "editableUntil" : "2024-12-29T00:59:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "11"
      ],
      "favorite_count" : "0",
      "id_str" : "1873156885026881802",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1873156885026881802",
      "created_at" : "Sat Dec 28 23:59:37 +0000 2024",
      "favorited" : false,
      "full_text" : "見事に右半身だけ筋肉痛",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1873031429011193942"
          ],
          "editableUntil" : "2024-12-28T16:41:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "41"
      ],
      "favorite_count" : "2",
      "id_str" : "1873031429011193942",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1873031429011193942",
      "created_at" : "Sat Dec 28 15:41:06 +0000 2024",
      "favorited" : false,
      "full_text" : "今日も課題を何一つできなかった。しかも、日曜日なのにびっけん終わってないし。大鬱。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1872963003102146994"
          ],
          "editableUntil" : "2024-12-28T12:09:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "1",
      "id_str" : "1872963003102146994",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1872963003102146994",
      "created_at" : "Sat Dec 28 11:09:12 +0000 2024",
      "favorited" : false,
      "full_text" : "冬に着たらぜってー寒い服買った！思ったよりいい感じ。この世界には着ず嫌いしてるタイプの服が他にもありそう…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1872474158430613918"
          ],
          "editableUntil" : "2024-12-27T03:46:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/GWNGqEXLFy",
            "expanded_url" : "https://yt.be/MusicRecap",
            "display_url" : "yt.be/MusicRecap",
            "indices" : [
              "41",
              "64"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1872474158430613918/photo/1",
            "indices" : [
              "88",
              "111"
            ],
            "url" : "https://t.co/izJUUtSL27",
            "media_url" : "http://pbs.twimg.com/media/GfxdUrIaEAAilUK.jpg",
            "id_str" : "1872474154836037632",
            "id" : "1872474154836037632",
            "media_url_https" : "https://pbs.twimg.com/media/GfxdUrIaEAAilUK.jpg",
            "sizes" : {
              "large" : {
                "w" : "1080",
                "h" : "1920",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "383",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "675",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/izJUUtSL27"
          }
        ],
        "hashtags" : [
          {
            "text" : "YouTubeMusicRecap",
            "indices" : [
              "9",
              "27"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "111"
      ],
      "favorite_count" : "1",
      "id_str" : "1872474158430613918",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1872474158430613918",
      "possibly_sensitive" : false,
      "created_at" : "Fri Dec 27 02:46:42 +0000 2024",
      "favorited" : false,
      "full_text" : "私の2024年の #YouTubeMusicRecap をシェアします！あなたのもhttps://t.co/GWNGqEXLFyでチェックしよう\n3位以降なんかおかしくない？ https://t.co/izJUUtSL27",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1872474158430613918/photo/1",
            "indices" : [
              "88",
              "111"
            ],
            "url" : "https://t.co/izJUUtSL27",
            "media_url" : "http://pbs.twimg.com/media/GfxdUrIaEAAilUK.jpg",
            "id_str" : "1872474154836037632",
            "id" : "1872474154836037632",
            "media_url_https" : "https://pbs.twimg.com/media/GfxdUrIaEAAilUK.jpg",
            "sizes" : {
              "large" : {
                "w" : "1080",
                "h" : "1920",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "383",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "675",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/izJUUtSL27"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1872067666535653434"
          ],
          "editableUntil" : "2024-12-26T00:51:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/85OXGbsNaO",
            "expanded_url" : "https://youtu.be/KKY8koF56ws?si=YJtooUThQ_hWKPMb",
            "display_url" : "youtu.be/KKY8koF56ws?si…",
            "indices" : [
              "53",
              "76"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "76"
      ],
      "favorite_count" : "0",
      "id_str" : "1872067666535653434",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1872067666535653434",
      "possibly_sensitive" : false,
      "created_at" : "Wed Dec 25 23:51:27 +0000 2024",
      "favorited" : false,
      "full_text" : "地獄でなぜ悪いの弾き語り聴きたかったな…\nしょうがないのでYoutubeにのっかってるverを鬼リピする\nhttps://t.co/85OXGbsNaO",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1871916889225785438"
          ],
          "editableUntil" : "2024-12-25T14:52:19.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "1",
      "id_str" : "1871916889225785438",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1871916889225785438",
      "created_at" : "Wed Dec 25 13:52:19 +0000 2024",
      "favorited" : false,
      "full_text" : "あぶねー酢酸エチルの半減期を10^-3s台って書いてた。鬼速すぎるわ。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1871754831641325597"
          ],
          "editableUntil" : "2024-12-25T04:08:22.043Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "ウィンヒロ",
            "indices" : [
              "37",
              "43"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ウィンヒロ『WIND BREAKER 不良たちの英雄譚』公式",
            "screen_name" : "winhero_PR",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "1830452972817612800",
            "id" : "1830452972817612800"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1871754831641325597",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1871754831641325597",
      "created_at" : "Wed Dec 25 03:08:22 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @winhero_PR: 【アクリル色紙プレゼントキャンペーン】\n\n#ウィンヒロ オリジナル クリスマスイラストのアクリル色紙を抽選で10名様にプレゼント🎁✨\n\n▼応募方法\n本アカウントをフォロー＆この投稿をRP🔁\n\n▼応募期間\n12/31(火)23:59まで\n\n▼応募に…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1871712103255748883"
          ],
          "editableUntil" : "2024-12-25T01:18:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "1",
      "id_str" : "1871712103255748883",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1871712103255748883",
      "created_at" : "Wed Dec 25 00:18:34 +0000 2024",
      "favorited" : false,
      "full_text" : "もしや私が使ってる全ての路線が遅延してる？？？やめて？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1871681345803653554"
          ],
          "editableUntil" : "2024-12-24T23:16:21.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1871681345803653554/photo/1",
            "indices" : [
              "31",
              "54"
            ],
            "url" : "https://t.co/bCNpVpKAu3",
            "media_url" : "http://pbs.twimg.com/media/GfmMRAiakAArxTO.jpg",
            "id_str" : "1871681343979163648",
            "id" : "1871681343979163648",
            "media_url_https" : "https://pbs.twimg.com/media/GfmMRAiakAArxTO.jpg",
            "sizes" : {
              "large" : {
                "w" : "1024",
                "h" : "1024",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1024",
                "h" : "1024",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/bCNpVpKAu3"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "54"
      ],
      "favorite_count" : "12",
      "id_str" : "1871681345803653554",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1871681345803653554",
      "possibly_sensitive" : false,
      "created_at" : "Tue Dec 24 22:16:21 +0000 2024",
      "favorited" : false,
      "full_text" : "起きたら枕元にプレゼント置いてあった！サンタさんありがとう！ https://t.co/bCNpVpKAu3",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1871681345803653554/photo/1",
            "indices" : [
              "31",
              "54"
            ],
            "url" : "https://t.co/bCNpVpKAu3",
            "media_url" : "http://pbs.twimg.com/media/GfmMRAiakAArxTO.jpg",
            "id_str" : "1871681343979163648",
            "id" : "1871681343979163648",
            "media_url_https" : "https://pbs.twimg.com/media/GfmMRAiakAArxTO.jpg",
            "sizes" : {
              "large" : {
                "w" : "1024",
                "h" : "1024",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1024",
                "h" : "1024",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/bCNpVpKAu3"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1871423855589478757"
          ],
          "editableUntil" : "2024-12-24T06:13:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "カビゴンがXをとおせんぼ",
            "indices" : [
              "4",
              "17"
            ]
          },
          {
            "text" : "ポケモンスリープ",
            "indices" : [
              "85",
              "94"
            ]
          },
          {
            "text" : "ホリデープレゼントキャンペーン",
            "indices" : [
              "95",
              "111"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/2HNDbopWp1",
            "expanded_url" : "https://cp.pokemonsleepholiday.net/share/9hcig/index.html",
            "display_url" : "cp.pokemonsleepholiday.net/share/9hcig/in…",
            "indices" : [
              "113",
              "136"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "136"
      ],
      "favorite_count" : "0",
      "id_str" : "1871423855589478757",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1871423855589478757",
      "possibly_sensitive" : false,
      "created_at" : "Tue Dec 24 05:13:11 +0000 2024",
      "favorited" : false,
      "full_text" : "🎄┈🎁 #カビゴンがXをとおせんぼ🎁┈🎄\nわたしが見つけた ポケモンは…\n\n｡･ﾟ❄︎　イーブイ（ホリデー）　❄︎･ﾟ｡\n\n👇みんなもポケモンの寝顔を見つけてみよう✨\n\n#ポケモンスリープ\n#ホリデープレゼントキャンペーン\n\nhttps://t.co/2HNDbopWp1",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870851098954854812"
          ],
          "editableUntil" : "2024-12-22T16:17:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "2",
      "id_str" : "1870851098954854812",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1870851098954854812",
      "created_at" : "Sun Dec 22 15:17:15 +0000 2024",
      "favorited" : false,
      "full_text" : "あーあ、ボカロそこまで詳しくないからって理由でみくえっく見てないけど、TLの盛り上がり見てやっぱ見ればなあと…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870678095575056505"
          ],
          "editableUntil" : "2024-12-22T04:49:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "6",
      "id_str" : "1870678095575056505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1870678095575056505",
      "created_at" : "Sun Dec 22 03:49:48 +0000 2024",
      "favorited" : false,
      "full_text" : "やべバイトの時間1時間早く勘違いしてた…まあ1時間遅く勘違いするよりまし？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870406524285415601"
          ],
          "editableUntil" : "2024-12-21T10:50:40.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1870406524285415601/photo/1",
            "indices" : [
              "30",
              "53"
            ],
            "url" : "https://t.co/mKz5n2WL8m",
            "media_url" : "http://pbs.twimg.com/media/GfUEnMLbgAACorb.jpg",
            "id_str" : "1870406291572883456",
            "id" : "1870406291572883456",
            "media_url_https" : "https://pbs.twimg.com/media/GfUEnMLbgAACorb.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "379",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1079",
                "h" : "602",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1079",
                "h" : "602",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/mKz5n2WL8m"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "2",
      "id_str" : "1870406524285415601",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1870406524285415601",
      "possibly_sensitive" : false,
      "created_at" : "Sat Dec 21 09:50:40 +0000 2024",
      "favorited" : false,
      "full_text" : "ASE落単しそうってだけで怖いのにさらに怖いことしないで… https://t.co/mKz5n2WL8m",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1870406524285415601/photo/1",
            "indices" : [
              "30",
              "53"
            ],
            "url" : "https://t.co/mKz5n2WL8m",
            "media_url" : "http://pbs.twimg.com/media/GfUEnMLbgAACorb.jpg",
            "id_str" : "1870406291572883456",
            "id" : "1870406291572883456",
            "media_url_https" : "https://pbs.twimg.com/media/GfUEnMLbgAACorb.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "379",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1079",
                "h" : "602",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1079",
                "h" : "602",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/mKz5n2WL8m"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870341537177239945"
          ],
          "editableUntil" : "2024-12-21T06:32:26.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1870097615368733094",
      "id_str" : "1870341537177239945",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1870341537177239945",
      "in_reply_to_status_id" : "1870097615368733094",
      "created_at" : "Sat Dec 21 05:32:26 +0000 2024",
      "favorited" : false,
      "full_text" : "なんか目的語とか主語とか諸々なくない？私って本当に文系ですか？",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870261423475175771"
          ],
          "editableUntil" : "2024-12-21T01:14:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "0",
      "id_str" : "1870261423475175771",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1870261423475175771",
      "created_at" : "Sat Dec 21 00:14:05 +0000 2024",
      "favorited" : false,
      "full_text" : "インフル流行ってるのに、皮膚科と内科が併設されてる病院でマスクして行くの忘れたの本当に馬鹿",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870098415486665079"
          ],
          "editableUntil" : "2024-12-20T14:26:21.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "0",
      "id_str" : "1870098415486665079",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1870098415486665079",
      "created_at" : "Fri Dec 20 13:26:21 +0000 2024",
      "favorited" : false,
      "full_text" : "ピアスは私には合わなかったのかな。せっかく開けたけど全部閉鎖かな。半年間ありがとう。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1870097615368733094"
          ],
          "editableUntil" : "2024-12-20T14:23:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "1",
      "id_str" : "1870097615368733094",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1870097615368733094",
      "created_at" : "Fri Dec 20 13:23:10 +0000 2024",
      "favorited" : false,
      "full_text" : "ピアスの下の耳たぶキモかったからとりま外してたら、もう塞がってた…\n驚異の回復力…(今はいらない)",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869395838704951574"
          ],
          "editableUntil" : "2024-12-18T15:54:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "46"
      ],
      "favorite_count" : "0",
      "id_str" : "1869395838704951574",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1869395838704951574",
      "created_at" : "Wed Dec 18 14:54:34 +0000 2024",
      "favorited" : false,
      "full_text" : "前期はくそでかタスクだと思ってた課題がメンタル的に、くそちょっとでかタスクくらいになったかも",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869310487965646987"
          ],
          "editableUntil" : "2024-12-18T10:15:25.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "1",
      "id_str" : "1869310487965646987",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1869310487965646987",
      "created_at" : "Wed Dec 18 09:15:25 +0000 2024",
      "favorited" : false,
      "full_text" : "LINEで一番よく喋る友達の個チャとサークルのグルチャが隣り合ってるの怖すぎる。肝冷える。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1869028530304307592"
          ],
          "editableUntil" : "2024-12-17T15:35:01.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "2",
      "id_str" : "1869028530304307592",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1869028530304307592",
      "created_at" : "Tue Dec 17 14:35:01 +0000 2024",
      "favorited" : false,
      "full_text" : "終電乗り換えでダッシュしたら咳止まらなくてつらい",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868592170003046762"
          ],
          "editableUntil" : "2024-12-16T10:41:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1868592170003046762/photo/1",
            "indices" : [
              "51",
              "74"
            ],
            "url" : "https://t.co/GA0eITVgx2",
            "media_url" : "http://pbs.twimg.com/media/Ge6Sdn_acAAz4Jc.jpg",
            "id_str" : "1868591933054152704",
            "id" : "1868591933054152704",
            "media_url_https" : "https://pbs.twimg.com/media/Ge6Sdn_acAAz4Jc.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "453",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "800",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1620",
                "h" : "1080",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/GA0eITVgx2"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "74"
      ],
      "favorite_count" : "12",
      "id_str" : "1868592170003046762",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1868592170003046762",
      "possibly_sensitive" : false,
      "created_at" : "Mon Dec 16 09:41:04 +0000 2024",
      "favorited" : false,
      "full_text" : "2次曲線y=x^2をy軸周りに1回転させてできるイルミネーション\nって言ったら連れ全員に怒られた() https://t.co/GA0eITVgx2",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1868592170003046762/photo/1",
            "indices" : [
              "51",
              "74"
            ],
            "url" : "https://t.co/GA0eITVgx2",
            "media_url" : "http://pbs.twimg.com/media/Ge6Sdn_acAAz4Jc.jpg",
            "id_str" : "1868591933054152704",
            "id" : "1868591933054152704",
            "media_url_https" : "https://pbs.twimg.com/media/Ge6Sdn_acAAz4Jc.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "453",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "800",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1620",
                "h" : "1080",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/GA0eITVgx2"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1868266876213903779"
          ],
          "editableUntil" : "2024-12-15T13:08:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "5",
      "id_str" : "1868266876213903779",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1868266876213903779",
      "created_at" : "Sun Dec 15 12:08:28 +0000 2024",
      "favorited" : false,
      "full_text" : "力学は\nきちんと平均\n割りました\n平常点で\nカバーしたいが…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867867095473729924"
          ],
          "editableUntil" : "2024-12-14T10:39:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "18"
      ],
      "favorite_count" : "0",
      "id_str" : "1867867095473729924",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867867095473729924",
      "created_at" : "Sat Dec 14 09:39:53 +0000 2024",
      "favorited" : false,
      "full_text" : "紙飛行機を飛ばす技術結構高いと思った",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1867089965324308826"
          ],
          "editableUntil" : "2024-12-12T07:11:51.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "1",
      "id_str" : "1867089965324308826",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1867089965324308826",
      "created_at" : "Thu Dec 12 06:11:51 +0000 2024",
      "favorited" : false,
      "full_text" : "どうせならちょっとふざけて書いたアスピリンの感想部分を紹介して欲しかったなー",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866980673480954050"
          ],
          "editableUntil" : "2024-12-11T23:57:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "id_str" : "1866980673480954050",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866980673480954050",
      "created_at" : "Wed Dec 11 22:57:34 +0000 2024",
      "favorited" : false,
      "full_text" : "久しぶりに思い出してアブさんのあつ森実況を今更見始めてたら時間が溶けまくった",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866636632541237545"
          ],
          "editableUntil" : "2024-12-11T01:10:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "3",
      "id_str" : "1866636632541237545",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866636632541237545",
      "created_at" : "Wed Dec 11 00:10:28 +0000 2024",
      "favorited" : false,
      "full_text" : "夏休みのびっけん先取りが思ってた以上に頑張ってた。感動…！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866509115734049035"
          ],
          "editableUntil" : "2024-12-10T16:43:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1866509115734049035/photo/1",
            "indices" : [
              "18",
              "41"
            ],
            "url" : "https://t.co/gMR3E1rITs",
            "media_url" : "http://pbs.twimg.com/media/Gecr-PtaQAENf-8.jpg",
            "id_str" : "1866508918937239553",
            "id" : "1866508918937239553",
            "media_url_https" : "https://pbs.twimg.com/media/Gecr-PtaQAENf-8.jpg",
            "sizes" : {
              "large" : {
                "w" : "1080",
                "h" : "1080",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1080",
                "h" : "1080",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/gMR3E1rITs"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "41"
      ],
      "favorite_count" : "0",
      "id_str" : "1866509115734049035",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866509115734049035",
      "possibly_sensitive" : false,
      "created_at" : "Tue Dec 10 15:43:45 +0000 2024",
      "favorited" : false,
      "full_text" : "エナドリあるある\n…いや何味？？？ https://t.co/gMR3E1rITs",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1866509115734049035/photo/1",
            "indices" : [
              "18",
              "41"
            ],
            "url" : "https://t.co/gMR3E1rITs",
            "media_url" : "http://pbs.twimg.com/media/Gecr-PtaQAENf-8.jpg",
            "id_str" : "1866508918937239553",
            "id" : "1866508918937239553",
            "media_url_https" : "https://pbs.twimg.com/media/Gecr-PtaQAENf-8.jpg",
            "sizes" : {
              "large" : {
                "w" : "1080",
                "h" : "1080",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1080",
                "h" : "1080",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/gMR3E1rITs"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866449100973183421"
          ],
          "editableUntil" : "2024-12-10T12:45:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "id_str" : "1866449100973183421",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866449100973183421",
      "created_at" : "Tue Dec 10 11:45:17 +0000 2024",
      "favorited" : false,
      "full_text" : "図書館ゲートにはSuicaを、駅の改札には学生証をかざそうとしてしまう",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866274882511896739"
          ],
          "editableUntil" : "2024-12-10T01:13:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "1",
      "id_str" : "1866274882511896739",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866274882511896739",
      "created_at" : "Tue Dec 10 00:13:00 +0000 2024",
      "favorited" : false,
      "full_text" : "4月からずっと使ってる電車から東京スカイツリーがみえるポイントがあることに初めて気がついた！かっけー！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1866057945550926255"
          ],
          "editableUntil" : "2024-12-09T10:50:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1866057945550926255/photo/1",
            "indices" : [
              "22",
              "45"
            ],
            "url" : "https://t.co/Dds7NwZ5Aq",
            "media_url" : "http://pbs.twimg.com/media/GeWRuuMbQAAXBut.jpg",
            "id_str" : "1866057852475097088",
            "id" : "1866057852475097088",
            "media_url_https" : "https://pbs.twimg.com/media/GeWRuuMbQAAXBut.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1080",
                "h" : "1080",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1080",
                "h" : "1080",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/Dds7NwZ5Aq"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "1",
      "id_str" : "1866057945550926255",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1866057945550926255",
      "possibly_sensitive" : false,
      "created_at" : "Mon Dec 09 09:50:58 +0000 2024",
      "favorited" : false,
      "full_text" : "勝因は一回もカスミ使いに出会わなかったこと https://t.co/Dds7NwZ5Aq",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1866057945550926255/photo/1",
            "indices" : [
              "22",
              "45"
            ],
            "url" : "https://t.co/Dds7NwZ5Aq",
            "media_url" : "http://pbs.twimg.com/media/GeWRuuMbQAAXBut.jpg",
            "id_str" : "1866057852475097088",
            "id" : "1866057852475097088",
            "media_url_https" : "https://pbs.twimg.com/media/GeWRuuMbQAAXBut.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1080",
                "h" : "1080",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1080",
                "h" : "1080",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/Dds7NwZ5Aq"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1865714412272893978"
          ],
          "editableUntil" : "2024-12-08T12:05:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "46"
      ],
      "favorite_count" : "0",
      "id_str" : "1865714412272893978",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1865714412272893978",
      "created_at" : "Sun Dec 08 11:05:53 +0000 2024",
      "favorited" : false,
      "full_text" : "弟とその友達のインスタのイキリ具合が過去の私を救ってくれる。同じ類の人みると本当に安心する。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1865685271108608405"
          ],
          "editableUntil" : "2024-12-08T10:10:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1865684905587560611",
      "id_str" : "1865685271108608405",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1865685271108608405",
      "in_reply_to_status_id" : "1865684905587560611",
      "created_at" : "Sun Dec 08 09:10:06 +0000 2024",
      "favorited" : false,
      "full_text" : "もしその方々が高校生なんだったら年相応に見える努力をもっとしてほしいし",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1865684905587560611"
          ],
          "editableUntil" : "2024-12-08T10:08:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "1",
      "id_str" : "1865684905587560611",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1865684905587560611",
      "created_at" : "Sun Dec 08 09:08:38 +0000 2024",
      "favorited" : false,
      "full_text" : "自習室にテスト期間？のみに現れる地元中学のみなさまガチうるせえ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1865387887224869003"
          ],
          "editableUntil" : "2024-12-07T14:28:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "15"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1865387814155948404",
      "id_str" : "1865387887224869003",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1865387887224869003",
      "in_reply_to_status_id" : "1865387814155948404",
      "created_at" : "Sat Dec 07 13:28:24 +0000 2024",
      "favorited" : false,
      "full_text" : "Twitterは引退しないけど",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1865387814155948404"
          ],
          "editableUntil" : "2024-12-07T14:28:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "0",
      "id_str" : "1865387814155948404",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1865387814155948404",
      "created_at" : "Sat Dec 07 13:28:06 +0000 2024",
      "favorited" : false,
      "full_text" : "やっぱネットリテラシー無さすぎるからインスタ引退しよかな",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1865178116160917665"
          ],
          "editableUntil" : "2024-12-07T00:34:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "13"
      ],
      "favorite_count" : "0",
      "id_str" : "1865178116160917665",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1865178116160917665",
      "created_at" : "Fri Dec 06 23:34:50 +0000 2024",
      "favorited" : false,
      "full_text" : "3時間のばおわ！いい現場！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1864961388705358112"
          ],
          "editableUntil" : "2024-12-06T10:13:39.031Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ウィンヒロ『WIND BREAKER 不良たちの英雄譚』公式",
            "screen_name" : "winhero_PR",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "1830452972817612800",
            "id" : "1830452972817612800"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1864961388705358112",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1864961388705358112",
      "created_at" : "Fri Dec 06 09:13:39 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @winhero_PR: 【イラスト公開記念プレゼントキャンペーン第9弾】\n\n十亀 条のキャラクターイラストを使用したアクリルスタンドを抽選で10名様にプレゼント🎁\n\n▼応募方法\n本アカウントをフォロー＆この投稿をRP🔁\n\n▼応募期間\n12/12(木)23:59まで\n\n▼…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1864834184155664631"
          ],
          "editableUntil" : "2024-12-06T01:48:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1864834184155664631/photo/1",
            "indices" : [
              "54",
              "77"
            ],
            "url" : "https://t.co/NwexsBScqE",
            "media_url" : "http://pbs.twimg.com/media/GeE4bQrbgAAUTCL.jpg",
            "id_str" : "1864833761692844032",
            "id" : "1864833761692844032",
            "media_url_https" : "https://pbs.twimg.com/media/GeE4bQrbgAAUTCL.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "671",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "380",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1605",
                "h" : "897",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/NwexsBScqE"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "77"
      ],
      "favorite_count" : "2",
      "id_str" : "1864834184155664631",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1864834184155664631",
      "possibly_sensitive" : false,
      "created_at" : "Fri Dec 06 00:48:11 +0000 2024",
      "favorited" : false,
      "full_text" : "高1で挫折したプロセカのスクショだけど、その時から七億円名乗ってたのか。春に初めて考えた名前だと思ってた。 https://t.co/NwexsBScqE",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1864834184155664631/photo/1",
            "indices" : [
              "54",
              "77"
            ],
            "url" : "https://t.co/NwexsBScqE",
            "media_url" : "http://pbs.twimg.com/media/GeE4bQrbgAAUTCL.jpg",
            "id_str" : "1864833761692844032",
            "id" : "1864833761692844032",
            "media_url_https" : "https://pbs.twimg.com/media/GeE4bQrbgAAUTCL.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "671",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "380",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1605",
                "h" : "897",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/NwexsBScqE"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1864476194584056262"
          ],
          "editableUntil" : "2024-12-05T02:05:39.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "0",
      "id_str" : "1864476194584056262",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1864476194584056262",
      "created_at" : "Thu Dec 05 01:05:39 +0000 2024",
      "favorited" : false,
      "full_text" : "お昼ごはん運搬にガチになりすぎて左腕が痛い",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1863487744892338473"
          ],
          "editableUntil" : "2024-12-02T08:37:54.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "0",
      "id_str" : "1863487744892338473",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1863487744892338473",
      "created_at" : "Mon Dec 02 07:37:54 +0000 2024",
      "favorited" : false,
      "full_text" : "お腹すいてお腹いたいからパンたべたけど、まだいたい…\nつまり、別の事象に起因する腹痛であると導かれる。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1863353972918280529"
          ],
          "editableUntil" : "2024-12-01T23:46:21.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "id_str" : "1863353972918280529",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1863353972918280529",
      "created_at" : "Sun Dec 01 22:46:21 +0000 2024",
      "favorited" : false,
      "full_text" : "眠すぎるけど勉強したいから電車の手すりに向かって自主的ヘドバンをかましていく",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1863233192498737280"
          ],
          "editableUntil" : "2024-12-01T15:46:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1863233192498737280/photo/1",
            "indices" : [
              "16",
              "39"
            ],
            "url" : "https://t.co/UTCsPFSJbQ",
            "media_url" : "http://pbs.twimg.com/media/GduIpEJWEAAYO_T.jpg",
            "id_str" : "1863233109916782592",
            "id" : "1863233109916782592",
            "media_url_https" : "https://pbs.twimg.com/media/GduIpEJWEAAYO_T.jpg",
            "sizes" : {
              "medium" : {
                "w" : "661",
                "h" : "1200",
                "resize" : "fit"
              },
              "small" : {
                "w" : "375",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1080",
                "h" : "1960",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/UTCsPFSJbQ"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "1",
      "id_str" : "1863233192498737280",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1863233192498737280",
      "possibly_sensitive" : false,
      "created_at" : "Sun Dec 01 14:46:24 +0000 2024",
      "favorited" : false,
      "full_text" : "日曜あるある\n営業時間縮めがち https://t.co/UTCsPFSJbQ",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1863233192498737280/photo/1",
            "indices" : [
              "16",
              "39"
            ],
            "url" : "https://t.co/UTCsPFSJbQ",
            "media_url" : "http://pbs.twimg.com/media/GduIpEJWEAAYO_T.jpg",
            "id_str" : "1863233109916782592",
            "id" : "1863233109916782592",
            "media_url_https" : "https://pbs.twimg.com/media/GduIpEJWEAAYO_T.jpg",
            "sizes" : {
              "medium" : {
                "w" : "661",
                "h" : "1200",
                "resize" : "fit"
              },
              "small" : {
                "w" : "375",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1080",
                "h" : "1960",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/UTCsPFSJbQ"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1863207612952752153"
          ],
          "editableUntil" : "2024-12-01T14:04:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "0",
      "id_str" : "1863207612952752153",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1863207612952752153",
      "created_at" : "Sun Dec 01 13:04:46 +0000 2024",
      "favorited" : false,
      "full_text" : "どうしよ暗記しさせすれば点とれる中国語のせいで力学できない…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1862752374269649128"
          ],
          "editableUntil" : "2024-11-30T07:55:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "36"
      ],
      "favorite_count" : "1",
      "id_str" : "1862752374269649128",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1862752374269649128",
      "created_at" : "Sat Nov 30 06:55:48 +0000 2024",
      "favorited" : false,
      "full_text" : "線形のカンニングペーパー何作ろうかしらん？とりまリアペ敷き詰めるか？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1862541517208133985"
          ],
          "editableUntil" : "2024-11-29T17:57:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "0",
      "id_str" : "1862541517208133985",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1862541517208133985",
      "created_at" : "Fri Nov 29 16:57:56 +0000 2024",
      "favorited" : false,
      "full_text" : "久しぶりのエッグい濃度の鼻血。とまんねえぜ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1862479208104304955"
          ],
          "editableUntil" : "2024-11-29T13:50:21.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1862120283769040969",
      "id_str" : "1862479208104304955",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1862479208104304955",
      "in_reply_to_status_id" : "1862120283769040969",
      "created_at" : "Fri Nov 29 12:50:21 +0000 2024",
      "favorited" : false,
      "full_text" : "やったー！1周回れたー！やっと走れたー！",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1862120283769040969"
          ],
          "editableUntil" : "2024-11-28T14:04:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "18"
      ],
      "favorite_count" : "1",
      "id_str" : "1862120283769040969",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1862120283769040969",
      "created_at" : "Thu Nov 28 13:04:06 +0000 2024",
      "favorited" : false,
      "full_text" : "明日こそ走りたい！走らせてくれ！！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1862118270842835442"
          ],
          "editableUntil" : "2024-11-28T13:56:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "8",
      "id_str" : "1862118270842835442",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1862118270842835442",
      "created_at" : "Thu Nov 28 12:56:06 +0000 2024",
      "favorited" : false,
      "full_text" : "昨日は図書館のゲートに入館拒否され、今日はB棟、C棟で追い出されたので私の居場所を否定され続けている（）",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1861558305443004907"
          ],
          "editableUntil" : "2024-11-27T00:51:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "0",
      "id_str" : "1861558305443004907",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1861558305443004907",
      "created_at" : "Tue Nov 26 23:51:00 +0000 2024",
      "favorited" : false,
      "full_text" : "源さんのライブとか久しぶりすぎて嬉しいけど、さいアリは争奪戦だな…\n(ｻｲｱｸｲﾍﾞﾝﾄｽﾀｯﾌﾄｼﾃﾓｸﾞﾘｺﾑｶ…?)",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1861557296947699898"
          ],
          "editableUntil" : "2024-11-27T00:47:00.311Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "星野源 Gen Hoshino",
            "screen_name" : "gen_senden",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "137682023",
            "id" : "137682023"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/qnt9bNHmKj",
            "expanded_url" : "https://www.hoshinogen.com/special/tour2025/",
            "display_url" : "hoshinogen.com/special/tour20…",
            "indices" : [
              "69",
              "92"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1861557296947699898",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1861557296947699898",
      "possibly_sensitive" : false,
      "created_at" : "Tue Nov 26 23:47:00 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @gen_senden: 星野源、来春アルバムリリース＆全国アリーナツアー決定！\nツアー日程などの詳細はこちらからご確認ください。\nhttps://t.co/qnt9bNHmKj\n\n本日発売の「読売新聞」朝刊にも見開き広告が掲載されていますので、ぜひチェックしてくださいね…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1860565269271445724"
          ],
          "editableUntil" : "2024-11-24T07:05:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "60"
      ],
      "favorite_count" : "1",
      "id_str" : "1860565269271445724",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1860565269271445724",
      "created_at" : "Sun Nov 24 06:05:02 +0000 2024",
      "favorited" : false,
      "full_text" : "今日は結局テントがないかもしれないと心配だったがちゃんとあってものすごく安心したサークルでずっと受付してた！\n完売御礼！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1860314412432965912"
          ],
          "editableUntil" : "2024-11-23T14:28:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "81"
      ],
      "favorite_count" : "3",
      "id_str" : "1860314412432965912",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1860314412432965912",
      "created_at" : "Sat Nov 23 13:28:13 +0000 2024",
      "favorited" : false,
      "full_text" : "明日は自分らの作品が完成しきれなかったサークル、そもそも自分の作品提出を諦めたサークル、テントがあるかわからないサークル、どのサークルにお手伝いにいこうかしらん♪",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1859514892996509852"
          ],
          "editableUntil" : "2024-11-21T09:31:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1859514892996509852/photo/1",
            "indices" : [
              "19",
              "42"
            ],
            "url" : "https://t.co/EdBo0KuP0k",
            "media_url" : "http://pbs.twimg.com/media/Gc5S6WfaAAI9WbM.jpg",
            "id_str" : "1859514858573791234",
            "id" : "1859514858573791234",
            "media_url_https" : "https://pbs.twimg.com/media/Gc5S6WfaAAI9WbM.jpg",
            "sizes" : {
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              },
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/EdBo0KuP0k"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "2",
      "id_str" : "1859514892996509852",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1859514892996509852",
      "possibly_sensitive" : false,
      "created_at" : "Thu Nov 21 08:31:13 +0000 2024",
      "favorited" : false,
      "full_text" : "そういえば普通のEXカードも出てきた https://t.co/EdBo0KuP0k",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1859514892996509852/photo/1",
            "indices" : [
              "19",
              "42"
            ],
            "url" : "https://t.co/EdBo0KuP0k",
            "media_url" : "http://pbs.twimg.com/media/Gc5S6WfaAAI9WbM.jpg",
            "id_str" : "1859514858573791234",
            "id" : "1859514858573791234",
            "media_url_https" : "https://pbs.twimg.com/media/Gc5S6WfaAAI9WbM.jpg",
            "sizes" : {
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              },
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/EdBo0KuP0k"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1859436708124868867"
          ],
          "editableUntil" : "2024-11-21T04:20:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1859436708124868867/photo/1",
            "indices" : [
              "49",
              "72"
            ],
            "url" : "https://t.co/B49jGaRYGJ",
            "media_url" : "http://pbs.twimg.com/media/Gc4LoFiaAAMcgrX.jpg",
            "id_str" : "1859436479459753987",
            "id" : "1859436479459753987",
            "media_url_https" : "https://pbs.twimg.com/media/Gc4LoFiaAAMcgrX.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/B49jGaRYGJ"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "72"
      ],
      "favorite_count" : "8",
      "id_str" : "1859436708124868867",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1859436708124868867",
      "possibly_sensitive" : false,
      "created_at" : "Thu Nov 21 03:20:32 +0000 2024",
      "favorited" : false,
      "full_text" : "いまポケポケが流行中とのことで、私が10歳の時にゲットしたEXカードのごく一部をお見せいたします https://t.co/B49jGaRYGJ",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1859436708124868867/photo/1",
            "indices" : [
              "49",
              "72"
            ],
            "url" : "https://t.co/B49jGaRYGJ",
            "media_url" : "http://pbs.twimg.com/media/Gc4LoFiaAAMcgrX.jpg",
            "id_str" : "1859436479459753987",
            "id" : "1859436479459753987",
            "media_url_https" : "https://pbs.twimg.com/media/Gc4LoFiaAAMcgrX.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1536",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/B49jGaRYGJ"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1859223724735787439"
          ],
          "editableUntil" : "2024-11-20T14:14:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "1",
      "id_str" : "1859223724735787439",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1859223724735787439",
      "created_at" : "Wed Nov 20 13:14:13 +0000 2024",
      "favorited" : false,
      "full_text" : "昨日のある人のツイートに関する衝撃の事実を知ってバカ笑ってたw\n登場人物全員知り合いw",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1858278890449609147"
          ],
          "editableUntil" : "2024-11-17T23:39:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "1",
      "id_str" : "1858278890449609147",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1858278890449609147",
      "created_at" : "Sun Nov 17 22:39:47 +0000 2024",
      "favorited" : false,
      "full_text" : "電車の手すりに顔面を殴打することで目覚める毎日",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1858031602720289037"
          ],
          "editableUntil" : "2024-11-17T07:17:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "26"
      ],
      "favorite_count" : "0",
      "id_str" : "1858031602720289037",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1858031602720289037",
      "created_at" : "Sun Nov 17 06:17:09 +0000 2024",
      "favorited" : false,
      "full_text" : "LINEのリアクションにあいづち😌みたいなやつ欲しい",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1858015442339770579"
          ],
          "editableUntil" : "2024-11-17T06:12:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1858015253885497436",
      "id_str" : "1858015442339770579",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1858015442339770579",
      "in_reply_to_status_id" : "1858015253885497436",
      "created_at" : "Sun Nov 17 05:12:56 +0000 2024",
      "favorited" : false,
      "full_text" : "ぼかし方キモいけどスマホの標準機能使ってるからしゃあなし",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1858015253885497436"
          ],
          "editableUntil" : "2024-11-17T06:12:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1858015253885497436/photo/1",
            "indices" : [
              "42",
              "65"
            ],
            "url" : "https://t.co/tiCYcpCxpv",
            "media_url" : "http://pbs.twimg.com/media/Gcj-7eUaMAEcYEg.jpg",
            "id_str" : "1858015143994732545",
            "id" : "1858015143994732545",
            "media_url_https" : "https://pbs.twimg.com/media/Gcj-7eUaMAEcYEg.jpg",
            "sizes" : {
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              },
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/tiCYcpCxpv"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "1",
      "id_str" : "1858015253885497436",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1858015253885497436",
      "possibly_sensitive" : false,
      "created_at" : "Sun Nov 17 05:12:11 +0000 2024",
      "favorited" : false,
      "full_text" : "この忙しい時期に写真加工のアメイジングさに気づき直してしまった。全然印象変わるね。 https://t.co/tiCYcpCxpv",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1858015253885497436/photo/1",
            "indices" : [
              "42",
              "65"
            ],
            "url" : "https://t.co/tiCYcpCxpv",
            "media_url" : "http://pbs.twimg.com/media/Gcj-7eUaMAEcYEg.jpg",
            "id_str" : "1858015143994732545",
            "id" : "1858015143994732545",
            "media_url_https" : "https://pbs.twimg.com/media/Gcj-7eUaMAEcYEg.jpg",
            "sizes" : {
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              },
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/tiCYcpCxpv"
          },
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1858015253885497436/photo/1",
            "indices" : [
              "42",
              "65"
            ],
            "url" : "https://t.co/tiCYcpCxpv",
            "media_url" : "http://pbs.twimg.com/media/Gcj-8jib0AAayIP.jpg",
            "id_str" : "1858015162575605760",
            "id" : "1858015162575605760",
            "media_url_https" : "https://pbs.twimg.com/media/Gcj-8jib0AAayIP.jpg",
            "sizes" : {
              "medium" : {
                "w" : "675",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1152",
                "h" : "2048",
                "resize" : "fit"
              },
              "small" : {
                "w" : "382",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/tiCYcpCxpv"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1857446633602191744"
          ],
          "editableUntil" : "2024-11-15T16:32:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "17"
      ],
      "favorite_count" : "0",
      "id_str" : "1857446633602191744",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1857446633602191744",
      "created_at" : "Fri Nov 15 15:32:41 +0000 2024",
      "favorited" : false,
      "full_text" : "卓球は久しぶりにやるから楽しいんよ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1857220193224896910"
          ],
          "editableUntil" : "2024-11-15T01:32:54.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "2",
      "id_str" : "1857220193224896910",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1857220193224896910",
      "created_at" : "Fri Nov 15 00:32:54 +0000 2024",
      "favorited" : false,
      "full_text" : "コーシー・アダマールの定理を\nコーヒーアッタマルーの定理と呼んでるの私だけじゃないはず",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1857218203568792053"
          ],
          "editableUntil" : "2024-11-15T01:24:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "0",
      "id_str" : "1857218203568792053",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1857218203568792053",
      "created_at" : "Fri Nov 15 00:24:59 +0000 2024",
      "favorited" : false,
      "full_text" : "そして目の前の人に顔面ダイブすんのも痴漢だと思われそうだからやめたい",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1857217873577730062"
          ],
          "editableUntil" : "2024-11-15T01:23:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "0",
      "id_str" : "1857217873577730062",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1857217873577730062",
      "created_at" : "Fri Nov 15 00:23:41 +0000 2024",
      "favorited" : false,
      "full_text" : "電車内で眠すぎてヘドバンすんのもうやめたい",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1856889042077643015"
          ],
          "editableUntil" : "2024-11-14T03:37:01.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "1",
      "id_str" : "1856889042077643015",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1856889042077643015",
      "created_at" : "Thu Nov 14 02:37:01 +0000 2024",
      "favorited" : false,
      "full_text" : "基礎プロ、自分のもすごいと思ってたのに…。遥かに上をいく作品をみんな作りすぎ()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1855403352705962041"
          ],
          "editableUntil" : "2024-11-10T01:13:25.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "32"
      ],
      "favorite_count" : "0",
      "id_str" : "1855403352705962041",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1855403352705962041",
      "created_at" : "Sun Nov 10 00:13:25 +0000 2024",
      "favorited" : false,
      "full_text" : "10年ぶりに着るジャンルのファッションが思ったより違和感ないぞ？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1854248651792781317"
          ],
          "editableUntil" : "2024-11-06T20:45:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "12"
      ],
      "favorite_count" : "1",
      "id_str" : "1854248651792781317",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1854248651792781317",
      "created_at" : "Wed Nov 06 19:45:03 +0000 2024",
      "favorited" : false,
      "full_text" : "おやすみなscience",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1854248541147013449"
          ],
          "editableUntil" : "2024-11-06T20:44:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "26"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1854248417968689270",
      "id_str" : "1854248541147013449",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1854248541147013449",
      "in_reply_to_status_id" : "1854248417968689270",
      "created_at" : "Wed Nov 06 19:44:37 +0000 2024",
      "favorited" : false,
      "full_text" : "前回までは土日に終わってたのに微積のせいで全部狂った",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1854248417968689270"
          ],
          "editableUntil" : "2024-11-06T20:44:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "17"
      ],
      "favorite_count" : "0",
      "id_str" : "1854248417968689270",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1854248417968689270",
      "created_at" : "Wed Nov 06 19:44:07 +0000 2024",
      "favorited" : false,
      "full_text" : "こんなに切羽詰まった謁見初めてかも",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1852588198230475155"
          ],
          "editableUntil" : "2024-11-02T06:47:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "9"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1852588081699811710",
      "id_str" : "1852588198230475155",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1852588198230475155",
      "in_reply_to_status_id" : "1852588081699811710",
      "created_at" : "Sat Nov 02 05:47:00 +0000 2024",
      "favorited" : false,
      "full_text" : "(わかってるだけ)",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1852588081699811710"
          ],
          "editableUntil" : "2024-11-02T06:46:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "2",
      "id_str" : "1852588081699811710",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1852588081699811710",
      "created_at" : "Sat Nov 02 05:46:32 +0000 2024",
      "favorited" : false,
      "full_text" : "24のポケポケプレイヤーを全員フレンド申請するの巻",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1852349270927786470"
          ],
          "editableUntil" : "2024-11-01T14:57:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "id_str" : "1852349270927786470",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1852349270927786470",
      "created_at" : "Fri Nov 01 13:57:35 +0000 2024",
      "favorited" : false,
      "full_text" : "Gitの使い方を大間違えしてた()\nそして〆まであと14日！！！やばい！！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1851983616819298748"
          ],
          "editableUntil" : "2024-10-31T14:44:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "3",
      "id_str" : "1851983616819298748",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1851983616819298748",
      "created_at" : "Thu Oct 31 13:44:37 +0000 2024",
      "favorited" : false,
      "full_text" : "「今日の部室まじカオスだな」を毎回超えてくる()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1851807160973562212"
          ],
          "editableUntil" : "2024-10-31T03:03:26.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1851807160973562212/photo/1",
            "indices" : [
              "26",
              "49"
            ],
            "url" : "https://t.co/zDGHBdVSkS",
            "media_url" : "http://pbs.twimg.com/media/GbLwlfqbIAA9Y0R.jpg",
            "id_str" : "1851806923747958784",
            "id" : "1851806923747958784",
            "media_url_https" : "https://pbs.twimg.com/media/GbLwlfqbIAA9Y0R.jpg",
            "sizes" : {
              "large" : {
                "w" : "1078",
                "h" : "1907",
                "resize" : "fit"
              },
              "small" : {
                "w" : "384",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "678",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/zDGHBdVSkS"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "0",
      "id_str" : "1851807160973562212",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1851807160973562212",
      "possibly_sensitive" : false,
      "created_at" : "Thu Oct 31 02:03:26 +0000 2024",
      "favorited" : false,
      "full_text" : "なんだかよくわからんままチュートリアルがおわってた https://t.co/zDGHBdVSkS",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1851807160973562212/photo/1",
            "indices" : [
              "26",
              "49"
            ],
            "url" : "https://t.co/zDGHBdVSkS",
            "media_url" : "http://pbs.twimg.com/media/GbLwlfqbIAA9Y0R.jpg",
            "id_str" : "1851806923747958784",
            "id" : "1851806923747958784",
            "media_url_https" : "https://pbs.twimg.com/media/GbLwlfqbIAA9Y0R.jpg",
            "sizes" : {
              "large" : {
                "w" : "1078",
                "h" : "1907",
                "resize" : "fit"
              },
              "small" : {
                "w" : "384",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "678",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/zDGHBdVSkS"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1851430541759037708"
          ],
          "editableUntil" : "2024-10-30T02:06:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "16"
      ],
      "favorite_count" : "0",
      "id_str" : "1851430541759037708",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1851430541759037708",
      "created_at" : "Wed Oct 30 01:06:53 +0000 2024",
      "favorited" : false,
      "full_text" : "あー！！！国領トラップめー！！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1851410667087245807"
          ],
          "editableUntil" : "2024-10-30T00:47:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "15"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1851410580013502580",
      "id_str" : "1851410667087245807",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1851410667087245807",
      "in_reply_to_status_id" : "1851410580013502580",
      "created_at" : "Tue Oct 29 23:47:55 +0000 2024",
      "favorited" : false,
      "full_text" : "よく考えたら若干ストーカー（）",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1851410580013502580"
          ],
          "editableUntil" : "2024-10-30T00:47:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "0",
      "id_str" : "1851410580013502580",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1851410580013502580",
      "created_at" : "Tue Oct 29 23:47:34 +0000 2024",
      "favorited" : false,
      "full_text" : "上野東京ラインに小中のときすごく仲良くしてくれた子が乗ってたけど、私が行きたいのは新宿だから乗れなかった…！惜しい…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1851235001825968367"
          ],
          "editableUntil" : "2024-10-29T13:09:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "46"
      ],
      "favorite_count" : "0",
      "id_str" : "1851235001825968367",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1851235001825968367",
      "created_at" : "Tue Oct 29 12:09:53 +0000 2024",
      "favorited" : false,
      "full_text" : "PCからSDカードがはみだすから、小さめのスロット買ったのにそれでもだいぶはみ出してて悲しい",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1847995915979898949"
          ],
          "editableUntil" : "2024-10-20T14:38:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "0",
      "id_str" : "1847995915979898949",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1847995915979898949",
      "created_at" : "Sun Oct 20 13:38:55 +0000 2024",
      "favorited" : false,
      "full_text" : "やべガチでやばいときの血出てきた耳が内出血して青くなってきた",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1847991786607706438"
          ],
          "editableUntil" : "2024-10-20T14:22:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "50"
      ],
      "favorite_count" : "0",
      "id_str" : "1847991786607706438",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1847991786607706438",
      "created_at" : "Sun Oct 20 13:22:30 +0000 2024",
      "favorited" : false,
      "full_text" : "ピアス外した時の、確かに臭いんだけど何故か心地よい臭いは、何の臭いに似てるって言えば伝わるんだ？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1847991327105098172"
          ],
          "editableUntil" : "2024-10-20T14:20:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "41"
      ],
      "favorite_count" : "0",
      "id_str" : "1847991327105098172",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1847991327105098172",
      "created_at" : "Sun Oct 20 13:20:41 +0000 2024",
      "favorited" : false,
      "full_text" : "耳たぶが厚すぎるせいでせっかく買ったピアスが付けられんかった…さよなら330円()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1847464292599419006"
          ],
          "editableUntil" : "2024-10-19T03:26:26.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "14",
      "id_str" : "1847464292599419006",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1847464292599419006",
      "created_at" : "Sat Oct 19 02:26:26 +0000 2024",
      "favorited" : false,
      "full_text" : "やべ等電位線の銀ペースト触った手で鼻ほじっちゃった",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1846918320311984292"
          ],
          "editableUntil" : "2024-10-17T15:16:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "0",
      "id_str" : "1846918320311984292",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1846918320311984292",
      "created_at" : "Thu Oct 17 14:16:56 +0000 2024",
      "favorited" : false,
      "full_text" : "LINEのリアクション機能、ぽっと出野郎のはずなのになかった時のことが思い出せないくらい使いまくってる",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1846853742425264234"
          ],
          "editableUntil" : "2024-10-17T11:00:19.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "32"
      ],
      "favorite_count" : "0",
      "id_str" : "1846853742425264234",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1846853742425264234",
      "created_at" : "Thu Oct 17 10:00:19 +0000 2024",
      "favorited" : false,
      "full_text" : "新技習得のために使わない筋肉を使ったせいで足も腰も腕もやばい痛い",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1846549220645536206"
          ],
          "editableUntil" : "2024-10-16T14:50:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "0",
      "id_str" : "1846549220645536206",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1846549220645536206",
      "created_at" : "Wed Oct 16 13:50:16 +0000 2024",
      "favorited" : false,
      "full_text" : "選中の先生に認知されてすれ違ったらあいさつするようになった笑",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1846193763091468502"
          ],
          "editableUntil" : "2024-10-15T15:17:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "76"
      ],
      "favorite_count" : "2",
      "id_str" : "1846193763091468502",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1846193763091468502",
      "created_at" : "Tue Oct 15 14:17:48 +0000 2024",
      "favorited" : false,
      "full_text" : "自分の周りの人間はいい人達ばかりだと思うのは、その人達が本当にいい人達だからなのか、それとも、自分にその人達の本性を見抜く能力が欠落しているからなのか。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1846168837924048997"
          ],
          "editableUntil" : "2024-10-15T13:38:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "id_str" : "1846168837924048997",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1846168837924048997",
      "created_at" : "Tue Oct 15 12:38:45 +0000 2024",
      "favorited" : false,
      "full_text" : "ひえぇ…B棟は\"クソデカG\"のすみかっぽい…！自分の椅子の真下を通っていった…！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1846001430756512040"
          ],
          "editableUntil" : "2024-10-15T02:33:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "0",
      "id_str" : "1846001430756512040",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1846001430756512040",
      "created_at" : "Tue Oct 15 01:33:32 +0000 2024",
      "favorited" : false,
      "full_text" : "青空謁見界隈は日差し強すぎて引退しました",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1845968734810526165"
          ],
          "editableUntil" : "2024-10-15T00:23:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "0",
      "id_str" : "1845968734810526165",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1845968734810526165",
      "created_at" : "Mon Oct 14 23:23:37 +0000 2024",
      "favorited" : false,
      "full_text" : "今日は綱引きやるためじゃなくて、講演も終わったそのあとに基礎プロレポートやるために大学に行きます",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1845400486360515048"
          ],
          "editableUntil" : "2024-10-13T10:45:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "ウィンブレゲーム化",
            "indices" : [
              "12",
              "22"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ウィンヒロ『WIND BREAKER 不良たちの英雄譚』公式",
            "screen_name" : "winhero_PR",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "1830452972817612800",
            "id" : "1830452972817612800"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1845352303949381666",
      "id_str" : "1845400486360515048",
      "in_reply_to_user_id" : "1830452972817612800",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1845400486360515048",
      "in_reply_to_status_id" : "1845352303949381666",
      "created_at" : "Sun Oct 13 09:45:36 +0000 2024",
      "favorited" : false,
      "full_text" : "@winhero_PR #ウィンブレゲーム化",
      "lang" : "qme",
      "in_reply_to_screen_name" : "winhero_PR",
      "in_reply_to_user_id_str" : "1830452972817612800"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1845084659664945406"
          ],
          "editableUntil" : "2024-10-12T13:50:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "32"
      ],
      "favorite_count" : "2",
      "id_str" : "1845084659664945406",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1845084659664945406",
      "created_at" : "Sat Oct 12 12:50:37 +0000 2024",
      "favorited" : false,
      "full_text" : "やっぱなんか新宿っておもろんだよな…ごちゃごちゃ汚え都会って感じ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1844267753617883541"
          ],
          "editableUntil" : "2024-10-10T07:44:31.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "32"
      ],
      "favorite_count" : "1",
      "id_str" : "1844267753617883541",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1844267753617883541",
      "created_at" : "Thu Oct 10 06:44:31 +0000 2024",
      "favorited" : false,
      "full_text" : "今日の講評待ち世界一うるさかった自信ある。異論は絶対に認めない。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1844196062682284419"
          ],
          "editableUntil" : "2024-10-10T02:59:39.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "36"
      ],
      "favorite_count" : "2",
      "id_str" : "1844196062682284419",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1844196062682284419",
      "created_at" : "Thu Oct 10 01:59:39 +0000 2024",
      "favorited" : false,
      "full_text" : "キャリアデザイン履修希望なんてしてないのに落ちたメール来たのなんでだ…？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1843067932743782848"
          ],
          "editableUntil" : "2024-10-07T00:16:52.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "5",
      "id_str" : "1843067932743782848",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1843067932743782848",
      "created_at" : "Sun Oct 06 23:16:52 +0000 2024",
      "favorited" : false,
      "full_text" : "埼京線って人殺したことありそう。\n今日は特にやばかった。息できなくなるかとおもた",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1842226325345669303"
          ],
          "editableUntil" : "2024-10-04T16:32:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "K4FeCN6",
            "screen_name" : "k4_fe_cn6_uec24",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "1775512826460954624",
            "id" : "1775512826460954624"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1842222000292696101",
      "id_str" : "1842226325345669303",
      "in_reply_to_user_id" : "1775512826460954624",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1842226325345669303",
      "in_reply_to_status_id" : "1842222000292696101",
      "created_at" : "Fri Oct 04 15:32:37 +0000 2024",
      "favorited" : false,
      "full_text" : "@k4_fe_cn6_uec24 盗塁ないんかいw\nそんならそのおすすめ戦法使ってみます！",
      "lang" : "ja",
      "in_reply_to_screen_name" : "k4_fe_cn6_uec24",
      "in_reply_to_user_id_str" : "1775512826460954624"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1842218156653469959"
          ],
          "editableUntil" : "2024-10-04T16:00:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "15"
      ],
      "favorite_count" : "1",
      "id_str" : "1842218156653469959",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1842218156653469959",
      "created_at" : "Fri Oct 04 15:00:09 +0000 2024",
      "favorited" : false,
      "full_text" : "エナドリ飲むとハイになっちゃう",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1842218041310077235"
          ],
          "editableUntil" : "2024-10-04T15:59:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "56"
      ],
      "favorite_count" : "0",
      "id_str" : "1842218041310077235",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1842218041310077235",
      "created_at" : "Fri Oct 04 14:59:42 +0000 2024",
      "favorited" : false,
      "full_text" : "アタシは足の速さならギリ男子とも戦えるし、ソフトボールの授業で盗塁王を目指すぜ！\n\n盗塁のルールよく分からんけど",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1841843327144231357"
          ],
          "editableUntil" : "2024-10-03T15:10:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "41"
      ],
      "favorite_count" : "0",
      "id_str" : "1841843327144231357",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1841843327144231357",
      "created_at" : "Thu Oct 03 14:10:43 +0000 2024",
      "favorited" : false,
      "full_text" : "あたしのLMSにはページの下の方にノートの提出先あったんだけど、逆になんであるん？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1841608606669799813"
          ],
          "editableUntil" : "2024-10-02T23:38:01.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "13"
      ],
      "favorite_count" : "0",
      "id_str" : "1841608606669799813",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1841608606669799813",
      "created_at" : "Wed Oct 02 22:38:01 +0000 2024",
      "favorited" : false,
      "full_text" : "こ、これが絶起だとっ…！？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1841103671708565926"
          ],
          "editableUntil" : "2024-10-01T14:11:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "0",
      "id_str" : "1841103671708565926",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1841103671708565926",
      "created_at" : "Tue Oct 01 13:11:36 +0000 2024",
      "favorited" : false,
      "full_text" : "久々に会う人たちとめっちゃダベれて楽しかったです",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1840671639312458139"
          ],
          "editableUntil" : "2024-09-30T09:34:51.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "0",
      "id_str" : "1840671639312458139",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1840671639312458139",
      "created_at" : "Mon Sep 30 08:34:51 +0000 2024",
      "favorited" : false,
      "full_text" : "夏休みでわかったことは、私はスーパーポンコツ変人だということです。短期間でヘマをしすぎ()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1838231286672220284"
          ],
          "editableUntil" : "2024-09-23T15:57:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "97"
      ],
      "favorite_count" : "0",
      "id_str" : "1838231286672220284",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1838231286672220284",
      "created_at" : "Mon Sep 23 14:57:46 +0000 2024",
      "favorited" : false,
      "full_text" : "ボス「これ倒さないでね？」\n私「ハイッ！！！」\n＿人人人人人人人人＿\n＞　ﾄﾞﾝｶﾞﾗｶﾞｯｼｬｰﾝ　＜\n￣Y^Y^Y^Y^Y^Y^Y￣\nボス「…ﾁｯ」\n私「」\n\nそう、私はフラグ回収マスター。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1837030220358111274"
          ],
          "editableUntil" : "2024-09-20T08:25:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "3",
      "id_str" : "1837030220358111274",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1837030220358111274",
      "created_at" : "Fri Sep 20 07:25:09 +0000 2024",
      "favorited" : false,
      "full_text" : "やっと葬送のフリーレン見終わった。見始めるまでが一番めんどくさいね。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1833810953491911072"
          ],
          "editableUntil" : "2024-09-11T11:12:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "11"
      ],
      "favorite_count" : "0",
      "id_str" : "1833810953491911072",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1833810953491911072",
      "created_at" : "Wed Sep 11 10:12:56 +0000 2024",
      "favorited" : false,
      "full_text" : "間合いに入れなかった。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1833306017356255452"
          ],
          "editableUntil" : "2024-09-10T01:46:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "0",
      "id_str" : "1833306017356255452",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1833306017356255452",
      "created_at" : "Tue Sep 10 00:46:30 +0000 2024",
      "favorited" : false,
      "full_text" : "あぶねえ中和滴定の予習するとこだった！やらないって気づけてよかった！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1832343075630542916"
          ],
          "editableUntil" : "2024-09-07T10:00:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1832343075630542916/photo/1",
            "indices" : [
              "42",
              "65"
            ],
            "url" : "https://t.co/Il4rWkgmNy",
            "media_url" : "http://pbs.twimg.com/media/GW3KURkXYAAX61f.jpg",
            "id_str" : "1832343073071783936",
            "id" : "1832343073071783936",
            "media_url_https" : "https://pbs.twimg.com/media/GW3KURkXYAAX61f.jpg",
            "sizes" : {
              "large" : {
                "w" : "922",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "306",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "540",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/Il4rWkgmNy"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "1",
      "id_str" : "1832343075630542916",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1832343075630542916",
      "possibly_sensitive" : false,
      "created_at" : "Sat Sep 07 09:00:07 +0000 2024",
      "favorited" : false,
      "full_text" : "万年たつじん+1だった人が一日ででんせつまで駆け上れた！ビッグビッグランすごすぎ！ https://t.co/Il4rWkgmNy",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1832343075630542916/photo/1",
            "indices" : [
              "42",
              "65"
            ],
            "url" : "https://t.co/Il4rWkgmNy",
            "media_url" : "http://pbs.twimg.com/media/GW3KURkXYAAX61f.jpg",
            "id_str" : "1832343073071783936",
            "id" : "1832343073071783936",
            "media_url_https" : "https://pbs.twimg.com/media/GW3KURkXYAAX61f.jpg",
            "sizes" : {
              "large" : {
                "w" : "922",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "306",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "540",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/Il4rWkgmNy"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1831103272561868890"
          ],
          "editableUntil" : "2024-09-03T23:53:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1831103272561868890/photo/1",
            "indices" : [
              "12",
              "35"
            ],
            "url" : "https://t.co/MUhUt5CnIv",
            "media_url" : "http://pbs.twimg.com/media/GWliuDmbkAA4IXP.jpg",
            "id_str" : "1831103266882818048",
            "id" : "1831103266882818048",
            "media_url_https" : "https://pbs.twimg.com/media/GWliuDmbkAA4IXP.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1079",
                "h" : "970",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1079",
                "h" : "970",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "611",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/MUhUt5CnIv"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "0",
      "id_str" : "1831103272561868890",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1831103272561868890",
      "possibly_sensitive" : false,
      "created_at" : "Tue Sep 03 22:53:35 +0000 2024",
      "favorited" : false,
      "full_text" : "これアウトじゃね？？？ https://t.co/MUhUt5CnIv",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1831103272561868890/photo/1",
            "indices" : [
              "12",
              "35"
            ],
            "url" : "https://t.co/MUhUt5CnIv",
            "media_url" : "http://pbs.twimg.com/media/GWliuDmbkAA4IXP.jpg",
            "id_str" : "1831103266882818048",
            "id" : "1831103266882818048",
            "media_url_https" : "https://pbs.twimg.com/media/GWliuDmbkAA4IXP.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1079",
                "h" : "970",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1079",
                "h" : "970",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "611",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/MUhUt5CnIv"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1830820571560771687"
          ],
          "editableUntil" : "2024-09-03T05:10:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "1",
      "id_str" : "1830820571560771687",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1830820571560771687",
      "created_at" : "Tue Sep 03 04:10:13 +0000 2024",
      "favorited" : false,
      "full_text" : "うわああああせっかく仙台駅まで行ってポケモンスタンプもらったのにプレゼント引き換え忘れた😭",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1830795901738328502"
          ],
          "editableUntil" : "2024-09-03T03:32:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1830793881442766942",
      "id_str" : "1830795901738328502",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1830795901738328502",
      "in_reply_to_status_id" : "1830793881442766942",
      "created_at" : "Tue Sep 03 02:32:12 +0000 2024",
      "favorited" : false,
      "full_text" : "裏を返すと、実験とか、数学とか、理科とかで秀取ってるツイートによって私はダメージを受け続けてるってことだ！",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1830793881442766942"
          ],
          "editableUntil" : "2024-09-03T03:24:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "3",
      "id_str" : "1830793881442766942",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1830793881442766942",
      "created_at" : "Tue Sep 03 02:24:10 +0000 2024",
      "favorited" : false,
      "full_text" : "多分おそらくmaybeきっと実験とか、数学とか、理科とかよりは言ってもダメージ少ないと思うので、言わせていただくと健康論秀",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1830245841833222323"
          ],
          "editableUntil" : "2024-09-01T15:06:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "id_str" : "1830245841833222323",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1830245841833222323",
      "created_at" : "Sun Sep 01 14:06:27 +0000 2024",
      "favorited" : false,
      "full_text" : "危ねえ！超絶謎？の臨時列車がなければ徒歩で9時間コースになるとこだった…！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1830018577610822072"
          ],
          "editableUntil" : "2024-09-01T00:03:23.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "2",
      "id_str" : "1830018577610822072",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1830018577610822072",
      "created_at" : "Sat Aug 31 23:03:23 +0000 2024",
      "favorited" : false,
      "full_text" : "京王の各駅に乗る時は集中して乗らないと乗り過ごす(2敗目)",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1829895290687819917"
          ],
          "editableUntil" : "2024-08-31T15:53:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/RfOdpknK1b",
            "expanded_url" : "https://shichibee.github.io/Fishing_Game.html",
            "display_url" : "shichibee.github.io/Fishing_Game.h…",
            "indices" : [
              "68",
              "91"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1829895290687819917/video/1",
            "indices" : [
              "92",
              "115"
            ],
            "url" : "https://t.co/99sf915tzX",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1829895139273453568/pu/img/Pwhn3Bca4uO3CCpA.jpg",
            "id_str" : "1829895139273453568",
            "id" : "1829895139273453568",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1829895139273453568/pu/img/Pwhn3Bca4uO3CCpA.jpg",
            "sizes" : {
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/99sf915tzX"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "115"
      ],
      "favorite_count" : "0",
      "id_str" : "1829895290687819917",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1829895290687819917",
      "possibly_sensitive" : false,
      "created_at" : "Sat Aug 31 14:53:29 +0000 2024",
      "favorited" : false,
      "full_text" : "グループ制作〆まであと一週間なのに個人制作してる場合じゃなかった()\n(PC向けなのでスマホで開くとレイアウト崩れます。音も出ます。)\nhttps://t.co/RfOdpknK1b https://t.co/99sf915tzX",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1829895290687819917/video/1",
            "indices" : [
              "92",
              "115"
            ],
            "url" : "https://t.co/99sf915tzX",
            "media_url" : "http://pbs.twimg.com/ext_tw_video_thumb/1829895139273453568/pu/img/Pwhn3Bca4uO3CCpA.jpg",
            "id_str" : "1829895139273453568",
            "video_info" : {
              "aspect_ratio" : [
                "16",
                "9"
              ],
              "duration_millis" : "39200",
              "variants" : [
                {
                  "bitrate" : "2176000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1829895139273453568/pu/vid/avc1/1280x720/4JcshyrJdhWWgzEn.mp4?tag=12"
                },
                {
                  "content_type" : "application/x-mpegURL",
                  "url" : "https://video.twimg.com/ext_tw_video/1829895139273453568/pu/pl/jiSn2RfDTy_isbiF.m3u8?tag=12"
                },
                {
                  "bitrate" : "832000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1829895139273453568/pu/vid/avc1/640x360/yGHNzAb3YQ_zp57X.mp4?tag=12"
                },
                {
                  "bitrate" : "256000",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/ext_tw_video/1829895139273453568/pu/vid/avc1/480x270/HtPUB6jzYE1qSjLn.mp4?tag=12"
                }
              ]
            },
            "additional_media_info" : {
              "monetizable" : false
            },
            "id" : "1829895139273453568",
            "media_url_https" : "https://pbs.twimg.com/ext_tw_video_thumb/1829895139273453568/pu/img/Pwhn3Bca4uO3CCpA.jpg",
            "sizes" : {
              "large" : {
                "w" : "1280",
                "h" : "720",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              }
            },
            "type" : "video",
            "display_url" : "pic.x.com/99sf915tzX"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1829135019417509977"
          ],
          "editableUntil" : "2024-08-29T13:32:26.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "60"
      ],
      "favorite_count" : "0",
      "id_str" : "1829135019417509977",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1829135019417509977",
      "created_at" : "Thu Aug 29 12:32:26 +0000 2024",
      "favorited" : false,
      "full_text" : "弟に話しかけられたと思ってから返したら、通話中でバリバリ声はいっちゃった()\n最近漫画にでてくるウザい姉ムーブが加速中…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1828405015096238472"
          ],
          "editableUntil" : "2024-08-27T13:11:40.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "63"
      ],
      "favorite_count" : "0",
      "id_str" : "1828405015096238472",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1828405015096238472",
      "created_at" : "Tue Aug 27 12:11:40 +0000 2024",
      "favorited" : false,
      "full_text" : "ジバニャンが未来でロボニャンになるみたいなことをポケモンでもやってたの？！やっぱスピンオフばっかりやってると知識が足りないな…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1827700183083499856"
          ],
          "editableUntil" : "2024-08-25T14:30:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1827699842438820050",
      "id_str" : "1827700183083499856",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1827700183083499856",
      "in_reply_to_status_id" : "1827699842438820050",
      "created_at" : "Sun Aug 25 13:30:55 +0000 2024",
      "favorited" : false,
      "full_text" : "あーあスクショファイルが照れ顔だらけだよ",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1827699842438820050"
          ],
          "editableUntil" : "2024-08-25T14:29:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "0",
      "id_str" : "1827699842438820050",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1827699842438820050",
      "created_at" : "Sun Aug 25 13:29:34 +0000 2024",
      "favorited" : false,
      "full_text" : "ハーレムもの嫌いだったはずなのに魔都精兵のスレイブが素晴らしいと思ってしまった自分が嫌いになりそう",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1827608042256703599"
          ],
          "editableUntil" : "2024-08-25T08:24:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "36"
      ],
      "favorite_count" : "0",
      "id_str" : "1827608042256703599",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1827608042256703599",
      "created_at" : "Sun Aug 25 07:24:47 +0000 2024",
      "favorited" : false,
      "full_text" : "今日のバイトクソ楽でクソ早く上がれたかつ給料は同じって最高なのか？？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1827351880168829182"
          ],
          "editableUntil" : "2024-08-24T15:26:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "0",
      "id_str" : "1827351880168829182",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1827351880168829182",
      "created_at" : "Sat Aug 24 14:26:53 +0000 2024",
      "favorited" : false,
      "full_text" : "もしや東大の特集番組に中学で同じ塾通ってたやついる…！？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1826930389040181738"
          ],
          "editableUntil" : "2024-08-23T11:32:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "0",
      "id_str" : "1826930389040181738",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1826930389040181738",
      "created_at" : "Fri Aug 23 10:32:02 +0000 2024",
      "favorited" : false,
      "full_text" : "やっぱ周りの人に恵まれてるかも。運いいのかもしれない。\nだってこの調子でいけば宝くじで七億円当たる気がするもん",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1825995395337728266"
          ],
          "editableUntil" : "2024-08-20T21:36:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "1",
      "id_str" : "1825995395337728266",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1825995395337728266",
      "created_at" : "Tue Aug 20 20:36:42 +0000 2024",
      "favorited" : false,
      "full_text" : "やべ今日満月なのに寝るの忘れた。カビゴンごめん…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1824989021602451716"
          ],
          "editableUntil" : "2024-08-18T02:57:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1824987976373506211",
      "id_str" : "1824989021602451716",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1824989021602451716",
      "in_reply_to_status_id" : "1824987976373506211",
      "created_at" : "Sun Aug 18 01:57:44 +0000 2024",
      "favorited" : false,
      "full_text" : "こういうの読書メーターに書くやつじゃね？\nやったことないけど",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1824987976373506211"
          ],
          "editableUntil" : "2024-08-18T02:53:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "103"
      ],
      "favorite_count" : "0",
      "id_str" : "1824987976373506211",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1824987976373506211",
      "created_at" : "Sun Aug 18 01:53:34 +0000 2024",
      "favorited" : false,
      "full_text" : "「気になってる人が男じゃなかった」って漫画の単行本めちゃ高いけどめちゃ良かった。\n小学生の時の自分と同じ選択をした小学生の時の古賀さんには(そんなに良い結果とならなかったのに)なぜか救われた気持ちになった。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1824646685970272580"
          ],
          "editableUntil" : "2024-08-17T04:17:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "14"
      ],
      "favorite_count" : "3",
      "id_str" : "1824646685970272580",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1824646685970272580",
      "created_at" : "Sat Aug 17 03:17:24 +0000 2024",
      "favorited" : false,
      "full_text" : "人生初バイト面接落ちた！！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1824442973930786871"
          ],
          "editableUntil" : "2024-08-16T14:47:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "88"
      ],
      "favorite_count" : "3",
      "id_str" : "1824442973930786871",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1824442973930786871",
      "created_at" : "Fri Aug 16 13:47:56 +0000 2024",
      "favorited" : false,
      "full_text" : "ハッピーセットのおもちゃを断れるのにもらって「いらねw」ってなるの絶対やめたほうがいい悪習慣だな。今日もモンスターボール型コンパスもらっちゃったし。恵方巻き食うときしか使わんて",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1824427284310405240"
          ],
          "editableUntil" : "2024-08-16T13:45:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "0",
      "id_str" : "1824427284310405240",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1824427284310405240",
      "created_at" : "Fri Aug 16 12:45:35 +0000 2024",
      "favorited" : false,
      "full_text" : "今日はテクノロジーの進歩に貢献し、ボドゲをし、しゃぶしゃぶを奢ってもらうという充実しすぎている1日だった…！最高か？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1824089148447482143"
          ],
          "editableUntil" : "2024-08-15T15:21:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "0",
      "id_str" : "1824089148447482143",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1824089148447482143",
      "created_at" : "Thu Aug 15 14:21:57 +0000 2024",
      "favorited" : false,
      "full_text" : "インスタ開いたら大鬱になった。\n小中の友達(？)にBBQ誘われたい人生でした。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1822800609348886860"
          ],
          "editableUntil" : "2024-08-12T02:01:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1822800609348886860/photo/1",
            "indices" : [
              "17",
              "40"
            ],
            "url" : "https://t.co/d7IbpVAONR",
            "media_url" : "http://pbs.twimg.com/media/GUvjfdgaoAAw4NP.jpg",
            "id_str" : "1822800603837538304",
            "id" : "1822800603837538304",
            "media_url_https" : "https://pbs.twimg.com/media/GUvjfdgaoAAw4NP.jpg",
            "sizes" : {
              "small" : {
                "w" : "306",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "540",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "922",
                "h" : "2048",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/d7IbpVAONR"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1822797255294038513",
      "id_str" : "1822800609348886860",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1822800609348886860",
      "in_reply_to_status_id" : "1822797255294038513",
      "possibly_sensitive" : false,
      "created_at" : "Mon Aug 12 01:01:45 +0000 2024",
      "favorited" : false,
      "full_text" : "最近のやつだけ反映させてる感じね https://t.co/d7IbpVAONR",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1822800609348886860/photo/1",
            "indices" : [
              "17",
              "40"
            ],
            "url" : "https://t.co/d7IbpVAONR",
            "media_url" : "http://pbs.twimg.com/media/GUvjfdgaoAAw4NP.jpg",
            "id_str" : "1822800603837538304",
            "id" : "1822800603837538304",
            "media_url_https" : "https://pbs.twimg.com/media/GUvjfdgaoAAw4NP.jpg",
            "sizes" : {
              "small" : {
                "w" : "306",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "540",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "922",
                "h" : "2048",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/d7IbpVAONR"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1822797255294038513"
          ],
          "editableUntil" : "2024-08-12T01:48:26.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1822797255294038513/photo/1",
            "indices" : [
              "148",
              "171"
            ],
            "url" : "https://t.co/fqQnl47SIx",
            "media_url" : "http://pbs.twimg.com/media/GUvgcZJbAAAa_qw.jpg",
            "id_str" : "1822797252592861184",
            "id" : "1822797252592861184",
            "media_url_https" : "https://pbs.twimg.com/media/GUvgcZJbAAAa_qw.jpg",
            "sizes" : {
              "medium" : {
                "w" : "796",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1080",
                "h" : "1629",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "451",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/fqQnl47SIx"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "171"
      ],
      "favorite_count" : "0",
      "id_str" : "1822797255294038513",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1822797255294038513",
      "possibly_sensitive" : false,
      "created_at" : "Mon Aug 12 00:48:26 +0000 2024",
      "favorited" : false,
      "full_text" : "Roastで、男と疑われていると聞きました。\nこの際だからはっきりと言わせてもらいますが、女です。\n信頼しているフォロワーさん数名には写真を見せたこともあるかもしれません\nそう簡単には信じてもらえないことは分かっています。\nTwitterを趣味にしている以上、仕方のないことだと思っていますが。 https://t.co/fqQnl47SIx",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1822797255294038513/photo/1",
            "indices" : [
              "148",
              "171"
            ],
            "url" : "https://t.co/fqQnl47SIx",
            "media_url" : "http://pbs.twimg.com/media/GUvgcZJbAAAa_qw.jpg",
            "id_str" : "1822797252592861184",
            "id" : "1822797252592861184",
            "media_url_https" : "https://pbs.twimg.com/media/GUvgcZJbAAAa_qw.jpg",
            "sizes" : {
              "medium" : {
                "w" : "796",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1080",
                "h" : "1629",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "451",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/fqQnl47SIx"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1822621026372776414"
          ],
          "editableUntil" : "2024-08-11T14:08:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "1",
      "id_str" : "1822621026372776414",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1822621026372776414",
      "created_at" : "Sun Aug 11 13:08:10 +0000 2024",
      "favorited" : false,
      "full_text" : "Twitterに張り付いてる自分が嫌いだ。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1821869796553846832"
          ],
          "editableUntil" : "2024-08-09T12:23:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1821869796553846832/photo/1",
            "indices" : [
              "39",
              "62"
            ],
            "url" : "https://t.co/OX47GkcwkV",
            "media_url" : "http://pbs.twimg.com/media/GUiU68nbQAAbXvC.jpg",
            "id_str" : "1821869789696180224",
            "id" : "1821869789696180224",
            "media_url_https" : "https://pbs.twimg.com/media/GUiU68nbQAAbXvC.jpg",
            "sizes" : {
              "large" : {
                "w" : "1620",
                "h" : "1080",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "453",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "800",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/OX47GkcwkV"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "62"
      ],
      "favorite_count" : "1",
      "id_str" : "1821869796553846832",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1821869796553846832",
      "possibly_sensitive" : false,
      "created_at" : "Fri Aug 09 11:23:02 +0000 2024",
      "favorited" : false,
      "full_text" : "旅行中毎日ベストショットあげようと思ってたのに2日目でこれになっちゃった() https://t.co/OX47GkcwkV",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1821869796553846832/photo/1",
            "indices" : [
              "39",
              "62"
            ],
            "url" : "https://t.co/OX47GkcwkV",
            "media_url" : "http://pbs.twimg.com/media/GUiU68nbQAAbXvC.jpg",
            "id_str" : "1821869789696180224",
            "id" : "1821869789696180224",
            "media_url_https" : "https://pbs.twimg.com/media/GUiU68nbQAAbXvC.jpg",
            "sizes" : {
              "large" : {
                "w" : "1620",
                "h" : "1080",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "453",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "800",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/OX47GkcwkV"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1821519852298981427"
          ],
          "editableUntil" : "2024-08-08T13:12:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1821519852298981427/photo/1",
            "indices" : [
              "11",
              "34"
            ],
            "url" : "https://t.co/3nPhMAal4S",
            "media_url" : "http://pbs.twimg.com/media/GUdWpxsa8AEQn_E.jpg",
            "id_str" : "1821519850008932353",
            "id" : "1821519850008932353",
            "media_url_https" : "https://pbs.twimg.com/media/GUdWpxsa8AEQn_E.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "453",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1620",
                "h" : "1080",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "800",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/3nPhMAal4S"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "12",
      "id_str" : "1821519852298981427",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1821519852298981427",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 08 12:12:29 +0000 2024",
      "favorited" : false,
      "full_text" : "今日のベストショット https://t.co/3nPhMAal4S",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1821519852298981427/photo/1",
            "indices" : [
              "11",
              "34"
            ],
            "url" : "https://t.co/3nPhMAal4S",
            "media_url" : "http://pbs.twimg.com/media/GUdWpxsa8AEQn_E.jpg",
            "id_str" : "1821519850008932353",
            "id" : "1821519850008932353",
            "media_url_https" : "https://pbs.twimg.com/media/GUdWpxsa8AEQn_E.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "453",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1620",
                "h" : "1080",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "800",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/3nPhMAal4S"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1820466215879676089"
          ],
          "editableUntil" : "2024-08-05T15:25:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "0",
      "id_str" : "1820466215879676089",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1820466215879676089",
      "created_at" : "Mon Aug 05 14:25:43 +0000 2024",
      "favorited" : false,
      "full_text" : "乗り換えまで失敗した…！悪いことは重なる…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1820459226176917748"
          ],
          "editableUntil" : "2024-08-05T14:57:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "63"
      ],
      "favorite_count" : "5",
      "id_str" : "1820459226176917748",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1820459226176917748",
      "created_at" : "Mon Aug 05 13:57:56 +0000 2024",
      "favorited" : false,
      "full_text" : "カラオケしてテンション最高潮で帰ってたら若いねーちゃんがゲロ吐いたやつが靴にかかった…テストは家に帰るまでとはこのことか…！？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1820448152958476300"
          ],
          "editableUntil" : "2024-08-05T14:13:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "2",
      "id_str" : "1820448152958476300",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1820448152958476300",
      "created_at" : "Mon Aug 05 13:13:56 +0000 2024",
      "favorited" : false,
      "full_text" : "ヒトカラ楽しすぎたけど、地元のカラオケ屋じゃまず出さない低得点出たのはなぜ？？？東京って厳しい…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1820016908881780794"
          ],
          "editableUntil" : "2024-08-04T09:40:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1820016908881780794/photo/1",
            "indices" : [
              "36",
              "59"
            ],
            "url" : "https://t.co/uUbvcyLW7M",
            "media_url" : "http://pbs.twimg.com/media/GUH_tzOasAANVYG.jpg",
            "id_str" : "1820016886744264704",
            "id" : "1820016886744264704",
            "media_url_https" : "https://pbs.twimg.com/media/GUH_tzOasAANVYG.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "505",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1078",
                "h" : "800",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1078",
                "h" : "800",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/uUbvcyLW7M"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "59"
      ],
      "favorite_count" : "1",
      "id_str" : "1820016908881780794",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1820016908881780794",
      "possibly_sensitive" : false,
      "created_at" : "Sun Aug 04 08:40:20 +0000 2024",
      "favorited" : false,
      "full_text" : "ぼっち・ざ・ろっく！が今日限定で全話無料公開だったので明日のテストこれ https://t.co/uUbvcyLW7M",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1820016908881780794/photo/1",
            "indices" : [
              "36",
              "59"
            ],
            "url" : "https://t.co/uUbvcyLW7M",
            "media_url" : "http://pbs.twimg.com/media/GUH_tzOasAANVYG.jpg",
            "id_str" : "1820016886744264704",
            "id" : "1820016886744264704",
            "media_url_https" : "https://pbs.twimg.com/media/GUH_tzOasAANVYG.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "505",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1078",
                "h" : "800",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1078",
                "h" : "800",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/uUbvcyLW7M"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1819717413887484025"
          ],
          "editableUntil" : "2024-08-03T13:50:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "63"
      ],
      "favorite_count" : "1",
      "id_str" : "1819717413887484025",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1819717413887484025",
      "created_at" : "Sat Aug 03 12:50:14 +0000 2024",
      "favorited" : false,
      "full_text" : "母(卓球未経験)＆弟(卓球経験者)＆私(卓球経験者)\n「「「ジュースだ！ジュースに持ち込め！！ジュース🥤ジュース🧃！！！」」」",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1817052651881652391"
          ],
          "editableUntil" : "2024-07-27T05:21:26.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "0",
      "id_str" : "1817052651881652391",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1817052651881652391",
      "created_at" : "Sat Jul 27 04:21:26 +0000 2024",
      "favorited" : false,
      "full_text" : "マックのポテトMがきつい…やっぱSしか勝たん…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1816482837283164629"
          ],
          "editableUntil" : "2024-07-25T15:37:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "0",
      "id_str" : "1816482837283164629",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1816482837283164629",
      "created_at" : "Thu Jul 25 14:37:11 +0000 2024",
      "favorited" : false,
      "full_text" : "まって、2weekのコンタクトが3week目になってたの今気づいた！あと2日で4week目だ！！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1816370772547625067"
          ],
          "editableUntil" : "2024-07-25T08:11:53.369Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "チーズベーコンポテトパイ",
            "indices" : [
              "35",
              "48"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "マクドナルド",
            "screen_name" : "McDonaldsJapan",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "184004752",
            "id" : "184004752"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1816370772547625067",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1816370772547625067",
      "created_at" : "Thu Jul 25 07:11:53 +0000 2024",
      "favorited" : false,
      "full_text" : "RT @McDonaldsJapan: あのパイに、チーズが入った！\n#チーズベーコンポテトパイ 7/31(水)新登場\n\nこの投稿を本日7/25(木)中にリポストすると、抽選で50名様に1,000円分のマックカードが当たる！\n\nキャンペーン詳細はこちら\nhttps://t.co…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1816296625293386049"
          ],
          "editableUntil" : "2024-07-25T03:17:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "69"
      ],
      "favorite_count" : "5",
      "id_str" : "1816296625293386049",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1816296625293386049",
      "created_at" : "Thu Jul 25 02:17:15 +0000 2024",
      "favorited" : false,
      "full_text" : "高校を卒業してからコンタクトにし、ピアスを開け、メイクをし、ついに髪まで染めたので、無事にイキリ陰キャ&lt;完全体&gt;が爆誕した…！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1814309171866812831"
          ],
          "editableUntil" : "2024-07-19T15:39:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "0",
      "id_str" : "1814309171866812831",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1814309171866812831",
      "created_at" : "Fri Jul 19 14:39:49 +0000 2024",
      "favorited" : false,
      "full_text" : "電車の非常停止ブザーってこんなエッグい音だったの！？耳死ぬ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1813964752001040601"
          ],
          "editableUntil" : "2024-07-18T16:51:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "3",
      "id_str" : "1813964752001040601",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1813964752001040601",
      "created_at" : "Thu Jul 18 15:51:13 +0000 2024",
      "favorited" : false,
      "full_text" : "エデン組が3周年は嘘だね。だってつい最近デビューしたばっかでしょ？新人でしょ？\n\nって思うくらい時の流れこわい",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1812615831614050732"
          ],
          "editableUntil" : "2024-07-14T23:31:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "0",
      "id_str" : "1812615831614050732",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1812615831614050732",
      "created_at" : "Sun Jul 14 22:31:05 +0000 2024",
      "favorited" : false,
      "full_text" : "地元の祭りPM2:00からなのにもうひっかせの練習してるの気合い入りすぎだろ…もはや騒音だって…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1809921651301110011"
          ],
          "editableUntil" : "2024-07-07T13:05:23.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/mgC7Zu9yHr",
            "expanded_url" : "https://shichibee.github.io/Conliteguide/indexippan.html",
            "display_url" : "shichibee.github.io/Conliteguide/i…",
            "indices" : [
              "61",
              "84"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1809921651301110011/photo/1",
            "indices" : [
              "85",
              "108"
            ],
            "url" : "https://t.co/M5PoNe33tS",
            "media_url" : "http://pbs.twimg.com/media/GR4iG1haQAAJ4yl.jpg",
            "id_str" : "1809921601091289088",
            "id" : "1809921601091289088",
            "media_url_https" : "https://pbs.twimg.com/media/GR4iG1haQAAJ4yl.jpg",
            "sizes" : {
              "small" : {
                "w" : "77",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "136",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "233",
                "h" : "2048",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/M5PoNe33tS"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "108"
      ],
      "favorite_count" : "0",
      "id_str" : "1809921651301110011",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1809921651301110011",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jul 07 12:05:23 +0000 2024",
      "favorited" : false,
      "full_text" : "ChatGDPくんとイチャイチャしてたらこんなん作るのに６時間熱中してた() \nバグがどうにもならなかったの悔しい...\nhttps://t.co/mgC7Zu9yHr https://t.co/M5PoNe33tS",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1809921651301110011/photo/1",
            "indices" : [
              "85",
              "108"
            ],
            "url" : "https://t.co/M5PoNe33tS",
            "media_url" : "http://pbs.twimg.com/media/GR4iG1haQAAJ4yl.jpg",
            "id_str" : "1809921601091289088",
            "id" : "1809921601091289088",
            "media_url_https" : "https://pbs.twimg.com/media/GR4iG1haQAAJ4yl.jpg",
            "sizes" : {
              "small" : {
                "w" : "77",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "136",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "233",
                "h" : "2048",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/M5PoNe33tS"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1809564382747410565"
          ],
          "editableUntil" : "2024-07-06T13:25:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1809564188932730941",
      "id_str" : "1809564382747410565",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1809564382747410565",
      "in_reply_to_status_id" : "1809564188932730941",
      "created_at" : "Sat Jul 06 12:25:43 +0000 2024",
      "favorited" : false,
      "full_text" : "今気づいたけどけんけつちゃんがモザイク貫通してた",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1809564188932730941"
          ],
          "editableUntil" : "2024-07-06T13:24:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1809564188932730941/photo/1",
            "indices" : [
              "28",
              "51"
            ],
            "url" : "https://t.co/VjegWSUguM",
            "media_url" : "http://pbs.twimg.com/media/GRzdCiRbUAAq_za.jpg",
            "id_str" : "1809564185925472256",
            "id" : "1809564185925472256",
            "media_url_https" : "https://pbs.twimg.com/media/GRzdCiRbUAAq_za.jpg",
            "sizes" : {
              "large" : {
                "w" : "1073",
                "h" : "1411",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "913",
                "h" : "1200",
                "resize" : "fit"
              },
              "small" : {
                "w" : "517",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/VjegWSUguM"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "1",
      "id_str" : "1809564188932730941",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1809564188932730941",
      "possibly_sensitive" : false,
      "created_at" : "Sat Jul 06 12:24:57 +0000 2024",
      "favorited" : false,
      "full_text" : "Uフレットとコンリテのスクショ色合い似てて間違えちゃう https://t.co/VjegWSUguM",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1809564188932730941/photo/1",
            "indices" : [
              "28",
              "51"
            ],
            "url" : "https://t.co/VjegWSUguM",
            "media_url" : "http://pbs.twimg.com/media/GRzdCiRbUAAq_za.jpg",
            "id_str" : "1809564185925472256",
            "id" : "1809564185925472256",
            "media_url_https" : "https://pbs.twimg.com/media/GRzdCiRbUAAq_za.jpg",
            "sizes" : {
              "large" : {
                "w" : "1073",
                "h" : "1411",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "913",
                "h" : "1200",
                "resize" : "fit"
              },
              "small" : {
                "w" : "517",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/VjegWSUguM"
          },
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1809564188932730941/photo/1",
            "indices" : [
              "28",
              "51"
            ],
            "url" : "https://t.co/VjegWSUguM",
            "media_url" : "http://pbs.twimg.com/media/GRzdCibagAAEIIn.jpg",
            "id_str" : "1809564185967362048",
            "id" : "1809564185967362048",
            "media_url_https" : "https://pbs.twimg.com/media/GRzdCibagAAEIIn.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "531",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1078",
                "h" : "1381",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "937",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/VjegWSUguM"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1809053789426757807"
          ],
          "editableUntil" : "2024-07-05T03:36:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "猫好き",
            "screen_name" : "NewKeep_y",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1765218063530815488",
            "id" : "1765218063530815488"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1809053313239035985",
      "id_str" : "1809053789426757807",
      "in_reply_to_user_id" : "1765218063530815488",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1809053789426757807",
      "in_reply_to_status_id" : "1809053313239035985",
      "created_at" : "Fri Jul 05 02:36:48 +0000 2024",
      "favorited" : false,
      "full_text" : "@NewKeep_y 今日4限からだし、もう着いた！\n心配してくれてありがと！",
      "lang" : "ja",
      "in_reply_to_screen_name" : "NewKeep_y",
      "in_reply_to_user_id_str" : "1765218063530815488"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1809041960759668954"
          ],
          "editableUntil" : "2024-07-05T02:49:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "60"
      ],
      "favorite_count" : "4",
      "id_str" : "1809041960759668954",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1809041960759668954",
      "created_at" : "Fri Jul 05 01:49:48 +0000 2024",
      "favorited" : false,
      "full_text" : "京王線の各停乗っちゃってまあゆっくりできていいかって思ってたらゆっくりしすぎて南大沢にいます。\nどこだよここ！？！？？！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1808171467517092166"
          ],
          "editableUntil" : "2024-07-02T17:10:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "18"
      ],
      "favorite_count" : "4",
      "id_str" : "1808171467517092166",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1808171467517092166",
      "created_at" : "Tue Jul 02 16:10:46 +0000 2024",
      "favorited" : false,
      "full_text" : "びっけん予習ノート全部終わった！！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1808132880406888566"
          ],
          "editableUntil" : "2024-07-02T14:37:26.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "69"
      ],
      "favorite_count" : "3",
      "id_str" : "1808132880406888566",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1808132880406888566",
      "created_at" : "Tue Jul 02 13:37:26 +0000 2024",
      "favorited" : false,
      "full_text" : "イヤカフを洋式トイレの中に落とした！！！\n\n　＿人人人人人人人人人人＿\n　＞　ひ　ろ　っ　た　！＜\n　￣Y^Y^Y^Y^Y^Y^Y^Y^￣",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1806686678591172990"
          ],
          "editableUntil" : "2024-06-28T14:50:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "27"
      ],
      "favorite_count" : "4",
      "id_str" : "1806686678591172990",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1806686678591172990",
      "created_at" : "Fri Jun 28 13:50:45 +0000 2024",
      "favorited" : false,
      "full_text" : "B棟一階のトイレに超絶でっけえGがいるから気をつけてね",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1805957969303192031"
          ],
          "editableUntil" : "2024-06-26T14:35:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "50"
      ],
      "favorite_count" : "0",
      "id_str" : "1805957969303192031",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1805957969303192031",
      "created_at" : "Wed Jun 26 13:35:07 +0000 2024",
      "favorited" : false,
      "full_text" : "今日いた自習スペースは静かでクーラー効いてて人少なくてよかった。\n\n床が髪の毛パーティーしてたけど！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1804479088943612041"
          ],
          "editableUntil" : "2024-06-22T12:38:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1804409985805197498",
      "id_str" : "1804479088943612041",
      "in_reply_to_user_id" : "1117358395969814529",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1804479088943612041",
      "in_reply_to_status_id" : "1804409985805197498",
      "created_at" : "Sat Jun 22 11:38:35 +0000 2024",
      "favorited" : false,
      "full_text" : "@Fullerene_BJE まあ私もニュアンスはなんとなくそんな感じで思ってたから細かいことはまあいっか",
      "lang" : "ja",
      "in_reply_to_user_id_str" : "1117358395969814529"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1804408928794742970"
          ],
          "editableUntil" : "2024-06-22T07:59:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "106"
      ],
      "favorite_count" : "3",
      "id_str" : "1804408928794742970",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1804408928794742970",
      "created_at" : "Sat Jun 22 06:59:47 +0000 2024",
      "favorited" : false,
      "full_text" : "「どね」ってdoneのローマ字読みで何かタスクが終わったことを言ってるのかと思ってたけど、何かを提出（寄付、寄贈、贈与、助成、それともdonation？)したことを言ってたのか？調べるほどわからんくなってきたぞ？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1802705784037671339"
          ],
          "editableUntil" : "2024-06-17T15:12:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "0",
      "id_str" : "1802705784037671339",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1802705784037671339",
      "created_at" : "Mon Jun 17 14:12:06 +0000 2024",
      "favorited" : false,
      "full_text" : "B棟って自動で電気消えちゃうんだね怖かった。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1802251255215251865"
          ],
          "editableUntil" : "2024-06-16T09:05:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "78"
      ],
      "favorite_count" : "0",
      "id_str" : "1802251255215251865",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1802251255215251865",
      "created_at" : "Sun Jun 16 08:05:58 +0000 2024",
      "favorited" : false,
      "full_text" : "バルーンなら銃刀法違反には当たらないだろうと思って100均で買った刀が、素振り開始2分で使い物にならなくなった。買うならやはり本物でないとだめなのであろう。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1801071822714401057"
          ],
          "editableUntil" : "2024-06-13T02:59:19.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1801071530736312800",
      "id_str" : "1801071822714401057",
      "in_reply_to_user_id" : "1117358395969814529",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1801071822714401057",
      "in_reply_to_status_id" : "1801071530736312800",
      "created_at" : "Thu Jun 13 01:59:19 +0000 2024",
      "favorited" : false,
      "full_text" : "@Fullerene_BJE お願いだから忘却してくれぇ…！",
      "lang" : "ja",
      "in_reply_to_user_id_str" : "1117358395969814529"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1801071236308455470"
          ],
          "editableUntil" : "2024-06-13T02:56:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "1",
      "id_str" : "1801071236308455470",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1801071236308455470",
      "created_at" : "Thu Jun 13 01:56:59 +0000 2024",
      "favorited" : false,
      "full_text" : "いいね欄見られなくなったんだ！私個人的にはめちゃ嬉しい！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1800905451871387841"
          ],
          "editableUntil" : "2024-06-12T15:58:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "13"
      ],
      "favorite_count" : "0",
      "id_str" : "1800905451871387841",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1800905451871387841",
      "created_at" : "Wed Jun 12 14:58:13 +0000 2024",
      "favorited" : false,
      "full_text" : "久しぶりのスプラ調子良すぎ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1800847543741587881"
          ],
          "editableUntil" : "2024-06-12T12:08:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "22",
      "id_str" : "1800847543741587881",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1800847543741587881",
      "created_at" : "Wed Jun 12 11:08:07 +0000 2024",
      "favorited" : false,
      "full_text" : "うちの高校は自称進だから国公立大は太字で書くんだけど、東京電機大と間違えて電通大が普通表記になってんのすき",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1800846379692314698"
          ],
          "editableUntil" : "2024-06-12T12:03:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "47"
      ],
      "favorite_count" : "3",
      "id_str" : "1800846379692314698",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1800846379692314698",
      "created_at" : "Wed Jun 12 11:03:29 +0000 2024",
      "favorited" : false,
      "full_text" : "高校から合格体験記届いた！私のデータを探せゲームおもろい。(コツは成績の下の方から数えること)",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1799004119967179095"
          ],
          "editableUntil" : "2024-06-07T10:03:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "マックのアジアンスイーツ",
            "indices" : [
              "16",
              "29"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "マクドナルド",
            "screen_name" : "McDonaldsJapan",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "184004752",
            "id" : "184004752"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1798942967262323193",
      "id_str" : "1799004119967179095",
      "in_reply_to_user_id" : "184004752",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1799004119967179095",
      "in_reply_to_status_id" : "1798942967262323193",
      "created_at" : "Fri Jun 07 09:03:00 +0000 2024",
      "favorited" : false,
      "full_text" : "@McDonaldsJapan #マックのアジアンスイーツ",
      "lang" : "qme",
      "in_reply_to_screen_name" : "McDonaldsJapan",
      "in_reply_to_user_id_str" : "184004752"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1798684142709993488"
          ],
          "editableUntil" : "2024-06-06T12:51:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "45"
      ],
      "favorite_count" : "1",
      "id_str" : "1798684142709993488",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1798684142709993488",
      "created_at" : "Thu Jun 06 11:51:32 +0000 2024",
      "favorited" : false,
      "full_text" : "今の時期はまだ足見せる機会ないと思って爪にジェルネイル塗るの試してたのにもう機会が来た()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1797437310373703763"
          ],
          "editableUntil" : "2024-06-03T02:17:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "3",
      "id_str" : "1797437310373703763",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1797437310373703763",
      "created_at" : "Mon Jun 03 01:17:04 +0000 2024",
      "favorited" : false,
      "full_text" : "中学生の時にscratchで作ったゲームが完成度高いけどストーリーは無理やりすぎて笑ってたwww",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1797139117945581639"
          ],
          "editableUntil" : "2024-06-02T06:32:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "47"
      ],
      "favorite_count" : "1",
      "id_str" : "1797139117945581639",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1797139117945581639",
      "created_at" : "Sun Jun 02 05:32:09 +0000 2024",
      "favorited" : false,
      "full_text" : "今までペロッと飲み干してた天下一品のこってりラーメンが3分の1くらいで気持ち悪くなったの悔しい",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1796194502945763476"
          ],
          "editableUntil" : "2024-05-30T15:58:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1796194502945763476/photo/1",
            "indices" : [
              "35",
              "58"
            ],
            "url" : "https://t.co/Ao4TfuuZcm",
            "media_url" : "http://pbs.twimg.com/media/GO1dRpdXgAEFUnF.jpg",
            "id_str" : "1796194384158883841",
            "id" : "1796194384158883841",
            "media_url_https" : "https://pbs.twimg.com/media/GO1dRpdXgAEFUnF.jpg",
            "sizes" : {
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/Ao4TfuuZcm"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "2",
      "id_str" : "1796194502945763476",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1796194502945763476",
      "possibly_sensitive" : false,
      "created_at" : "Thu May 30 14:58:35 +0000 2024",
      "favorited" : false,
      "full_text" : "作ったはいいけどアコギ弾きだからエレキの周辺機器が全くわからない() https://t.co/Ao4TfuuZcm",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1796194502945763476/photo/1",
            "indices" : [
              "35",
              "58"
            ],
            "url" : "https://t.co/Ao4TfuuZcm",
            "media_url" : "http://pbs.twimg.com/media/GO1dRpdXgAEFUnF.jpg",
            "id_str" : "1796194384158883841",
            "id" : "1796194384158883841",
            "media_url_https" : "https://pbs.twimg.com/media/GO1dRpdXgAEFUnF.jpg",
            "sizes" : {
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/Ao4TfuuZcm"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1935827318838366609"
          ],
          "editableUntil" : "2025-06-19T23:29:33.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "トラマト",
            "screen_name" : "25ToraMutton",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1897201391002902530",
            "id" : "1897201391002902530"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "47"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1935825511437275214",
      "id_str" : "1935827318838366609",
      "in_reply_to_user_id" : "1897201391002902530",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1935827318838366609",
      "in_reply_to_status_id" : "1935825511437275214",
      "created_at" : "Thu Jun 19 22:29:33 +0000 2025",
      "favorited" : false,
      "full_text" : "@25ToraMutton 同じなんですか！？私も初めて見ました！！\nおめでとうございます！！",
      "lang" : "ja",
      "in_reply_to_screen_name" : "25ToraMutton",
      "in_reply_to_user_id_str" : "1897201391002902530"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1935822889779183824"
          ],
          "editableUntil" : "2025-06-19T23:11:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "いな",
            "screen_name" : "ina_uec24",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1771568167615414272",
            "id" : "1771568167615414272"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "16"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1935822657544675664",
      "id_str" : "1935822889779183824",
      "in_reply_to_user_id" : "1771568167615414272",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1935822889779183824",
      "in_reply_to_status_id" : "1935822657544675664",
      "created_at" : "Thu Jun 19 22:11:57 +0000 2025",
      "favorited" : false,
      "full_text" : "@ina_uec24 ありがと〜",
      "lang" : "ja",
      "in_reply_to_screen_name" : "ina_uec24",
      "in_reply_to_user_id_str" : "1771568167615414272"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1935820797362491464"
          ],
          "editableUntil" : "2025-06-19T23:03:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "琥珀",
            "screen_name" : "mezase_kenzenn",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1570697638068252674",
            "id" : "1570697638068252674"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1935770902303773000",
      "id_str" : "1935820797362491464",
      "in_reply_to_user_id" : "1570697638068252674",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1935820797362491464",
      "in_reply_to_status_id" : "1935770902303773000",
      "created_at" : "Thu Jun 19 22:03:38 +0000 2025",
      "favorited" : false,
      "full_text" : "@mezase_kenzenn ありがと！",
      "lang" : "ja",
      "in_reply_to_screen_name" : "mezase_kenzenn",
      "in_reply_to_user_id_str" : "1570697638068252674"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1935820717628834267"
          ],
          "editableUntil" : "2025-06-19T23:03:19.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "🎶👊💥",
            "screen_name" : "runrun_punch",
            "indices" : [
              "0",
              "13"
            ],
            "id_str" : "1925063776459751425",
            "id" : "1925063776459751425"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1935742961620550138",
      "id_str" : "1935820717628834267",
      "in_reply_to_user_id" : "1925063776459751425",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1935820717628834267",
      "in_reply_to_status_id" : "1935742961620550138",
      "created_at" : "Thu Jun 19 22:03:19 +0000 2025",
      "favorited" : false,
      "full_text" : "@runrun_punch ありがとう〜〜！",
      "lang" : "ja",
      "in_reply_to_screen_name" : "runrun_punch",
      "in_reply_to_user_id_str" : "1925063776459751425"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1935736500496613505"
          ],
          "editableUntil" : "2025-06-19T17:28:40.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1935736500496613505/photo/1",
            "indices" : [
              "6",
              "29"
            ],
            "url" : "https://t.co/1fkYxNNEDe",
            "media_url" : "http://pbs.twimg.com/media/Gt0eFrcXkAAVpqO.jpg",
            "id_str" : "1935736497749069824",
            "id" : "1935736497749069824",
            "media_url_https" : "https://pbs.twimg.com/media/Gt0eFrcXkAAVpqO.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "351",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1056",
                "h" : "2048",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "619",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/1fkYxNNEDe"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "47",
      "id_str" : "1935736500496613505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1935736500496613505",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jun 19 16:28:40 +0000 2025",
      "favorited" : false,
      "full_text" : "飛びました https://t.co/1fkYxNNEDe",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1935736500496613505/photo/1",
            "indices" : [
              "6",
              "29"
            ],
            "url" : "https://t.co/1fkYxNNEDe",
            "media_url" : "http://pbs.twimg.com/media/Gt0eFrcXkAAVpqO.jpg",
            "id_str" : "1935736497749069824",
            "id" : "1935736497749069824",
            "media_url_https" : "https://pbs.twimg.com/media/Gt0eFrcXkAAVpqO.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "351",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1056",
                "h" : "2048",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "619",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/1fkYxNNEDe"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1935696409703125009"
          ],
          "editableUntil" : "2025-06-19T14:49:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "35"
      ],
      "favorite_count" : "2",
      "id_str" : "1935696409703125009",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1935696409703125009",
      "created_at" : "Thu Jun 19 13:49:22 +0000 2025",
      "favorited" : false,
      "full_text" : "まあめちゃくちゃ楽しかったからええか。なんなら帰るのも惜しいくらいだ。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1935696181981741325"
          ],
          "editableUntil" : "2025-06-19T14:48:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "3",
      "id_str" : "1935696181981741325",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1935696181981741325",
      "created_at" : "Thu Jun 19 13:48:27 +0000 2025",
      "favorited" : false,
      "full_text" : "最寄り駅着くの00:04なんですか…！？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1935693369289904611"
          ],
          "editableUntil" : "2025-06-19T14:37:17.339Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "よあ",
            "screen_name" : "yoa195488",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "1770962201538625536",
            "id" : "1770962201538625536"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/BLnHOjGJfI",
            "expanded_url" : "https://docs.google.com/forms/d/e/1FAIpQLSckBrEwhYISuIirFd93iC60l6sbYSCMCWLJ7-Hwaj7mbK9Tpg/viewform",
            "display_url" : "docs.google.com/forms/d/e/1FAI…",
            "indices" : [
              "44",
              "67"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "67"
      ],
      "favorite_count" : "0",
      "id_str" : "1935693369289904611",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1935693369289904611",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jun 19 13:37:17 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @yoa195488: 現状回答者4人のみなので時間空いてる方お願いします...\nhttps://t.co/BLnHOjGJfI",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1935476248324813291"
          ],
          "editableUntil" : "2025-06-19T00:14:31.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/6bIC3RwJwk",
            "expanded_url" : "https://x.com/PokemonTCGP_JP/status/1935322930314879188",
            "display_url" : "x.com/PokemonTCGP_JP…",
            "indices" : [
              "26",
              "49"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "1",
      "id_str" : "1935476248324813291",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1935476248324813291",
      "possibly_sensitive" : false,
      "created_at" : "Wed Jun 18 23:14:31 +0000 2025",
      "favorited" : false,
      "full_text" : "ちょうどイーブイ秋山フレンズの話ししてたとこだった https://t.co/6bIC3RwJwk",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1935211889384112446"
          ],
          "editableUntil" : "2025-06-18T06:44:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "2",
      "id_str" : "1935211889384112446",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1935211889384112446",
      "created_at" : "Wed Jun 18 05:44:03 +0000 2025",
      "favorited" : false,
      "full_text" : "教室変更知らね〜！危うく2日連続で複素関数論の受講するとこだった〜！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1935207488258982183"
          ],
          "editableUntil" : "2025-06-18T06:26:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "3",
      "id_str" : "1935207488258982183",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1935207488258982183",
      "created_at" : "Wed Jun 18 05:26:34 +0000 2025",
      "favorited" : false,
      "full_text" : "L演習の宿題やってて気づいた。\n昨日の複素関数論のテストで、「ド・モアブル」の定理を、「ド・モルガンの法則」と書いたことに…😱😱😱",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1935097386613031393"
          ],
          "editableUntil" : "2025-06-17T23:09:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "15"
      ],
      "favorite_count" : "1",
      "id_str" : "1935097386613031393",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1935097386613031393",
      "created_at" : "Tue Jun 17 22:09:03 +0000 2025",
      "favorited" : false,
      "full_text" : "いいねだけ7400くらいしてる",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1935097064289165457"
          ],
          "editableUntil" : "2025-06-17T23:07:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "7",
      "id_str" : "1935097064289165457",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1935097064289165457",
      "created_at" : "Tue Jun 17 22:07:47 +0000 2025",
      "favorited" : false,
      "full_text" : "入学すらしていない最下層位タラーなので本当に勇気が出ない",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1935096656896364881"
          ],
          "editableUntil" : "2025-06-17T23:06:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "59"
      ],
      "favorite_count" : "3",
      "id_str" : "1935096656896364881",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1935096656896364881",
      "created_at" : "Tue Jun 17 22:06:10 +0000 2025",
      "favorited" : false,
      "full_text" : "AES枕アンケート、目標人数の半分は超えたけど、残り集まるか…？？？twitterで募集…？？？でもそんな勇気ないな。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1934983272511267097"
          ],
          "editableUntil" : "2025-06-17T15:35:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "0",
      "id_str" : "1934983272511267097",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1934983272511267097",
      "created_at" : "Tue Jun 17 14:35:37 +0000 2025",
      "favorited" : false,
      "full_text" : "もう無理って連呼してるのに理由がわからない。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1934884114882285586"
          ],
          "editableUntil" : "2025-06-17T09:01:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "2",
      "id_str" : "1934884114882285586",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1934884114882285586",
      "created_at" : "Tue Jun 17 08:01:36 +0000 2025",
      "favorited" : false,
      "full_text" : "タオル忘れた自分を今めっちゃ恨んでる()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1934154135630381164"
          ],
          "editableUntil" : "2025-06-15T08:40:55.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "56"
      ],
      "favorite_count" : "1",
      "id_str" : "1934154135630381164",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1934154135630381164",
      "created_at" : "Sun Jun 15 07:40:55 +0000 2025",
      "favorited" : false,
      "full_text" : "50円玉欲しくて864円のものに5010円払ったの、理系大学生として…とかでなく、1人の学ぶ者として恥ずかしい。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1934077143123972393"
          ],
          "editableUntil" : "2025-06-15T03:34:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "1",
      "id_str" : "1934077143123972393",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1934077143123972393",
      "created_at" : "Sun Jun 15 02:34:58 +0000 2025",
      "favorited" : false,
      "full_text" : "暑い！！！私、いつでも倒れられますからね！！！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1934023618645893375"
          ],
          "editableUntil" : "2025-06-15T00:02:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "いな",
            "screen_name" : "ina_uec24",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1771568167615414272",
            "id" : "1771568167615414272"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "15"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1934022220772454522",
      "id_str" : "1934023618645893375",
      "in_reply_to_user_id" : "1771568167615414272",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1934023618645893375",
      "in_reply_to_status_id" : "1934022220772454522",
      "created_at" : "Sat Jun 14 23:02:17 +0000 2025",
      "favorited" : false,
      "full_text" : "@ina_uec24 おはよ〜",
      "lang" : "ja",
      "in_reply_to_screen_name" : "ina_uec24",
      "in_reply_to_user_id_str" : "1771568167615414272"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1934015229081571806"
          ],
          "editableUntil" : "2025-06-14T23:28:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "0",
      "id_str" : "1934015229081571806",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1934015229081571806",
      "created_at" : "Sat Jun 14 22:28:57 +0000 2025",
      "favorited" : false,
      "full_text" : "今日は体調が芳しくないという言葉が一番似合う()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1796134379476963466"
          ],
          "editableUntil" : "2024-05-30T11:59:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "57"
      ],
      "favorite_count" : "1",
      "id_str" : "1796134379476963466",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1796134379476963466",
      "created_at" : "Thu May 30 10:59:41 +0000 2024",
      "favorited" : false,
      "full_text" : "中学生の時に勉強したけど何が何だかわかんなかったやつを、大学生になった今また勉強したらすごい納得できた！成長した！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1795992803907936336"
          ],
          "editableUntil" : "2024-05-30T02:37:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "5",
      "id_str" : "1795992803907936336",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1795992803907936336",
      "created_at" : "Thu May 30 01:37:07 +0000 2024",
      "favorited" : false,
      "full_text" : "100均に脳みそ売ってた。気になったけど臓器売買は良くないと思って買わなかった。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1795846467816661065"
          ],
          "editableUntil" : "2024-05-29T16:55:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "47"
      ],
      "favorite_count" : "0",
      "id_str" : "1795846467816661065",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1795846467816661065",
      "created_at" : "Wed May 29 15:55:37 +0000 2024",
      "favorited" : false,
      "full_text" : "溜めてたこのすば3期観たけど、ダクネスってこんなにも常識枠だったっけ？もっと変態じゃないっけ？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1795428367308861673"
          ],
          "editableUntil" : "2024-05-28T13:14:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "2",
      "id_str" : "1795428367308861673",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1795428367308861673",
      "created_at" : "Tue May 28 12:14:14 +0000 2024",
      "favorited" : false,
      "full_text" : "UTF-8を「ゆーたふえいと」って読んでたの全世界で私だけ説",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1795248381687922816"
          ],
          "editableUntil" : "2024-05-28T01:19:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "1",
      "id_str" : "1795248381687922816",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1795248381687922816",
      "created_at" : "Tue May 28 00:19:02 +0000 2024",
      "favorited" : false,
      "full_text" : "どんだけ電車内で眠くてもツイッター見てればとりま眠気を忘れられる。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1794735972124610761"
          ],
          "editableUntil" : "2024-05-26T15:22:54.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "0",
      "id_str" : "1794735972124610761",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1794735972124610761",
      "created_at" : "Sun May 26 14:22:54 +0000 2024",
      "favorited" : false,
      "full_text" : "なんかテスト前にDr.STONEにハマりそう",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1794373830905127370"
          ],
          "editableUntil" : "2024-05-25T15:23:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "1",
      "id_str" : "1794373830905127370",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1794373830905127370",
      "created_at" : "Sat May 25 14:23:53 +0000 2024",
      "favorited" : false,
      "full_text" : "なんかテスト前にアークナイツにハマり直ししそう",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1793614545396834725"
          ],
          "editableUntil" : "2024-05-23T13:06:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "実は源さんのこの曲も大好き",
            "indices" : [
              "40",
              "54"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/I9wdMbsete",
            "expanded_url" : "https://youtu.be/QK_xF-qPBik?si=PazJ4-IHoCgXIhXR",
            "display_url" : "youtu.be/QK_xF-qPBik?si…",
            "indices" : [
              "56",
              "79"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "79"
      ],
      "favorite_count" : "1",
      "id_str" : "1793614545396834725",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1793614545396834725",
      "possibly_sensitive" : false,
      "created_at" : "Thu May 23 12:06:46 +0000 2024",
      "favorited" : false,
      "full_text" : "本当は星野源の好きな曲とか絞るの激ムズだけどマイナーめのやつ選んだってことで。\n#実は源さんのこの曲も大好き\n\nhttps://t.co/I9wdMbsete",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1793277788436230357"
          ],
          "editableUntil" : "2024-05-22T14:48:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "4",
      "id_str" : "1793277788436230357",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1793277788436230357",
      "created_at" : "Wed May 22 13:48:36 +0000 2024",
      "favorited" : false,
      "full_text" : "開示来たけど共テで漢文が失敗してなかったらⅠ類入れたな…っていう点数で悔しい。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1792900552227168489"
          ],
          "editableUntil" : "2024-05-21T13:49:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "1",
      "id_str" : "1792900552227168489",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1792900552227168489",
      "created_at" : "Tue May 21 12:49:36 +0000 2024",
      "favorited" : false,
      "full_text" : "図書館のPCいっぱいルームの机の下にモンスターの缶落ちてた！捨てなかったやつ許さん！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1792519515005436337"
          ],
          "editableUntil" : "2024-05-20T12:35:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1792519515005436337/photo/1",
            "indices" : [
              "27",
              "50"
            ],
            "url" : "https://t.co/BP1Q2WRhHr",
            "media_url" : "http://pbs.twimg.com/media/GOBO9eiaYAAQ685.jpg",
            "id_str" : "1792519469769842688",
            "id" : "1792519469769842688",
            "media_url_https" : "https://pbs.twimg.com/media/GOBO9eiaYAAQ685.jpg",
            "sizes" : {
              "large" : {
                "w" : "1080",
                "h" : "1620",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "453",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "800",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/BP1Q2WRhHr"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "50"
      ],
      "favorite_count" : "1",
      "id_str" : "1792519515005436337",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1792519515005436337",
      "possibly_sensitive" : false,
      "created_at" : "Mon May 20 11:35:30 +0000 2024",
      "favorited" : false,
      "full_text" : "いつまでも子供心を忘れずに生きていきたいものですね。 https://t.co/BP1Q2WRhHr",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1792519515005436337/photo/1",
            "indices" : [
              "27",
              "50"
            ],
            "url" : "https://t.co/BP1Q2WRhHr",
            "media_url" : "http://pbs.twimg.com/media/GOBO9eiaYAAQ685.jpg",
            "id_str" : "1792519469769842688",
            "id" : "1792519469769842688",
            "media_url_https" : "https://pbs.twimg.com/media/GOBO9eiaYAAQ685.jpg",
            "sizes" : {
              "large" : {
                "w" : "1080",
                "h" : "1620",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "453",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "800",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/BP1Q2WRhHr"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1792000458816659507"
          ],
          "editableUntil" : "2024-05-19T02:12:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "13"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1792000359994732975",
      "id_str" : "1792000458816659507",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1792000458816659507",
      "in_reply_to_status_id" : "1792000359994732975",
      "created_at" : "Sun May 19 01:12:57 +0000 2024",
      "favorited" : false,
      "full_text" : "ちなみに昆布検定も持ってる",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1792000359994732975"
          ],
          "editableUntil" : "2024-05-19T02:12:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1792000359994732975/photo/1",
            "indices" : [
              "54",
              "77"
            ],
            "url" : "https://t.co/mVRecmiH1S",
            "media_url" : "http://pbs.twimg.com/media/GN52iWtbkAAEkCq.jpg",
            "id_str" : "1792000034323795968",
            "id" : "1792000034323795968",
            "media_url_https" : "https://pbs.twimg.com/media/GN52iWtbkAAEkCq.jpg",
            "sizes" : {
              "large" : {
                "w" : "2048",
                "h" : "1332",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "781",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "442",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/mVRecmiH1S"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "77"
      ],
      "favorite_count" : "4",
      "id_str" : "1792000359994732975",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1792000359994732975",
      "possibly_sensitive" : false,
      "created_at" : "Sun May 19 01:12:34 +0000 2024",
      "favorited" : false,
      "full_text" : "皆さまの応援のおかげでついにカレーパン検定に合格し、カレーパンタジスタになれました！ありがとうございます！ https://t.co/mVRecmiH1S",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1792000359994732975/photo/1",
            "indices" : [
              "54",
              "77"
            ],
            "url" : "https://t.co/mVRecmiH1S",
            "media_url" : "http://pbs.twimg.com/media/GN52iWtbkAAEkCq.jpg",
            "id_str" : "1792000034323795968",
            "id" : "1792000034323795968",
            "media_url_https" : "https://pbs.twimg.com/media/GN52iWtbkAAEkCq.jpg",
            "sizes" : {
              "large" : {
                "w" : "2048",
                "h" : "1332",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "781",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "442",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/mVRecmiH1S"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1791837780005523788"
          ],
          "editableUntil" : "2024-05-18T15:26:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "2",
      "id_str" : "1791837780005523788",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1791837780005523788",
      "created_at" : "Sat May 18 14:26:32 +0000 2024",
      "favorited" : false,
      "full_text" : "ピアスのおかわりしたけどやっぱ痛てえ。でも今回は２個開けたから分散してる。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1790697683008782348"
          ],
          "editableUntil" : "2024-05-15T11:56:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "0",
      "id_str" : "1790697683008782348",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1790697683008782348",
      "created_at" : "Wed May 15 10:56:11 +0000 2024",
      "favorited" : false,
      "full_text" : "Agoraでの自分の声でかすぎる気がする。そもそも仲いい子と一緒にいると調子乗り過ぎちゃう。反省。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1790323849793565079"
          ],
          "editableUntil" : "2024-05-14T11:10:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "8"
      ],
      "favorite_count" : "1",
      "id_str" : "1790323849793565079",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1790323849793565079",
      "created_at" : "Tue May 14 10:10:43 +0000 2024",
      "favorited" : false,
      "full_text" : "傘おかえりなさい",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1790030828816216524"
          ],
          "editableUntil" : "2024-05-13T15:46:21.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "猫好き",
            "screen_name" : "NewKeep_y",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1765218063530815488",
            "id" : "1765218063530815488"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1789974677667860829",
      "id_str" : "1790030828816216524",
      "in_reply_to_user_id" : "1765218063530815488",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1790030828816216524",
      "in_reply_to_status_id" : "1789974677667860829",
      "created_at" : "Mon May 13 14:46:21 +0000 2024",
      "favorited" : false,
      "full_text" : "@NewKeep_y oh…かなしいよね",
      "lang" : "ja",
      "in_reply_to_screen_name" : "NewKeep_y",
      "in_reply_to_user_id_str" : "1765218063530815488"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1789962113059819783"
          ],
          "editableUntil" : "2024-05-13T11:13:18.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "18"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1789961910244294849",
      "id_str" : "1789962113059819783",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1789962113059819783",
      "in_reply_to_status_id" : "1789961910244294849",
      "created_at" : "Mon May 13 10:13:18 +0000 2024",
      "favorited" : false,
      "full_text" : "これを見た人も傘の忘れ物に気をつけて",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1789961910244294849"
          ],
          "editableUntil" : "2024-05-13T11:12:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "5",
      "id_str" : "1789961910244294849",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1789961910244294849",
      "created_at" : "Mon May 13 10:12:29 +0000 2024",
      "favorited" : false,
      "full_text" : "案の定傘を電車に忘れた…前忘れたときは帰ってこなかったな",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1789287324116975643"
          ],
          "editableUntil" : "2024-05-11T14:31:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "５えん(実験中)",
            "screen_name" : "saveyenw",
            "indices" : [
              "0",
              "9"
            ],
            "id_str" : "1027592725846093824",
            "id" : "1027592725846093824"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "4",
      "in_reply_to_status_id_str" : "1789286938396266865",
      "id_str" : "1789287324116975643",
      "in_reply_to_user_id" : "1027592725846093824",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1789287324116975643",
      "in_reply_to_status_id" : "1789286938396266865",
      "created_at" : "Sat May 11 13:31:56 +0000 2024",
      "favorited" : false,
      "full_text" : "@saveyenw あざます💰💰💰💰💰💰💰",
      "lang" : "ja",
      "in_reply_to_screen_name" : "saveyenw",
      "in_reply_to_user_id_str" : "1027592725846093824"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1789286627648668103"
          ],
          "editableUntil" : "2024-05-11T14:29:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "12"
      ],
      "favorite_count" : "3",
      "id_str" : "1789286627648668103",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1789286627648668103",
      "created_at" : "Sat May 11 13:29:10 +0000 2024",
      "favorited" : false,
      "full_text" : "おやすみな𝒔𝒄𝒊𝒆𝒏𝒄𝒆",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1789285753538941169"
          ],
          "editableUntil" : "2024-05-11T14:25:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "猫好き",
            "screen_name" : "NewKeep_y",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1765218063530815488",
            "id" : "1765218063530815488"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "44"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1789269869047029786",
      "id_str" : "1789285753538941169",
      "in_reply_to_user_id" : "1765218063530815488",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1789285753538941169",
      "in_reply_to_status_id" : "1789269869047029786",
      "created_at" : "Sat May 11 13:25:41 +0000 2024",
      "favorited" : false,
      "full_text" : "@NewKeep_y 多分スーパー激混み満員電車に乗ったときな気がするからもう救出不可…",
      "lang" : "ja",
      "in_reply_to_screen_name" : "NewKeep_y",
      "in_reply_to_user_id_str" : "1765218063530815488"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1789251865542308256"
          ],
          "editableUntil" : "2024-05-11T12:11:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "46"
      ],
      "favorite_count" : "3",
      "id_str" : "1789251865542308256",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1789251865542308256",
      "created_at" : "Sat May 11 11:11:02 +0000 2024",
      "favorited" : false,
      "full_text" : "えまって僕とロボコの押忍!クソ男飯キーホルダーなくしたんだけどwww好きだったからつらwww",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1789248100907069592"
          ],
          "editableUntil" : "2024-05-11T11:56:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "42"
      ],
      "favorite_count" : "5",
      "id_str" : "1789248100907069592",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1789248100907069592",
      "created_at" : "Sat May 11 10:56:04 +0000 2024",
      "favorited" : false,
      "full_text" : "BBQで前より胃と膀胱が縮小してることと「デザートは別腹」はガチだということを知った",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1788739693657702651"
          ],
          "editableUntil" : "2024-05-10T02:15:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "猫好き",
            "screen_name" : "NewKeep_y",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1765218063530815488",
            "id" : "1765218063530815488"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1788690178497794491",
      "id_str" : "1788739693657702651",
      "in_reply_to_user_id" : "1765218063530815488",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1788739693657702651",
      "in_reply_to_status_id" : "1788690178497794491",
      "created_at" : "Fri May 10 01:15:50 +0000 2024",
      "favorited" : false,
      "full_text" : "@NewKeep_y そう。原理とか最低限でいいよって感じのスペースの狭さ",
      "lang" : "ja",
      "in_reply_to_screen_name" : "NewKeep_y",
      "in_reply_to_user_id_str" : "1765218063530815488"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1788621602667819426"
          ],
          "editableUntil" : "2024-05-09T18:26:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "猫好き",
            "screen_name" : "NewKeep_y",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "1765218063530815488",
            "id" : "1765218063530815488"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1788587108384567723",
      "id_str" : "1788621602667819426",
      "in_reply_to_user_id" : "1765218063530815488",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1788621602667819426",
      "in_reply_to_status_id" : "1788587108384567723",
      "created_at" : "Thu May 09 17:26:35 +0000 2024",
      "favorited" : false,
      "full_text" : "@NewKeep_y もらったてんぷれ紙の書くスペースが小さすぎて今まで一生懸命長々と書いた文章がだいぶ無駄になった...",
      "lang" : "ja",
      "in_reply_to_screen_name" : "NewKeep_y",
      "in_reply_to_user_id_str" : "1765218063530815488"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1788580965184598171"
          ],
          "editableUntil" : "2024-05-09T15:45:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "4",
      "in_reply_to_status_id_str" : "1788187797238771729",
      "id_str" : "1788580965184598171",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1788580965184598171",
      "in_reply_to_status_id" : "1788187797238771729",
      "created_at" : "Thu May 09 14:45:06 +0000 2024",
      "favorited" : false,
      "full_text" : "み　ず　の　あ　わ\n(唐突な手書き指示)",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1788187797238771729"
          ],
          "editableUntil" : "2024-05-08T13:42:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "5",
      "id_str" : "1788187797238771729",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1788187797238771729",
      "created_at" : "Wed May 08 12:42:48 +0000 2024",
      "favorited" : false,
      "full_text" : "謁見レポ5割終わった！\n\nまだ実験してないけど\n(全削除の可能性有)",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1787446511246418148"
          ],
          "editableUntil" : "2024-05-06T12:37:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1787446511246418148/photo/1",
            "indices" : [
              "36",
              "59"
            ],
            "url" : "https://t.co/AnBEqhAE1B",
            "media_url" : "http://pbs.twimg.com/media/GM5IwH2bAAA74Lv.jpg",
            "id_str" : "1787446093690896384",
            "id" : "1787446093690896384",
            "media_url_https" : "https://pbs.twimg.com/media/GM5IwH2bAAA74Lv.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1920",
                "h" : "1080",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/AnBEqhAE1B"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "59"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1787417767693697188",
      "id_str" : "1787446511246418148",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1787446511246418148",
      "in_reply_to_status_id" : "1787417767693697188",
      "possibly_sensitive" : false,
      "created_at" : "Mon May 06 11:37:12 +0000 2024",
      "favorited" : false,
      "full_text" : "アイコンを等間隔に整列らへんをいじってたらどうにかちょっともとに戻せた https://t.co/AnBEqhAE1B",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1787446511246418148/photo/1",
            "indices" : [
              "36",
              "59"
            ],
            "url" : "https://t.co/AnBEqhAE1B",
            "media_url" : "http://pbs.twimg.com/media/GM5IwH2bAAA74Lv.jpg",
            "id_str" : "1787446093690896384",
            "id" : "1787446093690896384",
            "media_url_https" : "https://pbs.twimg.com/media/GM5IwH2bAAA74Lv.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1920",
                "h" : "1080",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/AnBEqhAE1B"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1787417767693697188"
          ],
          "editableUntil" : "2024-05-06T10:42:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1787335478515245515",
      "id_str" : "1787417767693697188",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1787417767693697188",
      "in_reply_to_status_id" : "1787335478515245515",
      "created_at" : "Mon May 06 09:42:59 +0000 2024",
      "favorited" : false,
      "full_text" : "せっせと直して再起動したらまたぐちゃぐちゃになってて悲しかった。設定が悪いんか？それともバグ？🤔",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1787335478515245515"
          ],
          "editableUntil" : "2024-05-06T05:15:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1787335478515245515/photo/1",
            "indices" : [
              "46",
              "69"
            ],
            "url" : "https://t.co/gMpvUqqqyz",
            "media_url" : "http://pbs.twimg.com/media/GM3j3mJaIAATIeA.jpg",
            "id_str" : "1787335171408273408",
            "id" : "1787335171408273408",
            "media_url_https" : "https://pbs.twimg.com/media/GM3j3mJaIAATIeA.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1920",
                "h" : "1080",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/gMpvUqqqyz"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "69"
      ],
      "favorite_count" : "7",
      "id_str" : "1787335478515245515",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1787335478515245515",
      "possibly_sensitive" : false,
      "created_at" : "Mon May 06 04:15:59 +0000 2024",
      "favorited" : false,
      "full_text" : "デスクトップの整理してから2日ぶりにPC開いたらぐちゃぐちゃになってて怖くて震えてる... https://t.co/gMpvUqqqyz",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1787335478515245515/photo/1",
            "indices" : [
              "46",
              "69"
            ],
            "url" : "https://t.co/gMpvUqqqyz",
            "media_url" : "http://pbs.twimg.com/media/GM3j3mJaIAATIeA.jpg",
            "id_str" : "1787335171408273408",
            "id" : "1787335171408273408",
            "media_url_https" : "https://pbs.twimg.com/media/GM3j3mJaIAATIeA.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1920",
                "h" : "1080",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/gMpvUqqqyz"
          },
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1787335478515245515/photo/1",
            "indices" : [
              "46",
              "69"
            ],
            "url" : "https://t.co/gMpvUqqqyz",
            "media_url" : "http://pbs.twimg.com/media/GM3j4_XbAAAoKgc.jpg",
            "id_str" : "1787335195357806592",
            "id" : "1787335195357806592",
            "media_url_https" : "https://pbs.twimg.com/media/GM3j4_XbAAAoKgc.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "383",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "675",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1920",
                "h" : "1080",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/gMpvUqqqyz"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1786730483969380724"
          ],
          "editableUntil" : "2024-05-04T13:11:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1786730483969380724/photo/1",
            "indices" : [
              "25",
              "48"
            ],
            "url" : "https://t.co/2liG11Ko75",
            "media_url" : "http://pbs.twimg.com/media/GMu95-Sa4AANdB4.jpg",
            "id_str" : "1786730480852983808",
            "id" : "1786730480852983808",
            "media_url_https" : "https://pbs.twimg.com/media/GMu95-Sa4AANdB4.jpg",
            "sizes" : {
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/2liG11Ko75"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "5",
      "id_str" : "1786730483969380724",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1786730483969380724",
      "possibly_sensitive" : false,
      "created_at" : "Sat May 04 12:11:57 +0000 2024",
      "favorited" : false,
      "full_text" : "昼の超こってりのせいで私は夜苦しんでいるのだ…！ https://t.co/2liG11Ko75",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1786730483969380724/photo/1",
            "indices" : [
              "25",
              "48"
            ],
            "url" : "https://t.co/2liG11Ko75",
            "media_url" : "http://pbs.twimg.com/media/GMu95-Sa4AANdB4.jpg",
            "id_str" : "1786730480852983808",
            "id" : "1786730480852983808",
            "media_url_https" : "https://pbs.twimg.com/media/GMu95-Sa4AANdB4.jpg",
            "sizes" : {
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/2liG11Ko75"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1786293891655963072"
          ],
          "editableUntil" : "2024-05-03T08:17:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "15"
      ],
      "favorite_count" : "3",
      "id_str" : "1786293891655963072",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1786293891655963072",
      "created_at" : "Fri May 03 07:17:06 +0000 2024",
      "favorited" : false,
      "full_text" : "3度寝です。おはようございます",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1785656008121241941"
          ],
          "editableUntil" : "2024-05-01T14:02:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "17"
      ],
      "favorite_count" : "5",
      "id_str" : "1785656008121241941",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1785656008121241941",
      "created_at" : "Wed May 01 13:02:22 +0000 2024",
      "favorited" : false,
      "full_text" : "数円は公式サイトの過去問が役立つね",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1785457439233687815"
          ],
          "editableUntil" : "2024-05-01T00:53:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "1",
      "id_str" : "1785457439233687815",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1785457439233687815",
      "created_at" : "Tue Apr 30 23:53:20 +0000 2024",
      "favorited" : false,
      "full_text" : "学校にエグめの忘れ物したのに今気づいた()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1785268022326042999"
          ],
          "editableUntil" : "2024-04-30T12:20:39.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "4",
      "id_str" : "1785268022326042999",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1785268022326042999",
      "created_at" : "Tue Apr 30 11:20:39 +0000 2024",
      "favorited" : false,
      "full_text" : "甘ったるすぎないケーキってめっちゃいいな",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1783864564960104560"
          ],
          "editableUntil" : "2024-04-26T15:23:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "1",
      "id_str" : "1783864564960104560",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1783864564960104560",
      "created_at" : "Fri Apr 26 14:23:49 +0000 2024",
      "favorited" : false,
      "full_text" : "今日の健康論は調子良すぎて調子乗ったな。反省",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1782321479268638937"
          ],
          "editableUntil" : "2024-04-22T09:12:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "12"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1782321202062914003",
      "id_str" : "1782321479268638937",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1782321479268638937",
      "in_reply_to_status_id" : "1782321202062914003",
      "created_at" : "Mon Apr 22 08:12:09 +0000 2024",
      "favorited" : false,
      "full_text" : "垢間違えたけどまあいいか",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1782321202062914003"
          ],
          "editableUntil" : "2024-04-22T09:11:03.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "JK組",
            "indices" : [
              "27",
              "31"
            ]
          },
          {
            "text" : "キミの隣ににじさんじ",
            "indices" : [
              "77",
              "88"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/mAxgkY0EV9",
            "expanded_url" : "https://cheer-for-you-2024.nijisanji.jp/share/09",
            "display_url" : "cheer-for-you-2024.nijisanji.jp/share/09",
            "indices" : [
              "53",
              "76"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "88"
      ],
      "favorite_count" : "1",
      "id_str" : "1782321202062914003",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1782321202062914003",
      "possibly_sensitive" : false,
      "created_at" : "Mon Apr 22 08:11:03 +0000 2024",
      "favorited" : false,
      "full_text" : "🌈にじさんじ学校分け診断🏫\nあなたのタイプは...\n\n#JK組\n探求心があり好きなものを突き詰める個性派\nhttps://t.co/mAxgkY0EV9 #キミの隣ににじさんじ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1781646413946101942"
          ],
          "editableUntil" : "2024-04-20T12:29:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1781645234147078223",
      "id_str" : "1781646413946101942",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1781646413946101942",
      "in_reply_to_status_id" : "1781645234147078223",
      "created_at" : "Sat Apr 20 11:29:41 +0000 2024",
      "favorited" : false,
      "full_text" : "私の呼びかけに応えること以外なら両立できる(？)弟",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1781645234147078223"
          ],
          "editableUntil" : "2024-04-20T12:24:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "150"
      ],
      "favorite_count" : "1",
      "id_str" : "1781645234147078223",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1781645234147078223",
      "created_at" : "Sat Apr 20 11:24:59 +0000 2024",
      "favorited" : false,
      "full_text" : "友達と通話しながらSwitchでスマブラやって3DSで妖怪ウォッチやってテレビでリゼロみてスマホを2窓にしてモンストやってヒューマンバグ大学観てる弟みたいに、私も一人でピンインの歌聴きながら謁見レポ書いて化概の課題やってテレビではなかっぱみてスマホを2窓にしてQuizletやってコンリテの文字数()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1781298343878275494"
          ],
          "editableUntil" : "2024-04-19T13:26:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1781297189974933505",
      "id_str" : "1781298343878275494",
      "in_reply_to_user_id" : "1761736042695254016",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1781298343878275494",
      "in_reply_to_status_id" : "1781297189974933505",
      "created_at" : "Fri Apr 19 12:26:34 +0000 2024",
      "favorited" : false,
      "full_text" : "@nemu_physics 写研とスポチャンとx680x0！",
      "lang" : "ja",
      "in_reply_to_screen_name" : "nemu_cipher",
      "in_reply_to_user_id_str" : "1761736042695254016"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1781296553015304305"
          ],
          "editableUntil" : "2024-04-19T13:19:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "4",
      "id_str" : "1781296553015304305",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1781296553015304305",
      "created_at" : "Fri Apr 19 12:19:27 +0000 2024",
      "favorited" : false,
      "full_text" : "今日正式にサークル3つ掛け持ち決定！どれもほどほどにやってこー",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1780892183660511241"
          ],
          "editableUntil" : "2024-04-18T10:32:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "54"
      ],
      "favorite_count" : "0",
      "id_str" : "1780892183660511241",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1780892183660511241",
      "created_at" : "Thu Apr 18 09:32:38 +0000 2024",
      "favorited" : false,
      "full_text" : "ドレッシングかかってると思って食ってたサラダを食い進めてたらドレッシング袋が奥から出てきた。馬鹿舌かな？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1777312365861892247"
          ],
          "editableUntil" : "2024-04-08T13:27:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1777312365861892247/photo/1",
            "indices" : [
              "51",
              "74"
            ],
            "url" : "https://t.co/ZJxrQFTtqZ",
            "media_url" : "http://pbs.twimg.com/media/GKpILAFa4AAMLBO.jpg",
            "id_str" : "1777312356789575680",
            "id" : "1777312356789575680",
            "media_url_https" : "https://pbs.twimg.com/media/GKpILAFa4AAMLBO.jpg",
            "sizes" : {
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/ZJxrQFTtqZ"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "74"
      ],
      "favorite_count" : "1",
      "id_str" : "1777312365861892247",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1777312365861892247",
      "possibly_sensitive" : false,
      "created_at" : "Mon Apr 08 12:27:43 +0000 2024",
      "favorited" : false,
      "full_text" : "1日に2つゲット。スタンプラリー集めでめっちゃ動きづらい靴で歩きまくり、献血もしてきた。体張ったぞ！ https://t.co/ZJxrQFTtqZ",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1777312365861892247/photo/1",
            "indices" : [
              "51",
              "74"
            ],
            "url" : "https://t.co/ZJxrQFTtqZ",
            "media_url" : "http://pbs.twimg.com/media/GKpILAFa4AAMLBO.jpg",
            "id_str" : "1777312356789575680",
            "id" : "1777312356789575680",
            "media_url_https" : "https://pbs.twimg.com/media/GKpILAFa4AAMLBO.jpg",
            "sizes" : {
              "small" : {
                "w" : "510",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1536",
                "h" : "2048",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "900",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/ZJxrQFTtqZ"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1776957171005321502"
          ],
          "editableUntil" : "2024-04-07T13:56:18.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1776957171005321502/photo/1",
            "indices" : [
              "39",
              "62"
            ],
            "url" : "https://t.co/N7xZMV7FS1",
            "media_url" : "http://pbs.twimg.com/media/GKkFIWbbUAE3F9e.jpg",
            "id_str" : "1776957168992079873",
            "id" : "1776957168992079873",
            "media_url_https" : "https://pbs.twimg.com/media/GKkFIWbbUAE3F9e.jpg",
            "sizes" : {
              "medium" : {
                "w" : "759",
                "h" : "1200",
                "resize" : "fit"
              },
              "small" : {
                "w" : "430",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1080",
                "h" : "1707",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/N7xZMV7FS1"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "62"
      ],
      "favorite_count" : "4",
      "id_str" : "1776957171005321502",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1776957171005321502",
      "possibly_sensitive" : false,
      "created_at" : "Sun Apr 07 12:56:18 +0000 2024",
      "favorited" : false,
      "full_text" : "モバ充で妥協したらあたった！献血もすればワンチャンモバ充祭がブチ上がる？？？ https://t.co/N7xZMV7FS1",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1776957171005321502/photo/1",
            "indices" : [
              "39",
              "62"
            ],
            "url" : "https://t.co/N7xZMV7FS1",
            "media_url" : "http://pbs.twimg.com/media/GKkFIWbbUAE3F9e.jpg",
            "id_str" : "1776957168992079873",
            "id" : "1776957168992079873",
            "media_url_https" : "https://pbs.twimg.com/media/GKkFIWbbUAE3F9e.jpg",
            "sizes" : {
              "medium" : {
                "w" : "759",
                "h" : "1200",
                "resize" : "fit"
              },
              "small" : {
                "w" : "430",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1080",
                "h" : "1707",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/N7xZMV7FS1"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1776576226993578484"
          ],
          "editableUntil" : "2024-04-06T12:42:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "60"
      ],
      "favorite_count" : "2",
      "id_str" : "1776576226993578484",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1776576226993578484",
      "created_at" : "Sat Apr 06 11:42:34 +0000 2024",
      "favorited" : false,
      "full_text" : "キキキのレポートがレポートじゃなくて中学生の作文になってしまったんだけどこれでだしたら落ちるのだろうか？どう書けば良い？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1775500877518066158"
          ],
          "editableUntil" : "2024-04-03T13:29:31.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "64"
      ],
      "favorite_count" : "8",
      "id_str" : "1775500877518066158",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1775500877518066158",
      "created_at" : "Wed Apr 03 12:29:31 +0000 2024",
      "favorited" : false,
      "full_text" : "共テの漢文５０点満点だと思っていたら27点だった！\n＿人人人人人人人人＿\n＞　-23点の誤差　＜\n￣Y^Y^Y^Y^Y^Y^Y￣",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1775061537411235885"
          ],
          "editableUntil" : "2024-04-02T08:23:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "27"
      ],
      "favorite_count" : "1",
      "id_str" : "1775061537411235885",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1775061537411235885",
      "created_at" : "Tue Apr 02 07:23:44 +0000 2024",
      "favorited" : false,
      "full_text" : "uec検定と調布駅で各駅停車を見送るの同じくらいむずい",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1774787157884121488"
          ],
          "editableUntil" : "2024-04-01T14:13:27.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "13"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1774783445312643289",
      "id_str" : "1774787157884121488",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1774787157884121488",
      "in_reply_to_status_id" : "1774783445312643289",
      "created_at" : "Mon Apr 01 13:13:27 +0000 2024",
      "favorited" : false,
      "full_text" : "はずかしい気持ちが一番強い",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1774783445312643289"
          ],
          "editableUntil" : "2024-04-01T13:58:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "78"
      ],
      "favorite_count" : "15",
      "id_str" : "1774783445312643289",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1774783445312643289",
      "created_at" : "Mon Apr 01 12:58:41 +0000 2024",
      "favorited" : false,
      "full_text" : "何が嫌かって交流会で「Ⅱ類からⅠ類になったんすよwww」って自己紹介しちまったことが恥ずかしすぎることなんだよ。Ⅰ類の知り合いしか作れなかったことなんだよ。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1774743943227584994"
          ],
          "editableUntil" : "2024-04-01T11:21:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "11"
      ],
      "favorite_count" : "9",
      "in_reply_to_status_id_str" : "1774649425421627713",
      "id_str" : "1774743943227584994",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1774743943227584994",
      "in_reply_to_status_id" : "1774649425421627713",
      "created_at" : "Mon Apr 01 10:21:43 +0000 2024",
      "favorited" : false,
      "full_text" : "ぬ　か　よ　ろ　こ　び",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1774649425421627713"
          ],
          "editableUntil" : "2024-04-01T05:06:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "8"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1774293863085326440",
      "id_str" : "1774649425421627713",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1774649425421627713",
      "in_reply_to_status_id" : "1774293863085326440",
      "created_at" : "Mon Apr 01 04:06:09 +0000 2024",
      "favorited" : false,
      "full_text" : "Ⅱ類→Ⅰ類確定！",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1774298028721229964"
          ],
          "editableUntil" : "2024-03-31T05:49:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "0",
      "id_str" : "1774298028721229964",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1774298028721229964",
      "created_at" : "Sun Mar 31 04:49:49 +0000 2024",
      "favorited" : false,
      "full_text" : "クラスは1か5だから1類なら一限が週3で、2類なら週1かぁ…🤔",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1774293863085326440"
          ],
          "editableUntil" : "2024-03-31T05:33:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "62"
      ],
      "favorite_count" : "11",
      "id_str" : "1774293863085326440",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1774293863085326440",
      "created_at" : "Sun Mar 31 04:33:16 +0000 2024",
      "favorited" : false,
      "full_text" : "私は1類落ちの2類なんだけど、学籍番号の下から4桁目が1なのは変更願が受理された可能性があるってコト！？激アツかもしれん…！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1774001865631678491"
          ],
          "editableUntil" : "2024-03-30T10:12:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "2",
      "id_str" : "1774001865631678491",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1774001865631678491",
      "created_at" : "Sat Mar 30 09:12:58 +0000 2024",
      "favorited" : false,
      "full_text" : "花粉+普通の風邪+LaTeXの構築(?)=体温上昇！！！体調おかしい！！！謎テンション！！！ヒャッﾎｩーーー!！!！!！!",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1773951502098510256"
          ],
          "editableUntil" : "2024-03-30T06:52:51.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "1",
      "id_str" : "1773951502098510256",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1773951502098510256",
      "created_at" : "Sat Mar 30 05:52:51 +0000 2024",
      "favorited" : false,
      "full_text" : "latexインストール成功したかもしれんけどsdカードのファイルをコンパイルするとエラーになるのはなんで？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1772586348844589313"
          ],
          "editableUntil" : "2024-03-26T12:28:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1772586348844589313/photo/1",
            "indices" : [
              "82",
              "105"
            ],
            "url" : "https://t.co/dkvMpCDHJU",
            "media_url" : "http://pbs.twimg.com/media/GJl949xa0AAJZkt.jpg",
            "id_str" : "1772586345954988032",
            "id" : "1772586345954988032",
            "media_url_https" : "https://pbs.twimg.com/media/GJl949xa0AAJZkt.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "547",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1021",
                "h" : "822",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1021",
                "h" : "822",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/dkvMpCDHJU"
          }
        ],
        "hashtags" : [
          {
            "text" : "世代がバレる系ボカロビンゴ2023",
            "indices" : [
              "0",
              "18"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "105"
      ],
      "favorite_count" : "5",
      "id_str" : "1772586348844589313",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1772586348844589313",
      "possibly_sensitive" : false,
      "created_at" : "Tue Mar 26 11:28:13 +0000 2024",
      "favorited" : false,
      "full_text" : "#世代がバレる系ボカロビンゴ2023\n最近は綺麗に聴いてないなw私が中坊の頃の数年前から流行ってた曲をよく聞いてた気がする。てかほとんど歌みたで知ったやつっていう https://t.co/dkvMpCDHJU",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1772586348844589313/photo/1",
            "indices" : [
              "82",
              "105"
            ],
            "url" : "https://t.co/dkvMpCDHJU",
            "media_url" : "http://pbs.twimg.com/media/GJl949xa0AAJZkt.jpg",
            "id_str" : "1772586345954988032",
            "id" : "1772586345954988032",
            "media_url_https" : "https://pbs.twimg.com/media/GJl949xa0AAJZkt.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "547",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1021",
                "h" : "822",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1021",
                "h" : "822",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/dkvMpCDHJU"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1772134757159120932"
          ],
          "editableUntil" : "2024-03-25T06:33:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "75"
      ],
      "favorite_count" : "2",
      "id_str" : "1772134757159120932",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1772134757159120932",
      "created_at" : "Mon Mar 25 05:33:45 +0000 2024",
      "favorited" : false,
      "full_text" : "大容量のファイル移動でかかる時間が２３時間！？ってなってて、xでつぶやこうとして一瞬目を話した隙に４０分になったのはPCくんがツンデレってことでいい？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1768240550711537747"
          ],
          "editableUntil" : "2024-03-14T12:39:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "強くなれベジータ",
            "indices" : [
              "16",
              "25"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ドラゴンボールオフィシャル",
            "screen_name" : "DB_official_jp",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "2816443333",
            "id" : "2816443333"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1768187559732211832",
      "id_str" : "1768240550711537747",
      "in_reply_to_user_id" : "2816443333",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1768240550711537747",
      "in_reply_to_status_id" : "1768187559732211832",
      "created_at" : "Thu Mar 14 11:39:34 +0000 2024",
      "favorited" : false,
      "full_text" : "@DB_official_jp #強くなれベジータ \nベジータのおかげで2番手キャラめっちゃ好きなんよ",
      "lang" : "ja",
      "in_reply_to_screen_name" : "DB_official_jp",
      "in_reply_to_user_id_str" : "2816443333"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1767525800965013575"
          ],
          "editableUntil" : "2024-03-12T13:19:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "2",
      "id_str" : "1767525800965013575",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1767525800965013575",
      "created_at" : "Tue Mar 12 12:19:24 +0000 2024",
      "favorited" : false,
      "full_text" : "Latexやっぱりだめだ！！VScodeもともとダウンロードしてたラッキー！！…とか思ってたのに…コンパイルめ！！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1766078839522996638"
          ],
          "editableUntil" : "2024-03-08T13:29:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "1",
      "id_str" : "1766078839522996638",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1766078839522996638",
      "created_at" : "Fri Mar 08 12:29:42 +0000 2024",
      "favorited" : false,
      "full_text" : "でぃすこ怖すぎて逃げ出してしまった。よわよわすぎる",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1765752257344360504"
          ],
          "editableUntil" : "2024-03-07T15:51:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "3",
      "id_str" : "1765752257344360504",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1765752257344360504",
      "created_at" : "Thu Mar 07 14:51:58 +0000 2024",
      "favorited" : false,
      "full_text" : "電通大って体育あるんすか！？超頑張るしかない",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1765661152762052816"
          ],
          "editableUntil" : "2024-03-07T09:49:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "uec24",
            "indices" : [
              "41",
              "47"
            ]
          },
          {
            "text" : "春から電通大",
            "indices" : [
              "48",
              "55"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "55"
      ],
      "favorite_count" : "23",
      "id_str" : "1765661152762052816",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1765661152762052816",
      "created_at" : "Thu Mar 07 08:49:57 +0000 2024",
      "favorited" : false,
      "full_text" : "電通大Ⅱ類受かりました。(第一志望はⅠ類だったが。)とりあえず情報収集始めます。\n#uec24 #春から電通大",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1934012012503384092"
          ],
          "editableUntil" : "2025-06-14T23:16:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "32"
      ],
      "favorite_count" : "1",
      "id_str" : "1934012012503384092",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1934012012503384092",
      "created_at" : "Sat Jun 14 22:16:10 +0000 2025",
      "favorited" : false,
      "full_text" : "まって部室でルーティーン設定の目覚まし貫通してた疑惑が(ごめん)",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1933184754393989436"
          ],
          "editableUntil" : "2025-06-12T16:28:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "26"
      ],
      "favorite_count" : "2",
      "id_str" : "1933184754393989436",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1933184754393989436",
      "created_at" : "Thu Jun 12 15:28:56 +0000 2025",
      "favorited" : false,
      "full_text" : "今日の大塩化会の鑑賞会しにスポチャン行けばよかったな",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1933182492397453787"
          ],
          "editableUntil" : "2025-06-12T16:19:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "0",
      "id_str" : "1933182492397453787",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1933182492397453787",
      "created_at" : "Thu Jun 12 15:19:57 +0000 2025",
      "favorited" : false,
      "full_text" : "この感情絶対今さっきバチェラー観てたからだろ()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1933181173624377630"
          ],
          "editableUntil" : "2025-06-12T16:14:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "0",
      "id_str" : "1933181173624377630",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1933181173624377630",
      "created_at" : "Thu Jun 12 15:14:43 +0000 2025",
      "favorited" : false,
      "full_text" : "なんかバチェロレッテの恋愛抜きやってる気分",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1933103024664416281"
          ],
          "editableUntil" : "2025-06-12T11:04:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "16"
      ],
      "favorite_count" : "0",
      "id_str" : "1933103024664416281",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1933103024664416281",
      "created_at" : "Thu Jun 12 10:04:11 +0000 2025",
      "favorited" : false,
      "full_text" : "これはこれでおれは愛していくよ。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1933102922445074455"
          ],
          "editableUntil" : "2025-06-12T11:03:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "54"
      ],
      "favorite_count" : "2",
      "id_str" : "1933102922445074455",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1933102922445074455",
      "created_at" : "Thu Jun 12 10:03:46 +0000 2025",
      "favorited" : false,
      "full_text" : "待ってフィルム知らなすぎて、結構いい感じだと思ってたけど、一般的には色とか粗さとかがかなり酷いのでは…？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1933092658576347409"
          ],
          "editableUntil" : "2025-06-12T10:22:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1933089398582837259",
      "id_str" : "1933092658576347409",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1933092658576347409",
      "in_reply_to_status_id" : "1933089398582837259",
      "created_at" : "Thu Jun 12 09:22:59 +0000 2025",
      "favorited" : false,
      "full_text" : "そうはいっても、色調不良にチェックはちゃんとついてるわね…",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1933089398582837259"
          ],
          "editableUntil" : "2025-06-12T10:10:02.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/fFbfJeRfIJ",
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1930436707314479127",
            "display_url" : "x.com/joyjoy_7shichi…",
            "indices" : [
              "19",
              "42"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1933089398582837259/photo/1",
            "indices" : [
              "43",
              "66"
            ],
            "url" : "https://t.co/SSYMvpgZnb",
            "media_url" : "http://pbs.twimg.com/media/GtO2j5wbcAEl6x2.jpg",
            "id_str" : "1933089392987697153",
            "id" : "1933089392987697153",
            "media_url_https" : "https://pbs.twimg.com/media/GtO2j5wbcAEl6x2.jpg",
            "sizes" : {
              "large" : {
                "w" : "1422",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "833",
                "h" : "1200",
                "resize" : "fit"
              },
              "small" : {
                "w" : "472",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/SSYMvpgZnb"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "66"
      ],
      "favorite_count" : "4",
      "id_str" : "1933089398582837259",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1933089398582837259",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jun 12 09:10:02 +0000 2025",
      "favorited" : false,
      "full_text" : "意外とちゃんと映ってるじゃないか〜！ https://t.co/fFbfJeRfIJ https://t.co/SSYMvpgZnb",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1933089398582837259/photo/1",
            "indices" : [
              "43",
              "66"
            ],
            "url" : "https://t.co/SSYMvpgZnb",
            "media_url" : "http://pbs.twimg.com/media/GtO2j5wbcAEl6x2.jpg",
            "id_str" : "1933089392987697153",
            "id" : "1933089392987697153",
            "media_url_https" : "https://pbs.twimg.com/media/GtO2j5wbcAEl6x2.jpg",
            "sizes" : {
              "large" : {
                "w" : "1422",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "833",
                "h" : "1200",
                "resize" : "fit"
              },
              "small" : {
                "w" : "472",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/SSYMvpgZnb"
          },
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1933089398582837259/photo/1",
            "indices" : [
              "43",
              "66"
            ],
            "url" : "https://t.co/SSYMvpgZnb",
            "media_url" : "http://pbs.twimg.com/media/GtO2j6-aMAANT6K.jpg",
            "id_str" : "1933089393314770944",
            "id" : "1933089393314770944",
            "media_url_https" : "https://pbs.twimg.com/media/GtO2j6-aMAANT6K.jpg",
            "sizes" : {
              "large" : {
                "w" : "1422",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "833",
                "h" : "1200",
                "resize" : "fit"
              },
              "small" : {
                "w" : "472",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/SSYMvpgZnb"
          },
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1933089398582837259/photo/1",
            "indices" : [
              "43",
              "66"
            ],
            "url" : "https://t.co/SSYMvpgZnb",
            "media_url" : "http://pbs.twimg.com/media/GtO2j-TbIAAkTnO.jpg",
            "id_str" : "1933089394208219136",
            "id" : "1933089394208219136",
            "media_url_https" : "https://pbs.twimg.com/media/GtO2j-TbIAAkTnO.jpg",
            "sizes" : {
              "small" : {
                "w" : "472",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1422",
                "h" : "2048",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "833",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/SSYMvpgZnb"
          },
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1933089398582837259/photo/1",
            "indices" : [
              "43",
              "66"
            ],
            "url" : "https://t.co/SSYMvpgZnb",
            "media_url" : "http://pbs.twimg.com/media/GtO2j_jbQAEkeB3.jpg",
            "id_str" : "1933089394543771649",
            "id" : "1933089394543771649",
            "media_url_https" : "https://pbs.twimg.com/media/GtO2j_jbQAEkeB3.jpg",
            "sizes" : {
              "large" : {
                "w" : "2048",
                "h" : "1422",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "833",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "472",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/SSYMvpgZnb"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1933033396034515005"
          ],
          "editableUntil" : "2025-06-12T06:27:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "2",
      "id_str" : "1933033396034515005",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1933033396034515005",
      "created_at" : "Thu Jun 12 05:27:30 +0000 2025",
      "favorited" : false,
      "full_text" : "my PCがSDカードを認識しなくなった。キーボードも壊れてるし、今年の夏こそPC買うぞ！！！！！\n(去年の夏も言ってた)",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1932979709438239058"
          ],
          "editableUntil" : "2025-06-12T02:54:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "2",
      "id_str" : "1932979709438239058",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1932979709438239058",
      "created_at" : "Thu Jun 12 01:54:10 +0000 2025",
      "favorited" : false,
      "full_text" : "この時間に起きてしまってショック。勉強したかった。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1932783942811418627"
          ],
          "editableUntil" : "2025-06-11T13:56:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "32"
      ],
      "favorite_count" : "0",
      "id_str" : "1932783942811418627",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1932783942811418627",
      "created_at" : "Wed Jun 11 12:56:16 +0000 2025",
      "favorited" : false,
      "full_text" : "着実にコツコツポンコツポイントを貯め続けています。\nやめたい()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1932783553785573419"
          ],
          "editableUntil" : "2025-06-11T13:54:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "4",
      "id_str" : "1932783553785573419",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1932783553785573419",
      "created_at" : "Wed Jun 11 12:54:43 +0000 2025",
      "favorited" : false,
      "full_text" : "買った浴衣届いたからウキウキで着てたら、指がみそ汁に引っかかってこぼしちゃった🥲",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1932727282470396242"
          ],
          "editableUntil" : "2025-06-11T10:11:07.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "44"
      ],
      "favorite_count" : "0",
      "id_str" : "1932727282470396242",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1932727282470396242",
      "created_at" : "Wed Jun 11 09:11:07 +0000 2025",
      "favorited" : false,
      "full_text" : "ああいう人たちは私にとってはかなりこわい人たちだし、先生もっといっぱい怒っちゃって欲しい",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1932571016196444409"
          ],
          "editableUntil" : "2025-06-10T23:50:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "71"
      ],
      "favorite_count" : "2",
      "id_str" : "1932571016196444409",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1932571016196444409",
      "created_at" : "Tue Jun 10 22:50:10 +0000 2025",
      "favorited" : false,
      "full_text" : "私実は、音沙汰が奏でる音色がめっちゃ好きで。だから、あなたが思い思いに奏でる音沙汰をもっと聞かせて！\n(訳:お願いだから反応してください💩💩)",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1932431218450305298"
          ],
          "editableUntil" : "2025-06-10T14:34:39.971Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Splatoon（スプラトゥーン）",
            "screen_name" : "SplatoonJP",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "2888006497",
            "id" : "2888006497"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1932431218450305298",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1932431218450305298",
      "created_at" : "Tue Jun 10 13:34:39 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @SplatoonJP: シリーズ初のスピンオフタイトル『スプラトゥーン レイダース』が発表されたぞ！\n謎多き「ウズシオ諸島」で新たな主人公「メカニック」がすりみ連合と冒険を繰り広げるようだ。\nNintendo Switch 2 の専用ソフトとして鋭意開発中……もとい研究…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1932068885106442347"
          ],
          "editableUntil" : "2025-06-09T14:34:52.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "46"
      ],
      "favorite_count" : "4",
      "id_str" : "1932068885106442347",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1932068885106442347",
      "created_at" : "Mon Jun 09 13:34:52 +0000 2025",
      "favorited" : false,
      "full_text" : "最近中学時代の友達を電車で見かけることが多い。もちろん話しかけることなんてしないしできない。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1931179012627595288"
          ],
          "editableUntil" : "2025-06-07T03:38:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "36"
      ],
      "favorite_count" : "2",
      "id_str" : "1931179012627595288",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1931179012627595288",
      "created_at" : "Sat Jun 07 02:38:50 +0000 2025",
      "favorited" : false,
      "full_text" : "Switch2は、特にポケモンSVの変化がすごい。画質とスピードに感動。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1931178670435303571"
          ],
          "editableUntil" : "2025-06-07T03:37:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "0",
      "id_str" : "1931178670435303571",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1931178670435303571",
      "created_at" : "Sat Jun 07 02:37:29 +0000 2025",
      "favorited" : false,
      "full_text" : "Switch2やりすぎて、元々負傷してた親指がさらに痛い…。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1930892882522816605"
          ],
          "editableUntil" : "2025-06-06T08:41:52.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "33"
      ],
      "favorite_count" : "0",
      "id_str" : "1930892882522816605",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1930892882522816605",
      "created_at" : "Fri Jun 06 07:41:52 +0000 2025",
      "favorited" : false,
      "full_text" : "マリカワールドのダウンロードはやくおわれ〜！！あと1時間〜(？！)",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1930649066825982228"
          ],
          "editableUntil" : "2025-06-05T16:33:01.913Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "いな",
            "screen_name" : "ina_uec24",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "1771568167615414272",
            "id" : "1771568167615414272"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "0",
      "id_str" : "1930649066825982228",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1930649066825982228",
      "created_at" : "Thu Jun 05 15:33:01 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @ina_uec24: 一生勉強一生青春。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1930616307982180712"
          ],
          "editableUntil" : "2025-06-05T14:22:51.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1930616307982180712/photo/1",
            "indices" : [
              "15",
              "38"
            ],
            "url" : "https://t.co/ty8EfDI1Xp",
            "media_url" : "http://pbs.twimg.com/media/GsrtSvra8AA5zV6.jpg",
            "id_str" : "1930616296573693952",
            "id" : "1930616296573693952",
            "media_url_https" : "https://pbs.twimg.com/media/GsrtSvra8AA5zV6.jpg",
            "sizes" : {
              "large" : {
                "w" : "1823",
                "h" : "1367",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/ty8EfDI1Xp"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "5",
      "id_str" : "1930616307982180712",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1930616307982180712",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jun 05 13:22:51 +0000 2025",
      "favorited" : false,
      "full_text" : "ダイエットは明日からにします https://t.co/ty8EfDI1Xp",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1930616307982180712/photo/1",
            "indices" : [
              "15",
              "38"
            ],
            "url" : "https://t.co/ty8EfDI1Xp",
            "media_url" : "http://pbs.twimg.com/media/GsrtSvra8AA5zV6.jpg",
            "id_str" : "1930616296573693952",
            "id" : "1930616296573693952",
            "media_url_https" : "https://pbs.twimg.com/media/GsrtSvra8AA5zV6.jpg",
            "sizes" : {
              "large" : {
                "w" : "1823",
                "h" : "1367",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "900",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/ty8EfDI1Xp"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1930602604070916394"
          ],
          "editableUntil" : "2025-06-05T13:28:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "75"
      ],
      "favorite_count" : "4",
      "id_str" : "1930602604070916394",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1930602604070916394",
      "created_at" : "Thu Jun 05 12:28:24 +0000 2025",
      "favorited" : false,
      "full_text" : "途中でドン引かれるほどの\n　　†キ✫チ✥ゲ✥解✫放†\nしたのに、見た感じだと普通に接してくれる人たちばかりで本当にありがとうございます。気をつけます。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1930436707314479127"
          ],
          "editableUntil" : "2025-06-05T02:29:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "1",
      "id_str" : "1930436707314479127",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1930436707314479127",
      "created_at" : "Thu Jun 05 01:29:11 +0000 2025",
      "favorited" : false,
      "full_text" : "やばい！フィルム現像のとき\n「このフィルム20年以上前に期限切れてるんすよ〜」っていうの忘れた〜！どうなっちゃう〜？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1930425690350072025"
          ],
          "editableUntil" : "2025-06-05T01:45:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "27"
      ],
      "favorite_count" : "1",
      "id_str" : "1930425690350072025",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1930425690350072025",
      "created_at" : "Thu Jun 05 00:45:24 +0000 2025",
      "favorited" : false,
      "full_text" : "プロ通は自己採10点です。来年もがんばる💪🔥🦾🔥💪🔥🦾",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1930425395679244385"
          ],
          "editableUntil" : "2025-06-05T01:44:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "27"
      ],
      "favorite_count" : "0",
      "id_str" : "1930425395679244385",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1930425395679244385",
      "created_at" : "Thu Jun 05 00:44:14 +0000 2025",
      "favorited" : false,
      "full_text" : "今日の級審査の対策、火曜のプロ通くらいなんにもしてない",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1930271255652950151"
          ],
          "editableUntil" : "2025-06-04T15:31:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "66"
      ],
      "favorite_count" : "1",
      "id_str" : "1930271255652950151",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1930271255652950151",
      "created_at" : "Wed Jun 04 14:31:44 +0000 2025",
      "favorited" : false,
      "full_text" : "食神の週替わりとか期間限定とか食べたいってなるんだけど結局行かないのよね…。なんなら去年3回しか行ってないもんな…。行きたいなあ…。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1929918922939347480"
          ],
          "editableUntil" : "2025-06-03T16:11:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1929918922939347480/photo/1",
            "indices" : [
              "27",
              "50"
            ],
            "url" : "https://t.co/tnOaySpZxM",
            "media_url" : "http://pbs.twimg.com/media/GshzCIJasAEP19C.jpg",
            "id_str" : "1929918920712171521",
            "id" : "1929918920712171521",
            "media_url_https" : "https://pbs.twimg.com/media/GshzCIJasAEP19C.jpg",
            "sizes" : {
              "large" : {
                "w" : "554",
                "h" : "554",
                "resize" : "fit"
              },
              "small" : {
                "w" : "554",
                "h" : "554",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "554",
                "h" : "554",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/tnOaySpZxM"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "50"
      ],
      "favorite_count" : "1",
      "id_str" : "1929918922939347480",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1929918922939347480",
      "possibly_sensitive" : false,
      "created_at" : "Tue Jun 03 15:11:42 +0000 2025",
      "favorited" : false,
      "full_text" : "今日擦りむいたところ痛すぎてシャワーのときずっとこれ https://t.co/tnOaySpZxM",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1929918922939347480/photo/1",
            "indices" : [
              "27",
              "50"
            ],
            "url" : "https://t.co/tnOaySpZxM",
            "media_url" : "http://pbs.twimg.com/media/GshzCIJasAEP19C.jpg",
            "id_str" : "1929918920712171521",
            "id" : "1929918920712171521",
            "media_url_https" : "https://pbs.twimg.com/media/GshzCIJasAEP19C.jpg",
            "sizes" : {
              "large" : {
                "w" : "554",
                "h" : "554",
                "resize" : "fit"
              },
              "small" : {
                "w" : "554",
                "h" : "554",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "554",
                "h" : "554",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/tnOaySpZxM"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1929467698674549181"
          ],
          "editableUntil" : "2025-06-02T10:18:41.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "1",
      "id_str" : "1929467698674549181",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1929467698674549181",
      "created_at" : "Mon Jun 02 09:18:41 +0000 2025",
      "favorited" : false,
      "full_text" : "一瞬でポテチ1袋を全部食べちゃいそう……。途中で食べるのやめようと思って縛る用の輪ゴムまで買ったのに……",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1929178990163427472"
          ],
          "editableUntil" : "2025-06-01T15:11:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "74"
      ],
      "favorite_count" : "1",
      "id_str" : "1929178990163427472",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1929178990163427472",
      "created_at" : "Sun Jun 01 14:11:28 +0000 2025",
      "favorited" : false,
      "full_text" : "ちなみに弟に私の通ってる大学名聞いたら\n「東京電機d…いや、電気通信大学だ！！！」ってギリギリ及第点でもはや意外ですらある。全く言えないと思ってた。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1929162707984400760"
          ],
          "editableUntil" : "2025-06-01T14:06:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "5",
      "id_str" : "1929162707984400760",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1929162707984400760",
      "created_at" : "Sun Jun 01 13:06:46 +0000 2025",
      "favorited" : false,
      "full_text" : "弟に「お前通ってるとこ国立でも私立でもない大学だととおもってたwww理系国立すごいwww」って今更言われたんだが()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1929113040076648860"
          ],
          "editableUntil" : "2025-06-01T10:49:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "0",
      "id_str" : "1929113040076648860",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1929113040076648860",
      "created_at" : "Sun Jun 01 09:49:24 +0000 2025",
      "favorited" : false,
      "full_text" : "まってプロ通小テスト解説今からまとめて見てるけど、地味に時間かかるやつやん。なんかマナビス思い出すわ。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1929087423713260026"
          ],
          "editableUntil" : "2025-06-01T09:07:37.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "17"
      ],
      "favorite_count" : "1",
      "id_str" : "1929087423713260026",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1929087423713260026",
      "created_at" : "Sun Jun 01 08:07:37 +0000 2025",
      "favorited" : false,
      "full_text" : "この世界は分からないことだらけだ。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1928857932051132443"
          ],
          "editableUntil" : "2025-05-31T17:55:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "41"
      ],
      "favorite_count" : "0",
      "id_str" : "1928857932051132443",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1928857932051132443",
      "created_at" : "Sat May 31 16:55:42 +0000 2025",
      "favorited" : false,
      "full_text" : "あっぶね23:59か良かった。\nけどね、テスト勉強全くしてないことは本当にやばやば",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1928857143010304177"
          ],
          "editableUntil" : "2025-05-31T17:52:33.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "id_str" : "1928857143010304177",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1928857143010304177",
      "created_at" : "Sat May 31 16:52:33 +0000 2025",
      "favorited" : false,
      "full_text" : "そいえばプロ通やってないけど、締め切りが日曜0:00だったらもう終わり()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1928803132709982282"
          ],
          "editableUntil" : "2025-05-31T14:17:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "26"
      ],
      "favorite_count" : "0",
      "id_str" : "1928803132709982282",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1928803132709982282",
      "created_at" : "Sat May 31 13:17:56 +0000 2025",
      "favorited" : false,
      "full_text" : "源さん素晴らしかった…！まさかのコラボもすごかった笑",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1928681730002555341"
          ],
          "editableUntil" : "2025-05-31T06:15:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/PcebYphrck",
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1928668148661678373",
            "display_url" : "x.com/joyjoy_7shichi…",
            "indices" : [
              "20",
              "43"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "0",
      "id_str" : "1928681730002555341",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1928681730002555341",
      "possibly_sensitive" : false,
      "created_at" : "Sat May 31 05:15:32 +0000 2025",
      "favorited" : false,
      "full_text" : "さっき茹でたパスタが弟の友達に渡る神回 https://t.co/PcebYphrck",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1928668148661678373"
          ],
          "editableUntil" : "2025-05-31T05:21:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "1",
      "id_str" : "1928668148661678373",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1928668148661678373",
      "created_at" : "Sat May 31 04:21:34 +0000 2025",
      "favorited" : false,
      "full_text" : "パスタ茹でたら、母に、\n「ばぶちゃんは火と仲良くなるところから始めましょう」\nって言われてしまった…()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1928658017945338219"
          ],
          "editableUntil" : "2025-05-31T04:41:18.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "41"
      ],
      "favorite_count" : "1",
      "id_str" : "1928658017945338219",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1928658017945338219",
      "created_at" : "Sat May 31 03:41:18 +0000 2025",
      "favorited" : false,
      "full_text" : "ディアマイベイビー観てた母親が、私のことばぶちゃんって呼び始めたのはマジで何？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1928113546707062944"
          ],
          "editableUntil" : "2025-05-29T16:37:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "0",
      "id_str" : "1928113546707062944",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1928113546707062944",
      "created_at" : "Thu May 29 15:37:46 +0000 2025",
      "favorited" : false,
      "full_text" : "ちなみに母もライブのチケットばんばか当ててる。星野源のライブとか3連番当てたりしてる。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1928113323016323549"
          ],
          "editableUntil" : "2025-05-29T16:36:53.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1928113323016323549/photo/1",
            "indices" : [
              "41",
              "64"
            ],
            "url" : "https://t.co/KNW8fc6cKl",
            "media_url" : "http://pbs.twimg.com/media/GsII2CNaUAEtHvr.jpg",
            "id_str" : "1928113314867073025",
            "id" : "1928113314867073025",
            "media_url_https" : "https://pbs.twimg.com/media/GsII2CNaUAEtHvr.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1080",
                "h" : "1080",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1080",
                "h" : "1080",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/KNW8fc6cKl"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "64"
      ],
      "favorite_count" : "1",
      "id_str" : "1928113323016323549",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1928113323016323549",
      "possibly_sensitive" : false,
      "created_at" : "Thu May 29 15:36:53 +0000 2025",
      "favorited" : false,
      "full_text" : "2つSwitch2を当選させた実績を持つお父様に引いていただいた。さすがすぎる。 https://t.co/KNW8fc6cKl",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1928113323016323549/photo/1",
            "indices" : [
              "41",
              "64"
            ],
            "url" : "https://t.co/KNW8fc6cKl",
            "media_url" : "http://pbs.twimg.com/media/GsII2CNaUAEtHvr.jpg",
            "id_str" : "1928113314867073025",
            "id" : "1928113314867073025",
            "media_url_https" : "https://pbs.twimg.com/media/GsII2CNaUAEtHvr.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1080",
                "h" : "1080",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1080",
                "h" : "1080",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/KNW8fc6cKl"
          },
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1928113323016323549/photo/1",
            "indices" : [
              "41",
              "64"
            ],
            "url" : "https://t.co/KNW8fc6cKl",
            "media_url" : "http://pbs.twimg.com/media/GsII2HYaUAQbjsS.jpg",
            "id_str" : "1928113316255387652",
            "id" : "1928113316255387652",
            "media_url_https" : "https://pbs.twimg.com/media/GsII2HYaUAQbjsS.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1080",
                "h" : "1080",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1080",
                "h" : "1080",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/KNW8fc6cKl"
          },
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1928113323016323549/photo/1",
            "indices" : [
              "41",
              "64"
            ],
            "url" : "https://t.co/KNW8fc6cKl",
            "media_url" : "http://pbs.twimg.com/media/GsII2QcaUAEc2Nu.jpg",
            "id_str" : "1928113318688083969",
            "id" : "1928113318688083969",
            "media_url_https" : "https://pbs.twimg.com/media/GsII2QcaUAEc2Nu.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "680",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1080",
                "h" : "1080",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1080",
                "h" : "1080",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/KNW8fc6cKl"
          },
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1928113323016323549/photo/1",
            "indices" : [
              "41",
              "64"
            ],
            "url" : "https://t.co/KNW8fc6cKl",
            "media_url" : "http://pbs.twimg.com/media/GsII2W3aUAA7euN.jpg",
            "id_str" : "1928113320411942912",
            "id" : "1928113320411942912",
            "media_url_https" : "https://pbs.twimg.com/media/GsII2W3aUAA7euN.jpg",
            "sizes" : {
              "large" : {
                "w" : "1055",
                "h" : "1522",
                "resize" : "fit"
              },
              "small" : {
                "w" : "471",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "832",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/KNW8fc6cKl"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1927960479151902871"
          ],
          "editableUntil" : "2025-05-29T06:29:32.660Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "琥珀",
            "screen_name" : "mezase_kenzenn",
            "indices" : [
              "3",
              "18"
            ],
            "id_str" : "1570697638068252674",
            "id" : "1570697638068252674"
          }
        ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/mezase_kenzenn/status/1927922922477277442/photo/1",
            "source_status_id" : "1927922922477277442",
            "indices" : [
              "52",
              "75"
            ],
            "url" : "https://t.co/uyqE24PBrX",
            "media_url" : "http://pbs.twimg.com/media/GsFbrfybAAAbzsy.jpg",
            "id_str" : "1927922918316769280",
            "source_user_id" : "1570697638068252674",
            "id" : "1927922918316769280",
            "media_url_https" : "https://pbs.twimg.com/media/GsFbrfybAAAbzsy.jpg",
            "source_user_id_str" : "1570697638068252674",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1100",
                "h" : "509",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "315",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1100",
                "h" : "509",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1927922922477277442",
            "display_url" : "pic.x.com/uyqE24PBrX"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "75"
      ],
      "favorite_count" : "0",
      "id_str" : "1927960479151902871",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1927960479151902871",
      "possibly_sensitive" : false,
      "created_at" : "Thu May 29 05:29:32 +0000 2025",
      "favorited" : false,
      "full_text" : "RT @mezase_kenzenn: 【ぼっちを56すタイプの先生の緑黄色社会】\n\nペアになって〜〜 https://t.co/uyqE24PBrX",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/mezase_kenzenn/status/1927922922477277442/photo/1",
            "source_status_id" : "1927922922477277442",
            "indices" : [
              "52",
              "75"
            ],
            "url" : "https://t.co/uyqE24PBrX",
            "media_url" : "http://pbs.twimg.com/media/GsFbrfybAAAbzsy.jpg",
            "id_str" : "1927922918316769280",
            "source_user_id" : "1570697638068252674",
            "id" : "1927922918316769280",
            "media_url_https" : "https://pbs.twimg.com/media/GsFbrfybAAAbzsy.jpg",
            "source_user_id_str" : "1570697638068252674",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1100",
                "h" : "509",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "315",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1100",
                "h" : "509",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "source_status_id_str" : "1927922922477277442",
            "display_url" : "pic.x.com/uyqE24PBrX"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1927745554961907983"
          ],
          "editableUntil" : "2025-05-28T16:15:30.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1927745554961907983/photo/1",
            "indices" : [
              "44",
              "67"
            ],
            "url" : "https://t.co/6fFMoJFx67",
            "media_url" : "http://pbs.twimg.com/media/GsC6XZna8AANItf.jpg",
            "id_str" : "1927745551690559488",
            "id" : "1927745551690559488",
            "media_url_https" : "https://pbs.twimg.com/media/GsC6XZna8AANItf.jpg",
            "sizes" : {
              "large" : {
                "w" : "922",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "306",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "540",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/6fFMoJFx67"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "67"
      ],
      "favorite_count" : "0",
      "id_str" : "1927745554961907983",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1927745554961907983",
      "possibly_sensitive" : false,
      "created_at" : "Wed May 28 15:15:30 +0000 2025",
      "favorited" : false,
      "full_text" : "明日新弾発表らしいけど今回神引きしすぎたので期待できません()(画像も一例でしかない) https://t.co/6fFMoJFx67",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1927745554961907983/photo/1",
            "indices" : [
              "44",
              "67"
            ],
            "url" : "https://t.co/6fFMoJFx67",
            "media_url" : "http://pbs.twimg.com/media/GsC6XZna8AANItf.jpg",
            "id_str" : "1927745551690559488",
            "id" : "1927745551690559488",
            "media_url_https" : "https://pbs.twimg.com/media/GsC6XZna8AANItf.jpg",
            "sizes" : {
              "large" : {
                "w" : "922",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "306",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "540",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/6fFMoJFx67"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1927571744253997344"
          ],
          "editableUntil" : "2025-05-28T04:44:51.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "1",
      "id_str" : "1927571744253997344",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1927571744253997344",
      "created_at" : "Wed May 28 03:44:51 +0000 2025",
      "favorited" : false,
      "full_text" : "生協近くの机の溝を許してはいけない。今日も尊い割り箸がお亡くなりになった()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1927494105090732391"
          ],
          "editableUntil" : "2025-05-27T23:36:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "24"
      ],
      "favorite_count" : "0",
      "id_str" : "1927494105090732391",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1927494105090732391",
      "created_at" : "Tue May 27 22:36:20 +0000 2025",
      "favorited" : false,
      "full_text" : "小テスト合計20点で顔始まり。\nまーじで気分良い",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1926660231657816400"
          ],
          "editableUntil" : "2025-05-25T16:22:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "0",
      "id_str" : "1926660231657816400",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1926660231657816400",
      "created_at" : "Sun May 25 15:22:49 +0000 2025",
      "favorited" : false,
      "full_text" : "そりゃまあ、未開の僻地の扱いには困るわな()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1926660179099050250"
          ],
          "editableUntil" : "2025-05-25T16:22:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "0",
      "id_str" : "1926660179099050250",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1926660179099050250",
      "created_at" : "Sun May 25 15:22:36 +0000 2025",
      "favorited" : false,
      "full_text" : "気づいちゃったんだけど、電通大だけ、電通\"大\"ってなってるんだよな笑",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1926573534773428268"
          ],
          "editableUntil" : "2025-05-25T10:38:19.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "15"
      ],
      "favorite_count" : "1",
      "id_str" : "1926573534773428268",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1926573534773428268",
      "created_at" : "Sun May 25 09:38:19 +0000 2025",
      "favorited" : false,
      "full_text" : "オープンラボめちゃ楽しかった！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1926475383878099341"
          ],
          "editableUntil" : "2025-05-25T04:08:18.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "27"
      ],
      "favorite_count" : "0",
      "id_str" : "1926475383878099341",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1926475383878099341",
      "created_at" : "Sun May 25 03:08:18 +0000 2025",
      "favorited" : false,
      "full_text" : "他大の女性たちの雰囲気に飲まれない女に私は、なりたい。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1926404039756910852"
          ],
          "editableUntil" : "2025-05-24T23:24:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "16"
      ],
      "favorite_count" : "0",
      "id_str" : "1926404039756910852",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1926404039756910852",
      "created_at" : "Sat May 24 22:24:48 +0000 2025",
      "favorited" : false,
      "full_text" : "もしかして:\n今日　めっちゃ寒い",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1926246085137252420"
          ],
          "editableUntil" : "2025-05-24T12:57:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "54"
      ],
      "favorite_count" : "0",
      "id_str" : "1926246085137252420",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1926246085137252420",
      "created_at" : "Sat May 24 11:57:09 +0000 2025",
      "favorited" : false,
      "full_text" : "スポーツ会場(私は出場しない)と、オープンラボどちらにも適する服装ってなんだ〜〜〜？？？考えすぎ〜〜〜？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1926181573419769876"
          ],
          "editableUntil" : "2025-05-24T08:40:48.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "15"
      ],
      "favorite_count" : "0",
      "id_str" : "1926181573419769876",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1926181573419769876",
      "created_at" : "Sat May 24 07:40:48 +0000 2025",
      "favorited" : false,
      "full_text" : "それはそうと桃フラッペ飲みたい",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1926181014046425485"
          ],
          "editableUntil" : "2025-05-24T08:38:35.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "3",
      "id_str" : "1926181014046425485",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1926181014046425485",
      "created_at" : "Sat May 24 07:38:35 +0000 2025",
      "favorited" : false,
      "full_text" : "小学生の時の友達とはマジで趣味合わなすぎて苦労したな。\nなんだよアイカツごっこって…モデル歩き練習してどうすんだよ…って思ってた。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1926180273307156702"
          ],
          "editableUntil" : "2025-05-24T08:35:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "68"
      ],
      "favorite_count" : "0",
      "id_str" : "1926180273307156702",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1926180273307156702",
      "created_at" : "Sat May 24 07:35:38 +0000 2025",
      "favorited" : false,
      "full_text" : "ちゃおとか友達に読まされたけど、最初の人間関係のあらすじの部分読むのが大変すぎて、結局フミちゃん主人公verの妖怪ウォッチしか読んでない",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1926070330189029862"
          ],
          "editableUntil" : "2025-05-24T01:18:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "21"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1926070132155019462",
      "id_str" : "1926070330189029862",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1926070330189029862",
      "in_reply_to_status_id" : "1926070132155019462",
      "created_at" : "Sat May 24 00:18:46 +0000 2025",
      "favorited" : false,
      "full_text" : "で、この鳥さんはなんて種類の子なの？？？？",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1926070132155019462"
          ],
          "editableUntil" : "2025-05-24T01:17:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1926070132155019462/photo/1",
            "indices" : [
              "26",
              "49"
            ],
            "url" : "https://t.co/00HSsrlzSg",
            "media_url" : "http://pbs.twimg.com/media/GrrGkktW4AAvblW.jpg",
            "id_str" : "1926070122285817856",
            "id" : "1926070122285817856",
            "media_url_https" : "https://pbs.twimg.com/media/GrrGkktW4AAvblW.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "453",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "800",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1365",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/00HSsrlzSg"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "4",
      "id_str" : "1926070132155019462",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1926070132155019462",
      "possibly_sensitive" : false,
      "created_at" : "Sat May 24 00:17:58 +0000 2025",
      "favorited" : false,
      "full_text" : "ベランダに隠れつつお手軽バードウォッチングするなど https://t.co/00HSsrlzSg",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1926070132155019462/photo/1",
            "indices" : [
              "26",
              "49"
            ],
            "url" : "https://t.co/00HSsrlzSg",
            "media_url" : "http://pbs.twimg.com/media/GrrGkktW4AAvblW.jpg",
            "id_str" : "1926070122285817856",
            "id" : "1926070122285817856",
            "media_url_https" : "https://pbs.twimg.com/media/GrrGkktW4AAvblW.jpg",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "453",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "800",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1365",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/00HSsrlzSg"
          },
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1926070132155019462/photo/1",
            "indices" : [
              "26",
              "49"
            ],
            "url" : "https://t.co/00HSsrlzSg",
            "media_url" : "http://pbs.twimg.com/media/GrrGk-eW8AEzZ4S.jpg",
            "id_str" : "1926070129202229249",
            "id" : "1926070129202229249",
            "media_url_https" : "https://pbs.twimg.com/media/GrrGk-eW8AEzZ4S.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "800",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "453",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "2048",
                "h" : "1365",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/00HSsrlzSg"
          },
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1926070132155019462/photo/1",
            "indices" : [
              "26",
              "49"
            ],
            "url" : "https://t.co/00HSsrlzSg",
            "media_url" : "http://pbs.twimg.com/media/GrrGkqyW8AEe4Uy.jpg",
            "id_str" : "1926070123917406209",
            "id" : "1926070123917406209",
            "media_url_https" : "https://pbs.twimg.com/media/GrrGkqyW8AEe4Uy.jpg",
            "sizes" : {
              "medium" : {
                "w" : "800",
                "h" : "1200",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1080",
                "h" : "1620",
                "resize" : "fit"
              },
              "small" : {
                "w" : "453",
                "h" : "680",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/00HSsrlzSg"
          },
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1926070132155019462/photo/1",
            "indices" : [
              "26",
              "49"
            ],
            "url" : "https://t.co/00HSsrlzSg",
            "media_url" : "http://pbs.twimg.com/media/GrrGk9gWsAAG05l.jpg",
            "id_str" : "1926070128942166016",
            "id" : "1926070128942166016",
            "media_url_https" : "https://pbs.twimg.com/media/GrrGk9gWsAAG05l.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "453",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1024",
                "h" : "682",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1024",
                "h" : "682",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/00HSsrlzSg"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1925824555177627654"
          ],
          "editableUntil" : "2025-05-23T09:02:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "琥珀",
            "screen_name" : "mezase_kenzenn",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1570697638068252674",
            "id" : "1570697638068252674"
          },
          {
            "name" : "ススキ",
            "screen_name" : "susuki_uec24",
            "indices" : [
              "16",
              "29"
            ],
            "id_str" : "1774432006467878912",
            "id" : "1774432006467878912"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "47"
      ],
      "favorite_count" : "3",
      "in_reply_to_status_id_str" : "1925824053027172855",
      "id_str" : "1925824555177627654",
      "in_reply_to_user_id" : "1570697638068252674",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1925824555177627654",
      "in_reply_to_status_id" : "1925824053027172855",
      "created_at" : "Fri May 23 08:02:08 +0000 2025",
      "favorited" : false,
      "full_text" : "@mezase_kenzenn @susuki_uec24 残念ながら一瞬で買い手決まりました",
      "lang" : "ja",
      "in_reply_to_screen_name" : "mezase_kenzenn",
      "in_reply_to_user_id_str" : "1570697638068252674"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1925817841476890756"
          ],
          "editableUntil" : "2025-05-23T08:35:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/kci3f071k9",
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1918275259989676378",
            "display_url" : "x.com/joyjoy_7shichi…",
            "indices" : [
              "41",
              "64"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "64"
      ],
      "favorite_count" : "6",
      "id_str" : "1925817841476890756",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1925817841476890756",
      "possibly_sensitive" : false,
      "created_at" : "Fri May 23 07:35:28 +0000 2025",
      "favorited" : false,
      "full_text" : "また当たったー！？！？\n恐れてはないけど恐れていたことが現実になりました！？！？ https://t.co/kci3f071k9",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1925558839044350221"
          ],
          "editableUntil" : "2025-05-22T15:26:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "琥珀",
            "screen_name" : "mezase_kenzenn",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "1570697638068252674",
            "id" : "1570697638068252674"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "50"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1925557948878893116",
      "id_str" : "1925558839044350221",
      "in_reply_to_user_id" : "1570697638068252674",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1925558839044350221",
      "in_reply_to_status_id" : "1925557948878893116",
      "created_at" : "Thu May 22 14:26:17 +0000 2025",
      "favorited" : false,
      "full_text" : "@mezase_kenzenn ゆーて、あの顔でこのツイート…！？とか、たまに変なRT流れるよねとか",
      "lang" : "ja",
      "in_reply_to_screen_name" : "mezase_kenzenn",
      "in_reply_to_user_id_str" : "1570697638068252674"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1925549873799278805"
          ],
          "editableUntil" : "2025-05-22T14:50:39.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/sR825leEa8",
            "expanded_url" : "https://x.com/nuko0655/status/1925483196948549753",
            "display_url" : "x.com/nuko0655/statu…",
            "indices" : [
              "16",
              "39"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "7",
      "id_str" : "1925549873799278805",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1925549873799278805",
      "possibly_sensitive" : false,
      "created_at" : "Thu May 22 13:50:39 +0000 2025",
      "favorited" : false,
      "full_text" : "個人的には褒めたの体感4割() https://t.co/sR825leEa8",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1925397296289816800"
          ],
          "editableUntil" : "2025-05-22T04:44:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "3",
      "id_str" : "1925397296289816800",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1925397296289816800",
      "created_at" : "Thu May 22 03:44:22 +0000 2025",
      "favorited" : false,
      "full_text" : "今の時間帯の電車空いてて良いね！年下JKと年上お姉さんのどっちの隣に座るかも選べちゃうもんね！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1925307329622524087"
          ],
          "editableUntil" : "2025-05-21T22:46:52.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "0",
      "id_str" : "1925307329622524087",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1925307329622524087",
      "created_at" : "Wed May 21 21:46:52 +0000 2025",
      "favorited" : false,
      "full_text" : "明日木曜日だと思って起きたら、火曜日だったとかいう大悪夢見て、心臓バックバク",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1924958662688440636"
          ],
          "editableUntil" : "2025-05-20T23:41:23.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "1",
      "id_str" : "1924958662688440636",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1924958662688440636",
      "created_at" : "Tue May 20 22:41:23 +0000 2025",
      "favorited" : false,
      "full_text" : "科学史小テスト、単位を答えに含めちゃダメなのか…これで8点なのちょっと不満だなぁ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1924951037389242434"
          ],
          "editableUntil" : "2025-05-20T23:11:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "58"
      ],
      "favorite_count" : "1",
      "id_str" : "1924951037389242434",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1924951037389242434",
      "created_at" : "Tue May 20 22:11:05 +0000 2025",
      "favorited" : false,
      "full_text" : "毎年この時期になるとうちのジューンベリーに鳥さんがわらわらの飛び込んでくる。今度おうちバードウォッチングしよっかな。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1924757256748552533"
          ],
          "editableUntil" : "2025-05-20T10:21:04.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "26"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1924591100884607220",
      "id_str" : "1924757256748552533",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1924757256748552533",
      "in_reply_to_status_id" : "1924591100884607220",
      "created_at" : "Tue May 20 09:21:04 +0000 2025",
      "favorited" : false,
      "full_text" : "もっとおもろい展開来た笑\n普通にすごすぎて言えない笑",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1924756940900724868"
          ],
          "editableUntil" : "2025-05-20T10:19:49.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "41"
      ],
      "favorite_count" : "0",
      "id_str" : "1924756940900724868",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1924756940900724868",
      "created_at" : "Tue May 20 09:19:49 +0000 2025",
      "favorited" : false,
      "full_text" : "スライディングして熱でズボン溶けた。\nいやスポチャンでスライディングってなに？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1924591100884607220"
          ],
          "editableUntil" : "2025-05-19T23:20:50.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "0",
      "id_str" : "1924591100884607220",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1924591100884607220",
      "created_at" : "Mon May 19 22:20:50 +0000 2025",
      "favorited" : false,
      "full_text" : "地元の駅に、リュックに小太刀ぶっ刺してる人いてなんか嬉しい",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1924587485327429703"
          ],
          "editableUntil" : "2025-05-19T23:06:28.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "0",
      "id_str" : "1924587485327429703",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1924587485327429703",
      "created_at" : "Mon May 19 22:06:28 +0000 2025",
      "favorited" : false,
      "full_text" : "私がおやすみなさいしてる間に何があった？？？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1924376298157408499"
          ],
          "editableUntil" : "2025-05-19T09:07:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "1",
      "id_str" : "1924376298157408499",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1924376298157408499",
      "created_at" : "Mon May 19 08:07:17 +0000 2025",
      "favorited" : false,
      "full_text" : "今日は初めてなんじゃないかってレベルの定時帰宅をしている。なんかもう不安になってきた。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1924121284813988234"
          ],
          "editableUntil" : "2025-05-18T16:13:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "2",
      "id_str" : "1924121284813988234",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1924121284813988234",
      "created_at" : "Sun May 18 15:13:57 +0000 2025",
      "favorited" : false,
      "full_text" : "星野源あるある\n今のアルバムと14年前のアルバムの雰囲気違いすぎて風邪ひいちゃう",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1923718532581425619"
          ],
          "editableUntil" : "2025-05-17T13:33:33.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "61"
      ],
      "favorite_count" : "0",
      "id_str" : "1923718532581425619",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1923718532581425619",
      "created_at" : "Sat May 17 12:33:33 +0000 2025",
      "favorited" : false,
      "full_text" : "埼玉スーパーアリーナはさいアリ呼び派です。\nSSAはなんかカッコつけすぎだし、スーパーアリーナは長いし、たまアリはえろい。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1923717738759066096"
          ],
          "editableUntil" : "2025-05-17T13:30:24.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "1",
      "id_str" : "1923717738759066096",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1923717738759066096",
      "created_at" : "Sat May 17 12:30:24 +0000 2025",
      "favorited" : false,
      "full_text" : "まって今わかったけど来年のビバラは埼スタ周辺の屋外なのか！？！？\nそして、さいアリ改名するんか！？！？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1923696967378759767"
          ],
          "editableUntil" : "2025-05-17T12:07:52.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "0",
      "id_str" : "1923696967378759767",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1923696967378759767",
      "created_at" : "Sat May 17 11:07:52 +0000 2025",
      "favorited" : false,
      "full_text" : "点数開示が詳細になってていいなあとか思ったり。\n私は文系だから、何の教科で救われたのか分からないんだよなあ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1923417261039145285"
          ],
          "editableUntil" : "2025-05-16T17:36:25.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "1",
      "id_str" : "1923417261039145285",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1923417261039145285",
      "created_at" : "Fri May 16 16:36:25 +0000 2025",
      "favorited" : false,
      "full_text" : "同期はまだしも後輩の片特調査に片得したって回答する先輩はやばい定期(自戒)",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1923411763782959119"
          ],
          "editableUntil" : "2025-05-16T17:14:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "110"
      ],
      "favorite_count" : "2",
      "id_str" : "1923411763782959119",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1923411763782959119",
      "created_at" : "Fri May 16 16:14:34 +0000 2025",
      "favorited" : false,
      "full_text" : "最近何個かのサークルで役職を与えられたけど、自分だけ何も知らないから何もできなくて、でも他の人は忙しそうで、手伝いのやり方もわからなくて、自分にとても無力感を感じる。\nまだなって日が浅いとはいえ、どうすれば良いんだろう。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1923408392120332672"
          ],
          "editableUntil" : "2025-05-16T17:01:10.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "39"
      ],
      "favorite_count" : "0",
      "id_str" : "1923408392120332672",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1923408392120332672",
      "created_at" : "Fri May 16 16:01:10 +0000 2025",
      "favorited" : false,
      "full_text" : "私って何クラ？Bクラなのは確かだけど、複素関数論のクラス分け的に2クラ？？？🤔",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1923382772997001594"
          ],
          "editableUntil" : "2025-05-16T15:19:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "26"
      ],
      "favorite_count" : "1",
      "id_str" : "1923382772997001594",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1923382772997001594",
      "created_at" : "Fri May 16 14:19:22 +0000 2025",
      "favorited" : false,
      "full_text" : "クイズって反射神経も必要なのね。25生みんなエグいわ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1923262221896843597"
          ],
          "editableUntil" : "2025-05-16T07:20:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "68"
      ],
      "favorite_count" : "1",
      "id_str" : "1923262221896843597",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1923262221896843597",
      "created_at" : "Fri May 16 06:20:20 +0000 2025",
      "favorited" : false,
      "full_text" : "真っ昼間からするツイートではないので誰も見てないうちに消し消し。たぶんさっきのツイートは夜3時くらいが適するから、今日は夜更かしするかー",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1923190020585742627"
          ],
          "editableUntil" : "2025-05-16T02:33:26.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "0",
      "id_str" : "1923190020585742627",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1923190020585742627",
      "created_at" : "Fri May 16 01:33:26 +0000 2025",
      "favorited" : false,
      "full_text" : "眠すぎてオンデマでよかったっていうレベルの課題の進捗率()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1922950398270197921"
          ],
          "editableUntil" : "2025-05-15T10:41:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "3",
      "id_str" : "1922950398270197921",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1922950398270197921",
      "created_at" : "Thu May 15 09:41:16 +0000 2025",
      "favorited" : false,
      "full_text" : "おっしゃgithub studentの登録どね",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1922490082675569106"
          ],
          "editableUntil" : "2025-05-14T04:12:08.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "37"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1922489788860403941",
      "id_str" : "1922490082675569106",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1922490082675569106",
      "in_reply_to_status_id" : "1922489788860403941",
      "created_at" : "Wed May 14 03:12:08 +0000 2025",
      "favorited" : false,
      "full_text" : "(わざとミュートしてTLには流さずリストで避難させて見てる人達だとおもう)",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1922489788860403941"
          ],
          "editableUntil" : "2025-05-14T04:10:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1922489788860403941/photo/1",
            "indices" : [
              "11",
              "34"
            ],
            "url" : "https://t.co/5yiwqtlEwG",
            "media_url" : "http://pbs.twimg.com/media/Gq4ORdcbAAAy054.jpg",
            "id_str" : "1922489784058183680",
            "id" : "1922489784058183680",
            "media_url_https" : "https://pbs.twimg.com/media/Gq4ORdcbAAAy054.jpg",
            "sizes" : {
              "medium" : {
                "w" : "227",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "387",
                "h" : "2048",
                "resize" : "fit"
              },
              "small" : {
                "w" : "128",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/5yiwqtlEwG"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "34"
      ],
      "favorite_count" : "26",
      "id_str" : "1922489788860403941",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1922489788860403941",
      "possibly_sensitive" : false,
      "created_at" : "Wed May 14 03:10:58 +0000 2025",
      "favorited" : false,
      "full_text" : "リプ欄これでおもろい https://t.co/5yiwqtlEwG",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1922489788860403941/photo/1",
            "indices" : [
              "11",
              "34"
            ],
            "url" : "https://t.co/5yiwqtlEwG",
            "media_url" : "http://pbs.twimg.com/media/Gq4ORdcbAAAy054.jpg",
            "id_str" : "1922489784058183680",
            "id" : "1922489784058183680",
            "media_url_https" : "https://pbs.twimg.com/media/Gq4ORdcbAAAy054.jpg",
            "sizes" : {
              "medium" : {
                "w" : "227",
                "h" : "1200",
                "resize" : "fit"
              },
              "large" : {
                "w" : "387",
                "h" : "2048",
                "resize" : "fit"
              },
              "small" : {
                "w" : "128",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/5yiwqtlEwG"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1922275563219173412"
          ],
          "editableUntil" : "2025-05-13T13:59:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "18"
      ],
      "favorite_count" : "0",
      "id_str" : "1922275563219173412",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1922275563219173412",
      "created_at" : "Tue May 13 12:59:43 +0000 2025",
      "favorited" : false,
      "full_text" : "スポ演のストレッチで足痛めて本末転倒",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1921932258585264510"
          ],
          "editableUntil" : "2025-05-12T15:15:32.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "49"
      ],
      "favorite_count" : "1",
      "id_str" : "1921932258585264510",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1921932258585264510",
      "created_at" : "Mon May 12 14:15:32 +0000 2025",
      "favorited" : false,
      "full_text" : "ソースの臭いおかしいし、ヨーグルトもチーズみたいな臭いするし、お茶の味もおかしいし、副鼻腔炎最悪。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1921907763518554382"
          ],
          "editableUntil" : "2025-05-12T13:38:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "2",
      "id_str" : "1921907763518554382",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1921907763518554382",
      "created_at" : "Mon May 12 12:38:12 +0000 2025",
      "favorited" : false,
      "full_text" : "副鼻腔炎きつい。なのに、お昼のくすり飲むの忘れちゃったの。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1921894109079335011"
          ],
          "editableUntil" : "2025-05-12T12:43:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "46"
      ],
      "favorite_count" : "0",
      "id_str" : "1921894109079335011",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1921894109079335011",
      "created_at" : "Mon May 12 11:43:57 +0000 2025",
      "favorited" : false,
      "full_text" : "2週間以上前に開けたグミ(途中から袋が半開きになってた)を食べてみたらちゃんと味おかしかった",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1921202900677603726"
          ],
          "editableUntil" : "2025-05-10T14:57:20.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "46"
      ],
      "favorite_count" : "0",
      "id_str" : "1921202900677603726",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1921202900677603726",
      "created_at" : "Sat May 10 13:57:20 +0000 2025",
      "favorited" : false,
      "full_text" : "今日の家の周り治安悪すぎて()\n🏍️-_-🏍️🏍️-_-_-ﾌﾞﾛﾛﾛ🚓_-_-ﾋ-ﾟﾎﾟｰ",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1921186887714082888"
          ],
          "editableUntil" : "2025-05-10T13:53:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "51"
      ],
      "favorite_count" : "0",
      "id_str" : "1921186887714082888",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1921186887714082888",
      "created_at" : "Sat May 10 12:53:42 +0000 2025",
      "favorited" : false,
      "full_text" : "今日は4タイトル見たけど、パンスト再放送の規制対象の基準が全くわかっんねえってのが一番印象に残ってる。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1921186227526447598"
          ],
          "editableUntil" : "2025-05-10T13:51:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "22"
      ],
      "favorite_count" : "0",
      "id_str" : "1921186227526447598",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1921186227526447598",
      "created_at" : "Sat May 10 12:51:05 +0000 2025",
      "favorited" : false,
      "full_text" : "今日録り溜めてたアニメしか見てなくてまずい。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1920839362297684128"
          ],
          "editableUntil" : "2025-05-09T14:52:46.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "1",
      "id_str" : "1920839362297684128",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1920839362297684128",
      "created_at" : "Fri May 09 13:52:46 +0000 2025",
      "favorited" : false,
      "full_text" : "今日些細なことでイライラしすぎてた…。大反省。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1920495744877785149"
          ],
          "editableUntil" : "2025-05-08T16:07:21.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "id_str" : "1920495744877785149",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1920495744877785149",
      "created_at" : "Thu May 08 15:07:21 +0000 2025",
      "favorited" : false,
      "full_text" : "そろそろお母さんがTwitter見るのをやめさせたい。だって良くない趣味じゃん…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1920495514078122176"
          ],
          "editableUntil" : "2025-05-08T16:06:26.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "1",
      "id_str" : "1920495514078122176",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1920495514078122176",
      "created_at" : "Thu May 08 15:06:26 +0000 2025",
      "favorited" : false,
      "full_text" : "家に帰ったら、お母さんがTLに大沢たかおがいすぎてノイローゼになってたwww",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1920490533945745559"
          ],
          "editableUntil" : "2025-05-08T15:46:38.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "59"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1920486841930711316",
      "id_str" : "1920490533945745559",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1920490533945745559",
      "in_reply_to_status_id" : "1920486841930711316",
      "created_at" : "Thu May 08 14:46:38 +0000 2025",
      "favorited" : false,
      "full_text" : "もうぽんぽんぺいんピークを過ぎた今だからわかるが、心底腹が立ったり減ったり痛かったりしてたからそう感じた被害妄想かも…",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1920486841930711316"
          ],
          "editableUntil" : "2025-05-08T15:31:58.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1920471985525768543",
      "id_str" : "1920486841930711316",
      "in_reply_to_user_id" : "1765658836759957505",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1920486841930711316",
      "in_reply_to_status_id" : "1920471985525768543",
      "created_at" : "Thu May 08 14:31:58 +0000 2025",
      "favorited" : false,
      "full_text" : "これ水ゼリー飲んでたから覚えられてたんだろうな",
      "lang" : "ja",
      "in_reply_to_screen_name" : "joyjoy_7shichi7",
      "in_reply_to_user_id_str" : "1765658836759957505"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1920479138562908326"
          ],
          "editableUntil" : "2025-05-08T15:01:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "16"
      ],
      "favorite_count" : "0",
      "id_str" : "1920479138562908326",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1920479138562908326",
      "created_at" : "Thu May 08 14:01:22 +0000 2025",
      "favorited" : false,
      "full_text" : "待ちすぎてお腹痛くなくなってきた",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1920472110729998695"
          ],
          "editableUntil" : "2025-05-08T14:33:26.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "40"
      ],
      "favorite_count" : "0",
      "id_str" : "1920472110729998695",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1920472110729998695",
      "created_at" : "Thu May 08 13:33:26 +0000 2025",
      "favorited" : false,
      "full_text" : "こっちはお腹すきすぎて取り急ぎの水ゼリー買うくらいお腹すきすぎて、お腹痛いのに。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1920471985525768543"
          ],
          "editableUntil" : "2025-05-08T14:32:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "62"
      ],
      "favorite_count" : "3",
      "id_str" : "1920471985525768543",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1920471985525768543",
      "created_at" : "Thu May 08 13:32:56 +0000 2025",
      "favorited" : false,
      "full_text" : "できるだけ早い電車で帰ろうと思って行ったら到底乗り切れないほどの人で、元の電車に戻ったら、それを見ていたJK2人組に笑われた",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1920464004587143315"
          ],
          "editableUntil" : "2025-05-08T14:01:13.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "26"
      ],
      "favorite_count" : "0",
      "id_str" : "1920464004587143315",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1920464004587143315",
      "created_at" : "Thu May 08 13:01:13 +0000 2025",
      "favorited" : false,
      "full_text" : "お腹すきすぎて、電車でしゃがむしかないくらいお腹痛い",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1920107493549826176"
          ],
          "editableUntil" : "2025-05-07T14:24:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "1",
      "id_str" : "1920107493549826176",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1920107493549826176",
      "created_at" : "Wed May 07 13:24:34 +0000 2025",
      "favorited" : false,
      "full_text" : "母がもらってきた赤いキウイ甘すぎる！！！まじでキウイなんかってかんじ！！！とにかく美味すぎる！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1920088320891408436"
          ],
          "editableUntil" : "2025-05-07T13:08:23.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "3",
      "id_str" : "1920088320891408436",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1920088320891408436",
      "created_at" : "Wed May 07 12:08:23 +0000 2025",
      "favorited" : false,
      "full_text" : "えまってただの副部長かと思ってたら議事録にガッツリ次期部長って書いてあってまずいまずい",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1919765939916025968"
          ],
          "editableUntil" : "2025-05-06T15:47:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "2",
      "id_str" : "1919765939916025968",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1919765939916025968",
      "created_at" : "Tue May 06 14:47:22 +0000 2025",
      "favorited" : false,
      "full_text" : "もう本当に勉強関連何もしたくない。燃え尽きた感じ。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1919701516828414058"
          ],
          "editableUntil" : "2025-05-06T11:31:22.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "13"
      ],
      "favorite_count" : "1",
      "id_str" : "1919701516828414058",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1919701516828414058",
      "created_at" : "Tue May 06 10:31:22 +0000 2025",
      "favorited" : false,
      "full_text" : "逆に期末コケたら終わりか？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1919701324058222894"
          ],
          "editableUntil" : "2025-05-06T11:30:36.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "1",
      "id_str" : "1919701324058222894",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1919701324058222894",
      "created_at" : "Tue May 06 10:30:36 +0000 2025",
      "favorited" : false,
      "full_text" : "中間の過去問全然ないなあって思ってたら、そもそも中間しない教科が多いのね。ありがとう。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1919587492463882484"
          ],
          "editableUntil" : "2025-05-06T03:58:17.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1919587492463882484/photo/1",
            "indices" : [
              "34",
              "57"
            ],
            "url" : "https://t.co/NZhqBoFPNa",
            "media_url" : "http://pbs.twimg.com/media/GqO-pi_bAAAbErc.jpg",
            "id_str" : "1919587487166693376",
            "id" : "1919587487166693376",
            "media_url_https" : "https://pbs.twimg.com/media/GqO-pi_bAAAbErc.jpg",
            "sizes" : {
              "large" : {
                "w" : "922",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "306",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "540",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/NZhqBoFPNa"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "57"
      ],
      "favorite_count" : "2",
      "id_str" : "1919587492463882484",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1919587492463882484",
      "possibly_sensitive" : false,
      "created_at" : "Tue May 06 02:58:17 +0000 2025",
      "favorited" : false,
      "full_text" : "スマホ無くして出来てなかった一昨日のリサーチ。マルノームかわいい！ https://t.co/NZhqBoFPNa",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1919587492463882484/photo/1",
            "indices" : [
              "34",
              "57"
            ],
            "url" : "https://t.co/NZhqBoFPNa",
            "media_url" : "http://pbs.twimg.com/media/GqO-pi_bAAAbErc.jpg",
            "id_str" : "1919587487166693376",
            "id" : "1919587487166693376",
            "media_url_https" : "https://pbs.twimg.com/media/GqO-pi_bAAAbErc.jpg",
            "sizes" : {
              "large" : {
                "w" : "922",
                "h" : "2048",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "306",
                "h" : "680",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "540",
                "h" : "1200",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/NZhqBoFPNa"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1919587228793372875"
          ],
          "editableUntil" : "2025-05-06T03:57:14.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "1",
      "id_str" : "1919587228793372875",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1919587228793372875",
      "created_at" : "Tue May 06 02:57:14 +0000 2025",
      "favorited" : false,
      "full_text" : "ああ！我が愛しの𝓼𝓶𝓪𝓻𝓽𝓹𝓱𝓸𝓷𝓮！よく生きていたな！！！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1919409234237645232"
          ],
          "editableUntil" : "2025-05-05T16:09:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "18"
      ],
      "favorite_count" : "0",
      "id_str" : "1919409234237645232",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1919409234237645232",
      "created_at" : "Mon May 05 15:09:56 +0000 2025",
      "favorited" : false,
      "full_text" : "こういうときに限ってポケポケ熱が…！",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1919408482941366306"
          ],
          "editableUntil" : "2025-05-05T16:06:57.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "31"
      ],
      "favorite_count" : "1",
      "id_str" : "1919408482941366306",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1919408482941366306",
      "created_at" : "Mon May 05 15:06:57 +0000 2025",
      "favorited" : false,
      "full_text" : "スマホ早く見つけに行きたいけど、明日も1時間半行くのだるいよ…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1919375952615776343"
          ],
          "editableUntil" : "2025-05-05T13:57:42.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "27"
      ],
      "favorite_count" : "1",
      "id_str" : "1919375952615776343",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1919375952615776343",
      "created_at" : "Mon May 05 12:57:42 +0000 2025",
      "favorited" : false,
      "full_text" : "すまほなくしてついったみれなかった\nぱそこんありがとう",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1918275775083757702"
          ],
          "editableUntil" : "2025-05-02T13:05:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "44"
      ],
      "favorite_count" : "0",
      "id_str" : "1918275775083757702",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1918275775083757702",
      "created_at" : "Fri May 02 12:05:59 +0000 2025",
      "favorited" : false,
      "full_text" : "もし2台目当たったら、誰かに低値で転売ヤーするか()\n(任天堂の意思に反してる気ががが)",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1918275259989676378"
          ],
          "editableUntil" : "2025-05-02T13:03:56.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "48"
      ],
      "favorite_count" : "7",
      "id_str" : "1918275259989676378",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1918275259989676378",
      "created_at" : "Fri May 02 12:03:56 +0000 2025",
      "favorited" : false,
      "full_text" : "電気屋のSwitch2の抽選当たってた！？！？あと4箇所くらい抽選結果待ち状態なのですが！？！？",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1918065921106800811"
          ],
          "editableUntil" : "2025-05-01T23:12:06.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "41"
      ],
      "favorite_count" : "0",
      "id_str" : "1918065921106800811",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1918065921106800811",
      "created_at" : "Thu May 01 22:12:06 +0000 2025",
      "favorited" : false,
      "full_text" : "恥を捨てて電車で地べたで座るのめっちゃ楽だった。\n何なら今日もそれで学校行きたい。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1917887787589927059"
          ],
          "editableUntil" : "2025-05-01T11:24:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "20"
      ],
      "favorite_count" : "2",
      "id_str" : "1917887787589927059",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1917887787589927059",
      "created_at" : "Thu May 01 10:24:15 +0000 2025",
      "favorited" : false,
      "full_text" : "あれ、今日昼飯食べてなくね？(遅すぎる)",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1917581165755785412"
          ],
          "editableUntil" : "2025-04-30T15:05:51.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "30"
      ],
      "favorite_count" : "0",
      "id_str" : "1917581165755785412",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1917581165755785412",
      "created_at" : "Wed Apr 30 14:05:51 +0000 2025",
      "favorited" : false,
      "full_text" : "昨日虫に刺されたところかゆすぎるし、かいたら痛いし腫れたー泣",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1917350972575343057"
          ],
          "editableUntil" : "2025-04-29T23:51:09.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "28"
      ],
      "favorite_count" : "2",
      "id_str" : "1917350972575343057",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1917350972575343057",
      "created_at" : "Tue Apr 29 22:51:09 +0000 2025",
      "favorited" : false,
      "full_text" : "どう頑張っても10点取れない。もう頑張るのやめようかな。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1916755451120582955"
          ],
          "editableUntil" : "2025-04-28T08:24:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "38"
      ],
      "favorite_count" : "1",
      "id_str" : "1916755451120582955",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1916755451120582955",
      "created_at" : "Mon Apr 28 07:24:45 +0000 2025",
      "favorited" : false,
      "full_text" : "学生証変えてもらったからって調子乗りすぎてるツイートしようとしたけど自重()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1916695434812424516"
          ],
          "editableUntil" : "2025-04-28T04:26:16.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "47"
      ],
      "favorite_count" : "1",
      "id_str" : "1916695434812424516",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1916695434812424516",
      "created_at" : "Mon Apr 28 03:26:16 +0000 2025",
      "favorited" : false,
      "full_text" : "ウエストのくびれ復活チャレンジのため、昼飯キャンセルをしようと意気込んだが、1日目で失敗…()",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1916149266810298579"
          ],
          "editableUntil" : "2025-04-26T16:16:00.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "43"
      ],
      "favorite_count" : "1",
      "id_str" : "1916149266810298579",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1916149266810298579",
      "created_at" : "Sat Apr 26 15:16:00 +0000 2025",
      "favorited" : false,
      "full_text" : "まってあたしのちょっとだけあったウエストは…！？春休みなってから消えた…！？ショック…",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1916115565342822620"
          ],
          "editableUntil" : "2025-04-26T14:02:05.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "53"
      ],
      "favorite_count" : "4",
      "id_str" : "1916115565342822620",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1916115565342822620",
      "created_at" : "Sat Apr 26 13:02:05 +0000 2025",
      "favorited" : false,
      "full_text" : "先輩も同期も後輩も遠慮なくブロックかブロ解してもらっていい。というか3月あたりに同期に死ぬほどされたわな。",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1916114721314640165"
          ],
          "editableUntil" : "2025-04-26T13:58:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "18"
      ],
      "favorite_count" : "1",
      "id_str" : "1916114721314640165",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1916114721314640165",
      "created_at" : "Sat Apr 26 12:58:43 +0000 2025",
      "favorited" : false,
      "full_text" : "嬉しくなってつい飛ばしちゃうんだよな",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1916114484537790961"
          ],
          "editableUntil" : "2025-04-26T13:57:47.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "1",
      "id_str" : "1916114484537790961",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1916114484537790961",
      "created_at" : "Sat Apr 26 12:57:47 +0000 2025",
      "favorited" : false,
      "full_text" : "自分からフォロー飛ばす先輩はやばい定期(自戒)",
      "lang" : "ja"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1915946615615197540"
          ],
          "editableUntil" : "2025-04-26T02:50:44.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [ ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1915946615615197540/photo/1",
            "indices" : [
              "79",
              "102"
            ],
            "url" : "https://t.co/fnDrijGjXb",
            "media_url" : "http://pbs.twimg.com/media/GpbPSv_bEAIFggf.jpg",
            "id_str" : "1915946612519800834",
            "id" : "1915946612519800834",
            "media_url_https" : "https://pbs.twimg.com/media/GpbPSv_bEAIFggf.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1024",
                "h" : "768",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1024",
                "h" : "768",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/fnDrijGjXb"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "102"
      ],
      "favorite_count" : "9",
      "id_str" : "1915946615615197540",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1915946615615197540",
      "possibly_sensitive" : false,
      "created_at" : "Sat Apr 26 01:50:44 +0000 2025",
      "favorited" : false,
      "full_text" : "母親が20年以上前に使ってたEos kiss発掘された…！\nフィルム使ったことなかったから使ってみたいんだけど、なんせ20年以上前のだから使えるのか…？？？ https://t.co/fnDrijGjXb",
      "lang" : "ja",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://x.com/joyjoy_7shichi7/status/1915946615615197540/photo/1",
            "indices" : [
              "79",
              "102"
            ],
            "url" : "https://t.co/fnDrijGjXb",
            "media_url" : "http://pbs.twimg.com/media/GpbPSv_bEAIFggf.jpg",
            "id_str" : "1915946612519800834",
            "id" : "1915946612519800834",
            "media_url_https" : "https://pbs.twimg.com/media/GpbPSv_bEAIFggf.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1024",
                "h" : "768",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "510",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1024",
                "h" : "768",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.x.com/fnDrijGjXb"
          }
        ]
      }
    }
  }
]