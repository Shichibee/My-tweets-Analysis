window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "1765658836759957505"
    }
  }
]