window.YTD.mute.part0 = [
  {
    "muting" : {
      "accountId" : "1908757419121070080",
      "userLink" : "https://twitter.com/intent/user?user_id=1908757419121070080"
    }
  },
  {
    "muting" : {
      "accountId" : "1897995793023504384",
      "userLink" : "https://twitter.com/intent/user?user_id=1897995793023504384"
    }
  },
  {
    "muting" : {
      "accountId" : "1576999174314160129",
      "userLink" : "https://twitter.com/intent/user?user_id=1576999174314160129"
    }
  },
  {
    "muting" : {
      "accountId" : "1780218549275078656",
      "userLink" : "https://twitter.com/intent/user?user_id=1780218549275078656"
    }
  },
  {
    "muting" : {
      "accountId" : "1688206119725080576",
      "userLink" : "https://twitter.com/intent/user?user_id=1688206119725080576"
    }
  },
  {
    "muting" : {
      "accountId" : "1900132690344763395",
      "userLink" : "https://twitter.com/intent/user?user_id=1900132690344763395"
    }
  },
  {
    "muting" : {
      "accountId" : "1027592725846093824",
      "userLink" : "https://twitter.com/intent/user?user_id=1027592725846093824"
    }
  },
  {
    "muting" : {
      "accountId" : "1897464835841073152",
      "userLink" : "https://twitter.com/intent/user?user_id=1897464835841073152"
    }
  },
  {
    "muting" : {
      "accountId" : "1897472932961726464",
      "userLink" : "https://twitter.com/intent/user?user_id=1897472932961726464"
    }
  },
  {
    "muting" : {
      "accountId" : "1907367644904493056",
      "userLink" : "https://twitter.com/intent/user?user_id=1907367644904493056"
    }
  },
  {
    "muting" : {
      "accountId" : "1708615553496293376",
      "userLink" : "https://twitter.com/intent/user?user_id=1708615553496293376"
    }
  },
  {
    "muting" : {
      "accountId" : "1765190434970861568",
      "userLink" : "https://twitter.com/intent/user?user_id=1765190434970861568"
    }
  },
  {
    "muting" : {
      "accountId" : "1852107681433292801",
      "userLink" : "https://twitter.com/intent/user?user_id=1852107681433292801"
    }
  },
  {
    "muting" : {
      "accountId" : "1122813090205065219",
      "userLink" : "https://twitter.com/intent/user?user_id=1122813090205065219"
    }
  },
  {
    "muting" : {
      "accountId" : "1632559241868484609",
      "userLink" : "https://twitter.com/intent/user?user_id=1632559241868484609"
    }
  },
  {
    "muting" : {
      "accountId" : "92482871",
      "userLink" : "https://twitter.com/intent/user?user_id=92482871"
    }
  },
  {
    "muting" : {
      "accountId" : "1774991013830090752",
      "userLink" : "https://twitter.com/intent/user?user_id=1774991013830090752"
    }
  },
  {
    "muting" : {
      "accountId" : "1497029777773182979",
      "userLink" : "https://twitter.com/intent/user?user_id=1497029777773182979"
    }
  },
  {
    "muting" : {
      "accountId" : "1583791867115999238",
      "userLink" : "https://twitter.com/intent/user?user_id=1583791867115999238"
    }
  },
  {
    "muting" : {
      "accountId" : "1581568629937647618",
      "userLink" : "https://twitter.com/intent/user?user_id=1581568629937647618"
    }
  },
  {
    "muting" : {
      "accountId" : "1709641993339682816",
      "userLink" : "https://twitter.com/intent/user?user_id=1709641993339682816"
    }
  },
  {
    "muting" : {
      "accountId" : "1757970274522476544",
      "userLink" : "https://twitter.com/intent/user?user_id=1757970274522476544"
    }
  },
  {
    "muting" : {
      "accountId" : "1620366409061785600",
      "userLink" : "https://twitter.com/intent/user?user_id=1620366409061785600"
    }
  },
  {
    "muting" : {
      "accountId" : "1636501570635599873",
      "userLink" : "https://twitter.com/intent/user?user_id=1636501570635599873"
    }
  },
  {
    "muting" : {
      "accountId" : "1388051205939634176",
      "userLink" : "https://twitter.com/intent/user?user_id=1388051205939634176"
    }
  },
  {
    "muting" : {
      "accountId" : "1731946779556679680",
      "userLink" : "https://twitter.com/intent/user?user_id=1731946779556679680"
    }
  },
  {
    "muting" : {
      "accountId" : "2860508569",
      "userLink" : "https://twitter.com/intent/user?user_id=2860508569"
    }
  },
  {
    "muting" : {
      "accountId" : "1732445720135745536",
      "userLink" : "https://twitter.com/intent/user?user_id=1732445720135745536"
    }
  },
  {
    "muting" : {
      "accountId" : "3117135549",
      "userLink" : "https://twitter.com/intent/user?user_id=3117135549"
    }
  },
  {
    "muting" : {
      "accountId" : "1641047732243808259",
      "userLink" : "https://twitter.com/intent/user?user_id=1641047732243808259"
    }
  },
  {
    "muting" : {
      "accountId" : "1373449440913096706",
      "userLink" : "https://twitter.com/intent/user?user_id=1373449440913096706"
    }
  },
  {
    "muting" : {
      "accountId" : "1243925540286763009",
      "userLink" : "https://twitter.com/intent/user?user_id=1243925540286763009"
    }
  },
  {
    "muting" : {
      "accountId" : "865480219540324354",
      "userLink" : "https://twitter.com/intent/user?user_id=865480219540324354"
    }
  },
  {
    "muting" : {
      "accountId" : "1131941661414551552",
      "userLink" : "https://twitter.com/intent/user?user_id=1131941661414551552"
    }
  }
]