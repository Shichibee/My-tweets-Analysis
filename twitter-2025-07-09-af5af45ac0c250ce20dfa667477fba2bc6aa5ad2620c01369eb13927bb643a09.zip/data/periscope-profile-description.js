window.YTD.periscope_profile_description.part0 = [
  {
    "periscopeProfileDescription" : {
      "bio" : "UEC24Ⅱ類 5クラ→Ⅰ類 Bクラ\nサークル : X680x0同好会🎮/写真研究部📸/uecﾎﾟｹﾓﾝだいすきｸﾗﾌﾞ⚡🐁/ｽﾎﾟｰﾂﾁｬﾝﾊﾞﾗ同好会⚔️\n\nこのアカウントは大学の情報収集のためだけに作られました。"
    }
  }
]