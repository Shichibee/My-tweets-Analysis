window.YTD.block.part0 = [
  {
    "blocking" : {
      "accountId" : "1913716577398296576",
      "userLink" : "https://twitter.com/intent/user?user_id=1913716577398296576"
    }
  },
  {
    "blocking" : {
      "accountId" : "1900517217902755840",
      "userLink" : "https://twitter.com/intent/user?user_id=1900517217902755840"
    }
  },
  {
    "blocking" : {
      "accountId" : "1886595277336760320",
      "userLink" : "https://twitter.com/intent/user?user_id=1886595277336760320"
    }
  },
  {
    "blocking" : {
      "accountId" : "1882482206268116992",
      "userLink" : "https://twitter.com/intent/user?user_id=1882482206268116992"
    }
  },
  {
    "blocking" : {
      "accountId" : "1880690805104672769",
      "userLink" : "https://twitter.com/intent/user?user_id=1880690805104672769"
    }
  },
  {
    "blocking" : {
      "accountId" : "1871459221705011200",
      "userLink" : "https://twitter.com/intent/user?user_id=1871459221705011200"
    }
  },
  {
    "blocking" : {
      "accountId" : "1870350537939697664",
      "userLink" : "https://twitter.com/intent/user?user_id=1870350537939697664"
    }
  },
  {
    "blocking" : {
      "accountId" : "1866813340154204162",
      "userLink" : "https://twitter.com/intent/user?user_id=1866813340154204162"
    }
  },
  {
    "blocking" : {
      "accountId" : "1866072448757825536",
      "userLink" : "https://twitter.com/intent/user?user_id=1866072448757825536"
    }
  },
  {
    "blocking" : {
      "accountId" : "1864405704427360256",
      "userLink" : "https://twitter.com/intent/user?user_id=1864405704427360256"
    }
  },
  {
    "blocking" : {
      "accountId" : "1863618220454002688",
      "userLink" : "https://twitter.com/intent/user?user_id=1863618220454002688"
    }
  },
  {
    "blocking" : {
      "accountId" : "1860297861881081857",
      "userLink" : "https://twitter.com/intent/user?user_id=1860297861881081857"
    }
  },
  {
    "blocking" : {
      "accountId" : "1858068189059645440",
      "userLink" : "https://twitter.com/intent/user?user_id=1858068189059645440"
    }
  },
  {
    "blocking" : {
      "accountId" : "1854358491466764288",
      "userLink" : "https://twitter.com/intent/user?user_id=1854358491466764288"
    }
  },
  {
    "blocking" : {
      "accountId" : "1852233373173141504",
      "userLink" : "https://twitter.com/intent/user?user_id=1852233373173141504"
    }
  },
  {
    "blocking" : {
      "accountId" : "1851548749358944256",
      "userLink" : "https://twitter.com/intent/user?user_id=1851548749358944256"
    }
  },
  {
    "blocking" : {
      "accountId" : "1851504518539698176",
      "userLink" : "https://twitter.com/intent/user?user_id=1851504518539698176"
    }
  },
  {
    "blocking" : {
      "accountId" : "1851060038304935936",
      "userLink" : "https://twitter.com/intent/user?user_id=1851060038304935936"
    }
  },
  {
    "blocking" : {
      "accountId" : "1848839750989582337",
      "userLink" : "https://twitter.com/intent/user?user_id=1848839750989582337"
    }
  },
  {
    "blocking" : {
      "accountId" : "1847003293228453893",
      "userLink" : "https://twitter.com/intent/user?user_id=1847003293228453893"
    }
  },
  {
    "blocking" : {
      "accountId" : "1845084365350457364",
      "userLink" : "https://twitter.com/intent/user?user_id=1845084365350457364"
    }
  },
  {
    "blocking" : {
      "accountId" : "1842826481589682176",
      "userLink" : "https://twitter.com/intent/user?user_id=1842826481589682176"
    }
  },
  {
    "blocking" : {
      "accountId" : "1842819702122221568",
      "userLink" : "https://twitter.com/intent/user?user_id=1842819702122221568"
    }
  },
  {
    "blocking" : {
      "accountId" : "1841770884853596161",
      "userLink" : "https://twitter.com/intent/user?user_id=1841770884853596161"
    }
  },
  {
    "blocking" : {
      "accountId" : "1838268226331119616",
      "userLink" : "https://twitter.com/intent/user?user_id=1838268226331119616"
    }
  },
  {
    "blocking" : {
      "accountId" : "1828110247892066304",
      "userLink" : "https://twitter.com/intent/user?user_id=1828110247892066304"
    }
  },
  {
    "blocking" : {
      "accountId" : "1821415707323899904",
      "userLink" : "https://twitter.com/intent/user?user_id=1821415707323899904"
    }
  },
  {
    "blocking" : {
      "accountId" : "1821349013993746432",
      "userLink" : "https://twitter.com/intent/user?user_id=1821349013993746432"
    }
  },
  {
    "blocking" : {
      "accountId" : "1820771047299489792",
      "userLink" : "https://twitter.com/intent/user?user_id=1820771047299489792"
    }
  },
  {
    "blocking" : {
      "accountId" : "1819576421486153729",
      "userLink" : "https://twitter.com/intent/user?user_id=1819576421486153729"
    }
  },
  {
    "blocking" : {
      "accountId" : "1819218311013396480",
      "userLink" : "https://twitter.com/intent/user?user_id=1819218311013396480"
    }
  },
  {
    "blocking" : {
      "accountId" : "1817989101913784325",
      "userLink" : "https://twitter.com/intent/user?user_id=1817989101913784325"
    }
  },
  {
    "blocking" : {
      "accountId" : "1817186412224974849",
      "userLink" : "https://twitter.com/intent/user?user_id=1817186412224974849"
    }
  },
  {
    "blocking" : {
      "accountId" : "1816833232526065664",
      "userLink" : "https://twitter.com/intent/user?user_id=1816833232526065664"
    }
  },
  {
    "blocking" : {
      "accountId" : "1816769889643966464",
      "userLink" : "https://twitter.com/intent/user?user_id=1816769889643966464"
    }
  },
  {
    "blocking" : {
      "accountId" : "1815400841807089664",
      "userLink" : "https://twitter.com/intent/user?user_id=1815400841807089664"
    }
  },
  {
    "blocking" : {
      "accountId" : "1814947103057354752",
      "userLink" : "https://twitter.com/intent/user?user_id=1814947103057354752"
    }
  },
  {
    "blocking" : {
      "accountId" : "1811828670111318017",
      "userLink" : "https://twitter.com/intent/user?user_id=1811828670111318017"
    }
  },
  {
    "blocking" : {
      "accountId" : "1810737009859907585",
      "userLink" : "https://twitter.com/intent/user?user_id=1810737009859907585"
    }
  },
  {
    "blocking" : {
      "accountId" : "1805147226642989056",
      "userLink" : "https://twitter.com/intent/user?user_id=1805147226642989056"
    }
  },
  {
    "blocking" : {
      "accountId" : "1792662906917523456",
      "userLink" : "https://twitter.com/intent/user?user_id=1792662906917523456"
    }
  },
  {
    "blocking" : {
      "accountId" : "1791083283037724673",
      "userLink" : "https://twitter.com/intent/user?user_id=1791083283037724673"
    }
  },
  {
    "blocking" : {
      "accountId" : "1784924761505849344",
      "userLink" : "https://twitter.com/intent/user?user_id=1784924761505849344"
    }
  },
  {
    "blocking" : {
      "accountId" : "1781618467239804928",
      "userLink" : "https://twitter.com/intent/user?user_id=1781618467239804928"
    }
  },
  {
    "blocking" : {
      "accountId" : "1774097413487403008",
      "userLink" : "https://twitter.com/intent/user?user_id=1774097413487403008"
    }
  },
  {
    "blocking" : {
      "accountId" : "1761834903665004544",
      "userLink" : "https://twitter.com/intent/user?user_id=1761834903665004544"
    }
  },
  {
    "blocking" : {
      "accountId" : "1755087741371498496",
      "userLink" : "https://twitter.com/intent/user?user_id=1755087741371498496"
    }
  },
  {
    "blocking" : {
      "accountId" : "1754583360452653056",
      "userLink" : "https://twitter.com/intent/user?user_id=1754583360452653056"
    }
  },
  {
    "blocking" : {
      "accountId" : "1748689533565079552",
      "userLink" : "https://twitter.com/intent/user?user_id=1748689533565079552"
    }
  },
  {
    "blocking" : {
      "accountId" : "1741915641471266816",
      "userLink" : "https://twitter.com/intent/user?user_id=1741915641471266816"
    }
  },
  {
    "blocking" : {
      "accountId" : "1723184740038217728",
      "userLink" : "https://twitter.com/intent/user?user_id=1723184740038217728"
    }
  },
  {
    "blocking" : {
      "accountId" : "1711259099298754560",
      "userLink" : "https://twitter.com/intent/user?user_id=1711259099298754560"
    }
  },
  {
    "blocking" : {
      "accountId" : "1709641993339682816",
      "userLink" : "https://twitter.com/intent/user?user_id=1709641993339682816"
    }
  },
  {
    "blocking" : {
      "accountId" : "1700000206744428544",
      "userLink" : "https://twitter.com/intent/user?user_id=1700000206744428544"
    }
  },
  {
    "blocking" : {
      "accountId" : "1688206119725080576",
      "userLink" : "https://twitter.com/intent/user?user_id=1688206119725080576"
    }
  },
  {
    "blocking" : {
      "accountId" : "1680137570305609730",
      "userLink" : "https://twitter.com/intent/user?user_id=1680137570305609730"
    }
  },
  {
    "blocking" : {
      "accountId" : "1672166161625088001",
      "userLink" : "https://twitter.com/intent/user?user_id=1672166161625088001"
    }
  },
  {
    "blocking" : {
      "accountId" : "1665325765661958144",
      "userLink" : "https://twitter.com/intent/user?user_id=1665325765661958144"
    }
  },
  {
    "blocking" : {
      "accountId" : "1655256386106961920",
      "userLink" : "https://twitter.com/intent/user?user_id=1655256386106961920"
    }
  },
  {
    "blocking" : {
      "accountId" : "1642893307780136960",
      "userLink" : "https://twitter.com/intent/user?user_id=1642893307780136960"
    }
  },
  {
    "blocking" : {
      "accountId" : "1613723047659458561",
      "userLink" : "https://twitter.com/intent/user?user_id=1613723047659458561"
    }
  },
  {
    "blocking" : {
      "accountId" : "1600839073941577731",
      "userLink" : "https://twitter.com/intent/user?user_id=1600839073941577731"
    }
  },
  {
    "blocking" : {
      "accountId" : "1570831627902922752",
      "userLink" : "https://twitter.com/intent/user?user_id=1570831627902922752"
    }
  },
  {
    "blocking" : {
      "accountId" : "1562099483978366977",
      "userLink" : "https://twitter.com/intent/user?user_id=1562099483978366977"
    }
  },
  {
    "blocking" : {
      "accountId" : "1561813022066511872",
      "userLink" : "https://twitter.com/intent/user?user_id=1561813022066511872"
    }
  },
  {
    "blocking" : {
      "accountId" : "1561706175552311296",
      "userLink" : "https://twitter.com/intent/user?user_id=1561706175552311296"
    }
  },
  {
    "blocking" : {
      "accountId" : "1539487958101000193",
      "userLink" : "https://twitter.com/intent/user?user_id=1539487958101000193"
    }
  },
  {
    "blocking" : {
      "accountId" : "1525517444433203200",
      "userLink" : "https://twitter.com/intent/user?user_id=1525517444433203200"
    }
  },
  {
    "blocking" : {
      "accountId" : "1508350305380954115",
      "userLink" : "https://twitter.com/intent/user?user_id=1508350305380954115"
    }
  },
  {
    "blocking" : {
      "accountId" : "1501508173429370883",
      "userLink" : "https://twitter.com/intent/user?user_id=1501508173429370883"
    }
  },
  {
    "blocking" : {
      "accountId" : "1499739415048032265",
      "userLink" : "https://twitter.com/intent/user?user_id=1499739415048032265"
    }
  },
  {
    "blocking" : {
      "accountId" : "1487468665989890050",
      "userLink" : "https://twitter.com/intent/user?user_id=1487468665989890050"
    }
  },
  {
    "blocking" : {
      "accountId" : "1483771941563830275",
      "userLink" : "https://twitter.com/intent/user?user_id=1483771941563830275"
    }
  },
  {
    "blocking" : {
      "accountId" : "1480125471782100995",
      "userLink" : "https://twitter.com/intent/user?user_id=1480125471782100995"
    }
  },
  {
    "blocking" : {
      "accountId" : "1469997773671964673",
      "userLink" : "https://twitter.com/intent/user?user_id=1469997773671964673"
    }
  },
  {
    "blocking" : {
      "accountId" : "1463794356268134405",
      "userLink" : "https://twitter.com/intent/user?user_id=1463794356268134405"
    }
  },
  {
    "blocking" : {
      "accountId" : "1460099449733091330",
      "userLink" : "https://twitter.com/intent/user?user_id=1460099449733091330"
    }
  },
  {
    "blocking" : {
      "accountId" : "1435806175660941316",
      "userLink" : "https://twitter.com/intent/user?user_id=1435806175660941316"
    }
  },
  {
    "blocking" : {
      "accountId" : "1433835794188455938",
      "userLink" : "https://twitter.com/intent/user?user_id=1433835794188455938"
    }
  },
  {
    "blocking" : {
      "accountId" : "1432739659541528578",
      "userLink" : "https://twitter.com/intent/user?user_id=1432739659541528578"
    }
  },
  {
    "blocking" : {
      "accountId" : "1415926097888223234",
      "userLink" : "https://twitter.com/intent/user?user_id=1415926097888223234"
    }
  },
  {
    "blocking" : {
      "accountId" : "1378314712220246017",
      "userLink" : "https://twitter.com/intent/user?user_id=1378314712220246017"
    }
  },
  {
    "blocking" : {
      "accountId" : "1342063380610203648",
      "userLink" : "https://twitter.com/intent/user?user_id=1342063380610203648"
    }
  },
  {
    "blocking" : {
      "accountId" : "1325236724176334848",
      "userLink" : "https://twitter.com/intent/user?user_id=1325236724176334848"
    }
  },
  {
    "blocking" : {
      "accountId" : "1295572296870969345",
      "userLink" : "https://twitter.com/intent/user?user_id=1295572296870969345"
    }
  },
  {
    "blocking" : {
      "accountId" : "1285123011624833025",
      "userLink" : "https://twitter.com/intent/user?user_id=1285123011624833025"
    }
  },
  {
    "blocking" : {
      "accountId" : "1282942034941063168",
      "userLink" : "https://twitter.com/intent/user?user_id=1282942034941063168"
    }
  },
  {
    "blocking" : {
      "accountId" : "1236293529845919746",
      "userLink" : "https://twitter.com/intent/user?user_id=1236293529845919746"
    }
  },
  {
    "blocking" : {
      "accountId" : "1233686148993757184",
      "userLink" : "https://twitter.com/intent/user?user_id=1233686148993757184"
    }
  },
  {
    "blocking" : {
      "accountId" : "1222383505507643392",
      "userLink" : "https://twitter.com/intent/user?user_id=1222383505507643392"
    }
  },
  {
    "blocking" : {
      "accountId" : "1207127588415500288",
      "userLink" : "https://twitter.com/intent/user?user_id=1207127588415500288"
    }
  },
  {
    "blocking" : {
      "accountId" : "1179174810020171776",
      "userLink" : "https://twitter.com/intent/user?user_id=1179174810020171776"
    }
  },
  {
    "blocking" : {
      "accountId" : "1151804880413052928",
      "userLink" : "https://twitter.com/intent/user?user_id=1151804880413052928"
    }
  },
  {
    "blocking" : {
      "accountId" : "1129356512181329922",
      "userLink" : "https://twitter.com/intent/user?user_id=1129356512181329922"
    }
  },
  {
    "blocking" : {
      "accountId" : "1099157212478521344",
      "userLink" : "https://twitter.com/intent/user?user_id=1099157212478521344"
    }
  },
  {
    "blocking" : {
      "accountId" : "1094533609300492288",
      "userLink" : "https://twitter.com/intent/user?user_id=1094533609300492288"
    }
  },
  {
    "blocking" : {
      "accountId" : "1008647195090825216",
      "userLink" : "https://twitter.com/intent/user?user_id=1008647195090825216"
    }
  },
  {
    "blocking" : {
      "accountId" : "943492458662346752",
      "userLink" : "https://twitter.com/intent/user?user_id=943492458662346752"
    }
  },
  {
    "blocking" : {
      "accountId" : "917304539870629890",
      "userLink" : "https://twitter.com/intent/user?user_id=917304539870629890"
    }
  },
  {
    "blocking" : {
      "accountId" : "902979044374962176",
      "userLink" : "https://twitter.com/intent/user?user_id=902979044374962176"
    }
  },
  {
    "blocking" : {
      "accountId" : "893099521109925889",
      "userLink" : "https://twitter.com/intent/user?user_id=893099521109925889"
    }
  },
  {
    "blocking" : {
      "accountId" : "885146434940620801",
      "userLink" : "https://twitter.com/intent/user?user_id=885146434940620801"
    }
  },
  {
    "blocking" : {
      "accountId" : "843510874228703232",
      "userLink" : "https://twitter.com/intent/user?user_id=843510874228703232"
    }
  },
  {
    "blocking" : {
      "accountId" : "823160987947794432",
      "userLink" : "https://twitter.com/intent/user?user_id=823160987947794432"
    }
  },
  {
    "blocking" : {
      "accountId" : "766319006018113536",
      "userLink" : "https://twitter.com/intent/user?user_id=766319006018113536"
    }
  },
  {
    "blocking" : {
      "accountId" : "724065377412616192",
      "userLink" : "https://twitter.com/intent/user?user_id=724065377412616192"
    }
  },
  {
    "blocking" : {
      "accountId" : "709627640701784067",
      "userLink" : "https://twitter.com/intent/user?user_id=709627640701784067"
    }
  },
  {
    "blocking" : {
      "accountId" : "3306781382",
      "userLink" : "https://twitter.com/intent/user?user_id=3306781382"
    }
  },
  {
    "blocking" : {
      "accountId" : "3229250676",
      "userLink" : "https://twitter.com/intent/user?user_id=3229250676"
    }
  },
  {
    "blocking" : {
      "accountId" : "3184096848",
      "userLink" : "https://twitter.com/intent/user?user_id=3184096848"
    }
  },
  {
    "blocking" : {
      "accountId" : "2924173694",
      "userLink" : "https://twitter.com/intent/user?user_id=2924173694"
    }
  },
  {
    "blocking" : {
      "accountId" : "2892127812",
      "userLink" : "https://twitter.com/intent/user?user_id=2892127812"
    }
  },
  {
    "blocking" : {
      "accountId" : "2784332590",
      "userLink" : "https://twitter.com/intent/user?user_id=2784332590"
    }
  },
  {
    "blocking" : {
      "accountId" : "2640135634",
      "userLink" : "https://twitter.com/intent/user?user_id=2640135634"
    }
  },
  {
    "blocking" : {
      "accountId" : "2348618768",
      "userLink" : "https://twitter.com/intent/user?user_id=2348618768"
    }
  },
  {
    "blocking" : {
      "accountId" : "2280788234",
      "userLink" : "https://twitter.com/intent/user?user_id=2280788234"
    }
  },
  {
    "blocking" : {
      "accountId" : "1618113870",
      "userLink" : "https://twitter.com/intent/user?user_id=1618113870"
    }
  },
  {
    "blocking" : {
      "accountId" : "1418930144",
      "userLink" : "https://twitter.com/intent/user?user_id=1418930144"
    }
  },
  {
    "blocking" : {
      "accountId" : "1371989568",
      "userLink" : "https://twitter.com/intent/user?user_id=1371989568"
    }
  },
  {
    "blocking" : {
      "accountId" : "627525938",
      "userLink" : "https://twitter.com/intent/user?user_id=627525938"
    }
  },
  {
    "blocking" : {
      "accountId" : "609855049",
      "userLink" : "https://twitter.com/intent/user?user_id=609855049"
    }
  },
  {
    "blocking" : {
      "accountId" : "547511483",
      "userLink" : "https://twitter.com/intent/user?user_id=547511483"
    }
  },
  {
    "blocking" : {
      "accountId" : "469387155",
      "userLink" : "https://twitter.com/intent/user?user_id=469387155"
    }
  },
  {
    "blocking" : {
      "accountId" : "401864280",
      "userLink" : "https://twitter.com/intent/user?user_id=401864280"
    }
  },
  {
    "blocking" : {
      "accountId" : "184813206",
      "userLink" : "https://twitter.com/intent/user?user_id=184813206"
    }
  },
  {
    "blocking" : {
      "accountId" : "158458667",
      "userLink" : "https://twitter.com/intent/user?user_id=158458667"
    }
  }
]