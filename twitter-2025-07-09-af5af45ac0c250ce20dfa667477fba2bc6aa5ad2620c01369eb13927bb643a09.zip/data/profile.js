window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "UEC24Ⅱ類 5クラ→Ⅰ類 Bクラ\nサークル : X680x0同好会🎮/写真研究部📸/uecﾎﾟｹﾓﾝだいすきｸﾗﾌﾞ⚡🐁/ｽﾎﾟｰﾂﾁｬﾝﾊﾞﾗ同好会⚔️\n\nこのアカウントは大学の情報収集のためだけに作られました。",
        "website" : "https://t.co/WQiAM54tG0",
        "location" : "湘南新宿ライン"
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1906909716728647680/esQNDbpz.jpg",
      "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/1765658836759957505/1743477414"
    }
  }
]